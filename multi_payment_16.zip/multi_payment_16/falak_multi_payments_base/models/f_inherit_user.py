from odoo import models, fields, api
from datetime import datetime


class FusersInherit(models.Model):
    _inherit = 'res.users' 
    
    f_default_journal = fields.Many2one('account.journal', string='default Journal' )