# -*- coding: utf-8 -*-

import json
import time
from ast import literal_eval
from collections import defaultdict
from datetime import date
from itertools import groupby
from operator import itemgetter

from odoo import SUPERUSER_ID, _, api, fields, models,tools
from odoo.addons.stock.models.stock_move import PROCUREMENT_PRIORITIES
from odoo.exceptions import UserError
from odoo.osv import expression
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, format_datetime
from odoo.tools.float_utils import float_compare, float_is_zero, float_round
from odoo.tools.misc import format_date
import logging
_logger = logging.getLogger(__name__)



class FStockMoveInherit(models.Model):
    _inherit = 'stock.move'
    source_move_id = fields.Many2one('stock.move', string='Source Move')
    f_prod_note = fields.Text(string="Note")
     

class FConfigSettings(models.TransientModel):
    _inherit = "res.config.settings"

    f_ship_testqty = fields.Boolean("Prevent Shipment Transfers",default= True)
   


    def set_values(self):
        super(FConfigSettings, self).set_values()
        config_parameters = self.env["ir.config_parameter"].sudo()

        for record in self:
            config_parameters.sudo().set_param("transfer_module.f_ship_testqty", record.f_ship_testqty)
        
        
        
        

    def get_values(self):
        res = super(FConfigSettings, self).get_values()
        f_ship_testqty = self.env['ir.config_parameter'].sudo().get_param('transfer_module.f_ship_testqty')
        res.update(
            f_ship_testqty = f_ship_testqty,
        )
        return res

    


class FTransferStockLocation(models.Model):
    _inherit = 'stock.location'
    
    
    f_is_transet = fields.Boolean("Is Transit",default=False)
    
class FTransferStockpick(models.Model):
    _inherit ="stock.picking"
    
    
    f_to_loc = fields.Many2many('stock.location', string="To Location Details")
    f_name_sequance = fields.Char("Internal Picking Seq" , default='', readonly=True, copy=False)
    f_transfer_id = fields.Many2one('f.stock.picking.transfer' , string="ITC NO.", copy=False) 
    f_source_transit=fields.Boolean(related='location_id.f_is_transet',string='src transit',store=True)
    f_dest_transit=fields.Boolean(related='location_dest_id.f_is_transet',string='dest transit',store=True)


    
    @api.model
    def create(self, vals):
        
        if 'backorder_id' in vals:
            pick = self.sudo().env['stock.picking'].sudo().search([('id','=',vals['backorder_id'])])
            if pick.f_transfer_id:
                vals['f_transfer_id'] = pick.f_transfer_id.id
        res = super(FTransferStockpick, self).create(vals)    
        return res


    
    @api.onchange('backorder_id')
    def f_get_itec_no(self):
        if self.backorder_id.f_transfer_id :
            self.f_transfer_id = self.backorder_id.f_transfer_id.id
    
    


  
  
    def f_view_barcode(self):
        
            
            print("88888999666")
            self.ensure_one()
            action = self.env["ir.actions.actions"]._for_xml_id("stock_barcode.stock_barcode_picking_client_action")
            params = {
                'model': 'stock.picking',
                'picking_id': self.id,
                'nomenclature_id': [self.env.company.nomenclature_id.id],
            }
            return dict(action, target='fullscreen', params=params)
        
        
            
#       
    @api.onchange('location_id')
    def get_locat(self):
        
        locations = self.env['stock.location'].search(["|",('f_limited_access','=',False),('f_allowed_users','in',self.env.user.id)])
        print("8888888888888888",locations)
        if self.location_id.id not in locations.ids:
            self.location_id = ''
            
            
        
             
             
        
            
    @api.onchange('picking_type_id')
    def _onchange_transfer(self):
        print("TTTTTTT")
        
        if self.user_has_groups('transfer_module.f_transfer_group_id'):
            print("passsssss")
           
           
        else:
            if self.picking_type_id.default_location_src_id.f_is_transet == True:
                print("llllll")
                self.picking_type_id = ''
        
        if self.picking_type_id.default_location_dest_id.f_is_transet == True:
            ld= []
            
            zz=self.env['stock.location'].search([('f_is_transet' , '=', True )]) 
            for x in zz :
                ld.append(x.id)
            domain_on_types=[('id' ,'in',ld)]
            
            #to loc
            
            ld_to_loc= []
            
            zz_toloc=self.env['stock.location'].with_user(SUPERUSER_ID).search([('usage' , '=','internal')]) 
            for x in zz_toloc :
                ld_to_loc.append(x.id)
            toloc_domain_on_types=[('id' ,'in',ld_to_loc)]



            
            ldl= []

            zo=self.env['stock.location'].search([('usage' , '=','internal')]) 
            print("zzzzzzzzzzzzz",zo)
            for x in zo :
                if self.env.user in x.f_allowed_users or x.f_limited_access ==  False:
                    ldl.append(x.id)
                
          #  ldl.append(self.picking_type_id.default_location_src_id.id)    
            loc_domain_on_types=[('id' ,'in',ldl)]
            
            
            
            return {'domain': {'location_dest_id': domain_on_types,'location_id': loc_domain_on_types,'f_to_loc':toloc_domain_on_types}}
        

        
        
        
        if self.picking_type_id.default_location_src_id.f_is_transet == True:
          #  self.location_dest_id = ''
            l= []
            zz=self.env['stock.location'].search([('f_is_transet' , '=', True )]) 
            for x in zz :
                l.append(x.id)
            domain_on_types=[('id' ,'in',l)]
            
            
            
            
            ldl= []
            zo=self.env['stock.location'].search([('usage' , '=','internal')]) 
            print("zzzzzzzzzzzzz",zo)
            for x in zo :
                if self.env.user in x.f_allowed_users or x.f_limited_access ==  False:
                    ldl.append(x.id)
                
           # ldl.append(self.picking_type_id.default_location_dest_id.id)    
            loc_domain_on_types=[('id' ,'in',ldl)]
            
            
            
            return {'domain': {'location_id': domain_on_types,'location_dest_id': loc_domain_on_types}}
                
            
        if self.picking_type_id.default_location_dest_id.f_is_transet == False or self.picking_type_id.default_location_src_id.f_is_transet == False:
            print("55555")  
            self.location_id =''
            ldls= []
            zod=self.env['stock.location'].search([('usage' , '=','internal')]) 
            print("zzzzzzzzzzzzz",zod)
            for x in zod :
                if self.env.user in x.f_allowed_users or x.f_limited_access ==  False:
                    ldls.append(x.id)
                
            loc_domain_on_typesd=[('id' ,'in',ldls)] 
            
            return {'domain': {'location_id': loc_domain_on_typesd}}



    
    def button_validate(self):
        for pick in self:
            if self.env['ir.config_parameter'].sudo().get_param('transfer_module.f_ship_testqty'):
                if pick.picking_type_id.code == 'internal':
                    if pick.picking_type_id.default_location_dest_id.f_is_transet == True or pick.picking_type_id.default_location_src_id.f_is_transet != True:
                        if pick.move_line_ids:
                            # Aggregate `qty_done` for each product-location pair directly in Python
                            product_location_qty = {}
                            for line in pick.move_line_ids:
                                key = (line.product_id.id, line.location_id.id)
                                product_location_qty[key] = product_location_qty.get(key, 0) + line.qty_done

                            # Fetch all `stock.quant` records for these product-location pairs in bulk
                            product_ids = list(set(key[0] for key in product_location_qty.keys()))
                            location_ids = list(set(key[1] for key in product_location_qty.keys()))
                            stock_quants = self.env['stock.quant'].search([
                                ('product_id', 'in', product_ids),
                                ('location_id', 'in', location_ids),
                            ])

                            #  Build a map of available quantities from `stock.quants`
                            stock_quant_map = {
                                (quant.product_id.id, quant.location_id.id): quant.quantity
                                for quant in stock_quants
                            }

                            #  Check if `qty_done` exceeds available quantity
                            res2_msg = []
                            for (product_id, location_id), total_qty_done in product_location_qty.items():
                                available_qty = stock_quant_map.get((product_id, location_id), 0)
                                if total_qty_done > available_qty:
                                    product = self.env['product.product'].browse(product_id)
                                    res2_msg.append(f"{product.barcode} - [{product.display_name}]")

                            if res2_msg:
                                res_msg = '\n'.join(res2_msg)
                                raise UserError(_(
                                    "Cannot validate the total Shipment Qty for Products:\n"
                                    "[%s]\n"
                                    "The shipment quantity exceeds the available stock.\n"
                                    "Please contact your manager.", res_msg
                                ))

            if pick.location_dest_id.f_is_transet == True:
                if pick.f_name_sequance == '':
                    number = self.env['ir.sequence'].next_by_code('f.seq.stock.picking')
                    pick.f_name_sequance = number
                    name_source = list()
                    print(pick.f_to_loc)
                    # print (dict(pick._fields['f_to_loc'].selection).get(pick.f_to_loc),"pppppppppppp")

                    name_source.append('''%s - %s''' % (pick.name, pick.location_id.display_name))
                    final_name = '\n'.join(name_source).strip(' + ')

                    self.env['f.stock.picking.transfer'].create(

                        {'f_name': number, 'f_source': final_name, 'f_to_loc': pick.f_to_loc})

            if pick.f_transfer_id:
                pick.f_name_sequance = pick.f_transfer_id.f_name

                groups = {}
                for xx in pick.move_line_ids:
                    dic_name = xx.product_id.id
                    if not groups.get(dic_name):
                        groups[dic_name] = {}
                        groups[dic_name].update({
                            'qty': xx.qty_done,
                            'product': xx.product_id
                        })
                        # print("ggggggggggggggg22222",groups[dic_name])
                    else:
                        groups[dic_name].update({
                            'qty': groups[dic_name].get('qty') + xx.qty_done,
                        })

                product_ids = list(groups.keys())
                icttransfers = self.env['f.real.icttransfer'].search([
                    ('f_name_seq', '=', pick.f_name_sequance),
                    ('product_id', 'in', product_ids)
                ])

                # Create a mapping for quick lookup of existing transfer records
                icttransfer_map = {rec.product_id.id: rec for rec in icttransfers}

                res2_msg_de = []

                # Iterate through grouped products
                for product_id, data in groups.items():
                    qty_done = data['qty']
                    product = data['product']

                    # Check if the product has an existing transfer record
                    if product_id in icttransfer_map:
                        icttransfer = icttransfer_map[product_id]
                        total_done = icttransfer.qty_done + qty_done
                        if total_done > icttransfer.qty_ship:
                            res2_msg_de.append(f"{product.barcode} - [{product.display_name}]")
                    else:
                        if qty_done != 0:  # Only add if quantity is non-zero
                            res2_msg_de.append(f"{product.barcode} - [{product.display_name}]")

                # Join messages and raise an error if needed
                if res2_msg_de:
                    res_msg_de = '\n'.join(res2_msg_de)
                    raise UserError(_(
                        'Cannot validate the total delivery of Products: \n [%s] \n'
                        'as it exceeds the ordered quantity. \n'
                        'Please contact your manager.', res_msg_de
                    ))

                # print("groups",groups)

            _logger.info('transfer test : 1  -----------------------   %s', pick.id)
            if pick.picking_type_id.f_enable_auto_receive:

                # print("Autooooo")

                tranfer_seq_nou = self.env['f.stock.picking.transfer'].search([('f_name', '=', pick.f_name_sequance)])
                _logger.info('transfer test  : 2 -----------------------   %s', pick.id)
                defaults = pick.default_get(
                    ['name', 'picking_type_id', 'location_id', 'location_dest_id', 'f_transfer_id', 'f_name_sequance',
                     'move_ids_without_package'])

                defaults.update({'name': '/'})
                defaults.update({'picking_type_id': pick.picking_type_id.f_opertaion_type_receiving.id})
                defaults.update({'location_id': pick.location_dest_id.id})
                defaults.update({'location_dest_id': pick.f_to_loc.id})
                defaults.update({'f_transfer_id': tranfer_seq_nou.id})
                defaults.update({'f_name_sequance': pick.f_name_sequance})
                defaults.update({'immediate_transfer': False})

                new_picking_id = self.env['stock.picking'].with_user(SUPERUSER_ID).search(
                    [('f_transfer_id', '=', tranfer_seq_nou.id)])
                # print("new_picking_idnew_picking_id",new_picking_id)
                if new_picking_id:
                    # print("5555")
                    new_picking_id.is_locked = False
                    if pick.picking_type_id.f_enable_auto_receive and not pick.picking_type_id.f_enable_auto_fill_qty:
                        # print("mmmmmm")
                        _logger.info('transfer test : 3  -----------------------   %s', pick.id)
                        for pick_rec in pick.move_line_ids:
                            move = self.env['stock.move'].search([('picking_id', '=', new_picking_id.id),
                                                                  ('product_id', '=', pick_rec.product_id.id)]).write({
                                'company_id': pick_rec.company_id.id,
                                'picking_type_id': pick_rec.picking_type_id.f_opertaion_type_receiving.id,
                                'name': pick_rec.product_id.name,
                                'product_id': pick_rec.product_id.id,
                                'location_id': pick.location_dest_id.id,
                                'location_dest_id': pick.f_to_loc.id,
                                'product_uom': pick_rec.product_uom_id.id,
                                'picking_id': new_picking_id.id,
                                'state': 'draft',
                                # 'source_move_id': pick.id,
                                'f_prod_note': pick_rec.move_id.f_prod_note,
                            })

                    if pick.picking_type_id.f_enable_auto_receive and pick.picking_type_id.f_enable_auto_fill_qty:
                        print("555229999999999999999999")
                        _logger.info('transfer test : 4  -----------------------   %s', pick.id)
                        for pick_rec in pick.move_line_ids:
                            move = self.env['stock.move'].search([('picking_id', '=', new_picking_id.id),
                                                                  ('product_id', '=', pick_rec.product_id.id)]).write({
                                'company_id': pick_rec.company_id.id,
                                'picking_type_id': pick_rec.picking_type_id.f_opertaion_type_receiving.id,
                                'name': pick_rec.product_id.name,
                                'product_id': pick_rec.product_id.id,
                                'product_uom_qty': pick_rec.qty_done,
                                'location_id': pick.location_dest_id.id,
                                'location_dest_id': pick.f_to_loc.id,
                                'product_uom': pick_rec.product_uom_id.id,
                                'picking_id': new_picking_id.id,
                                'state': 'draft',
                                # 'source_move_id': pick.id,
                                'f_prod_note': pick_rec.move_id.f_prod_note,
                            })

                else:
                    # print("deffffff",defaults)
                    # v.with_user(SUPERUSER_ID).

                    xx = self.env['stock.picking'].with_user(SUPERUSER_ID).create(defaults)
                    xx.is_locked = False
                    if xx:
                        if pick.picking_type_id.f_enable_auto_receive and not pick.picking_type_id.f_enable_auto_fill_qty:
                            _logger.info('transfer test : 5  -----------------------   %s', pick.id)
                            for pick_rec in pick.move_ids:
                                move = pick.env['stock.move'].create({
                                    'company_id': pick_rec.company_id.id,
                                    'picking_type_id': pick_rec.picking_type_id.f_opertaion_type_receiving.id,
                                    'name': pick_rec.product_id.name,
                                    'product_id': pick_rec.product_id.id,
                                    'location_id': pick.location_dest_id.id,
                                    'location_dest_id': pick.f_to_loc.id,
                                    'product_uom': pick_rec.product_uom.id,
                                    'picking_id': xx.id,
                                    'state': 'draft',
                                    # 'source_move_id': pick.id,
                                    'f_prod_note': pick_rec.f_prod_note,
                                })
                                # print("moveeeeeeee",move)
                                move._action_assign()
                        if pick.picking_type_id.f_enable_auto_receive and pick.picking_type_id.f_enable_auto_fill_qty:
                            _logger.info('transfer test : 5  -----------------------   %s', pick.id)
                            for pick_rec in pick.move_ids:
                                move = self.env['stock.move'].create({
                                    'company_id': pick_rec.company_id.id,
                                    'picking_type_id': pick_rec.picking_type_id.f_opertaion_type_receiving.id,
                                    'name': pick_rec.product_id.name,
                                    'product_id': pick_rec.product_id.id,
                                    'product_uom_qty': pick_rec.quantity_done,
                                    'location_id': pick.location_dest_id.id,
                                    'location_dest_id': pick.f_to_loc.id,
                                    'product_uom': pick_rec.product_uom.id,
                                    'picking_id': xx.id,
                                    'state': 'draft',
                                    # 'source_move_id': pick.id,
                                    'f_prod_note': pick_rec.f_prod_note,
                                })
                                # print("moveeeeeeee2222",move)
                                move._action_assign()

            _logger.info('transfer test : 7  -----------------------   %s', pick.id)
            return super(FTransferStockpick, self).button_validate()


class FTransfer(models.Model):
    _name = "f.stock.picking.transfer"
    _description = "Stock Picking Transfer "
    _rec_name = 'f_name'
    _inherit = ['mail.thread', 'mail.activity.mixin', 'portal.mixin']
    
    f_to_loc = fields.Many2many('stock.location',string="To Location Details")
    f_name = fields.Char("Name",readonly=True)
    f_source = fields.Char("Source Doc",readonly=True)
    f_dest = fields.Text("Destination Doc",compute="_get_dest_transfer")
    f_is_complete = fields.Selection([
            ('complete', 'Completed'),
            ('pending', 'Pending')],string="Status",default='pending', tracking=True,readonly=True,compute="_get_stateus",search="_search_state")
    
    f_storedis_complete = fields.Selection([
            ('complete', 'Completed'),
            ('pending', 'Pending')],string="Stored St",default='pending')
    
    real_product_state = fields.Selection([('process', 'In Process'), ('done', 'Done')],compute="_get_stateus", string='Real Product State', copy=False, default='process')
    f_force_validate = fields.Boolean(string='Force Complete',tracking=True)
    
  #  ,compute="_get_stateus",search="_search_state"
    
    def _search_state(self,  operator,value):
        print("in serchhhhh")
        if operator == 'like': 
            operator = 'ilike'
        print(value,"vvvvvvvvv")
        if value:
            print("1111111111111")
            recs = self.search([]).filtered(lambda x : x.f_storedis_complete == value )
            print(recs,"recsrecs")
            if recs:
                return [('id', 'in',recs.ids )]
            else:
                return [('id', '=',-1 )]
            
            
            
    def search_transfers(self):
            print("helelelelelelel")
            recs = self.search([]).filtered(lambda x : x.f_is_complete == 'pending' )
            print(recs,"recsrecs")
            return recs
           
        
        
    @api.onchange('f_force_validate')
    def change_state(self):
        print("8888822222")
        if self.f_force_validate == True:
            if self.f_is_complete != 'complete':
                self.f_is_complete = 'complete'
                self.real_product_state = 'done'
                self.f_storedis_complete = 'complete'
            
            
    
    def _get_stateus(self):
        for y in self:
            reals = self.env['f.real.icttransfer'].search([('f_name_seq','=',y.f_name),('state','=',False)],limit=1)
            if reals and y.f_force_validate != True:
                    
                    y.real_product_state = 'process'
                    y.f_is_complete = 'pending'
                    y.f_storedis_complete = 'pending'
                    
            else:
                y.real_product_state = 'done'
                y.f_is_complete = 'complete'
                y.f_storedis_complete = 'complete'
           
           # if y.f_force_validate == True:
            #    y.real_product_state = 'done'
              #  y.f_is_complete = 'complete'
           # else:
                
               # if reals:
                    
                   # y.real_product_state = 'process'
                   # y.f_is_complete = 'pending'
                    
               # else:
                   # y.real_product_state = 'done'
                 #   y.f_is_complete = 'complete'

   
                
                
    def name_get(self):
        result = []
        for x in self:
            name = x.f_name + (x.f_source and (' - ' + x.f_source) or '')
            result.append((x.id, name))
        return result
    
    
    def _get_dest_transfer(self):
        
        for x in self :
         
            picking_list = list()
            picking = self.env['stock.picking'].search([('f_transfer_id' , '=',x.id)])
            if picking:
                for z in picking:
                    picking_list.append('''%s - %s '''% (z.name,z.location_dest_id.display_name))
                    x.f_dest = '\n'.join(picking_list).strip(' + ')
                    
            else :
                x.f_dest = ''
                
    
    def _open_form_tree_view(self, action, form_view_id, tree_view_id, resource_ids):
        
        if len(resource_ids) == 1 :
            action.update({'view_id':form_view_id,
                           'res_id':resource_ids[0],
                           'view_mode': 'form'})    
        else :
            action.update({'view_id':False,
                           'view_mode': 'tree,form',
                            'views': [(tree_view_id, 'tree'), (form_view_id, 'form')]})
                            
        return action
    
                
    def f_view_sourcepickings(self):
        form_id = self.env.ref('stock.view_picking_form').id
        tree_id = self.env.ref('stock.vpicktree').id  
        picking=self.env['stock.picking'].search([('f_name_sequance','=',self.f_name)])
        
        resource_ids = picking.ids or []
        print(resource_ids,"resource_ids")

        action = {
            'name':_('Pickings'),
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'res_model': 'stock.picking',
            'domain':[('id', 'in', resource_ids)],
            }
        
        return self._open_form_tree_view(action, form_id, tree_id, resource_ids)
        
    
    

    def f_view_realproduct(self):
        real_product = self.env['f.real.icttransfer'].search([('f_name_seq','=',self.f_name)])
        print(real_product,"real_product")
        tree_id = self.env.ref('transfer_module.view_real_product_transfer').id  
        form_id = False
        resource_ids = real_product.ids or []
        action = {
            'name':_('Real Products'),
            'type': 'ir.actions.act_window',
            'view_mode': 'tree',
            'res_model': 'f.real.icttransfer',
            'domain':[('id', 'in', resource_ids)],
            }
        
        return action
    
  
 
   
class FLocationStockMoveLine(models.Model):
    _inherit = "stock.move.line"  
    
    @api.onchange('location_id') 
    def check_location_change(self):
        if self.picking_id.location_id.f_is_transet == True:
            if self.location_id.f_is_transet == True:
                print("passsss")
            else:
                raise UserError(_(
                    'From location must be Transit same as source Location ...  Please Contact Your Manager !!'))
      
                
        
       
        
        
        
        
    @api.onchange('location_dest_id') 
    def check_locationdes_change(self):
        if self.picking_id.location_dest_id.f_is_transet == True:
            if self.location_dest_id.f_is_transet == True:
                print("passsss")
            else:
                raise UserError(_(
                    'To location must be Transit same as Destination Location ...  Please Contact Your Manager !!'))
                
                
        
        
           
      
        
    
    
    
