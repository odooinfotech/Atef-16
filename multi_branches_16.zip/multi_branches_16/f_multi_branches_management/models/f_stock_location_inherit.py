from odoo import models, fields, api


class f_stock_location(models.Model):
    _inherit = 'stock.location'
    
    def _valid_field_parameter(self, field, name):
        
        return name == 'tracking' or super()._valid_field_parameter(field, name)
        
#     @api.model
#     def _get_root_location(self,location):
#         f_related_branch =-1
#         print(self)
#         print('location',location)
#         if location.location_id.name != 'Physical Locations' :
#             self._get_root_location(location.location_id)
#         else : 
#             print('In Else',location.location_id.name , location.name)
#             result = self.env['stock.warehouse'].search([('code','=',location.name )])
#             for res in result: 
#                 print('res',res.f_related_branch.id)
#                 f_related_branch = res.f_related_branch.id
#         
#                 
#         self.write({'f_related_branch':f_related_branch})
#             
# #         return f_related_branch
# #     
#     @api.model
#     def create(self, vals):
#        
#         vals['f_related_branch'] = 1
#         location = super(f_stock_location, self).create(vals)
#         
#         self._get_root_location(location)
#         
#         return location
#     
    
    
    def _get_default_branch(self):
         user_default_branch = False
         
         if self.company_id.f_allow_multi_branches ==True :  
         
             if self.env.user.company_id.f_allow_multi_branches ==True : 
                     
                 context = self._context
                 current_uid = context.get('uid')
                 print('current_uid',current_uid)
                 user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
                 if user_default_branch :
                     comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id
                     if comp == self.env.user.company_id.id :

                         self.f_related_branch  = user_default_branch
                         print('user_default_branch',user_default_branch)

                     else :
                         print(self.env.user.company_id.id)
                         branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.user.company_id.id)],limit=1)
                         print('branch',branch)
                         self.f_related_branch  = branch.id
                         user_default_branch = branch.id
                 else:
                     user_default_branch = self.env['res.users'].browse(current_uid).f_allowed_branches[0]
         return user_default_branch
    
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True,default=_get_default_branch, tracking=True)

