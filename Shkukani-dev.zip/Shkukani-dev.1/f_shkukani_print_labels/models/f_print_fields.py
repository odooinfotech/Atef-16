from odoo import models, fields, api, _


class FPrintFields(models.Model):
    _name = "f.print.fields"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Label Print Fields'
    _rec_name = 'f_field_name'

    f_field_name = fields.Char(string='Field Name', required=True)
