from . import f_sale_order_line_inherit
from . import f_purchase_order_line_inherit
from . import f_product_product_inherit
from . import f_account_move_line_inherit