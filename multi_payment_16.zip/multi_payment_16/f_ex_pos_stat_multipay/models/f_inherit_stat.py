# -*- coding: utf-8 -*-

from odoo import fields, models, api, _, tools
from datetime import datetime, timedelta, date
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT


class FinheritCustStatdetailedreport(models.TransientModel):
    _inherit = 'f.detailed.customer'


    def _multipayon_pososelect(self):
        return super(FinheritCustStatdetailedreport, self)._multipayon_pososelect()+'NULL::integer as multi_pay_id,'


  #  def _posorders_select(self):
       # return super(FinheritCustStatdetailedreport, self)._posorders_select() + ',NULL::integer as multi_pay_id'


   # def _pospayselect(self):
      # return super(FinheritCustStatdetailedreport, self)._pospayselect() + ',NULL::integer as multi_pay_id'


    def _multi_payselect(self):
        return super(FinheritCustStatdetailedreport, self)._multi_payselect() + ',NULL::integer as order_id,NULL::integer as payment_method_id,NULL::integer as payment_pos_id,NULL::integer as session_id,NULL::integer as config_id'
