from odoo import models, fields, api, _


class FProductAttributeInherit(models.Model):
    _inherit = 'product.attribute'

    f_type = fields.Selection([('color', 'Color'), ('size', 'Size')], string='Type')