from odoo import models, fields, api, _
from datetime import datetime, timedelta,date
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT

class AccountMoveLine(models.Model):
    _inherit = "account.move.line"

    maturity_date_ref = fields.Char('Maturity Date Ref')
    action_type       = fields.Char('check Action')
    f_payment_id = fields.Many2one('account.payment', string = 'Related Payment')
    f_bulk_action_seq = fields.Char('Bulk Seq #')
    
class AccountMove(models.Model):
    _inherit = "account.move"

    f_bulk_action_seq = fields.Char('Bulk Seq #')
    f_payment_id = fields.Many2one('account.payment', string = 'Related Payment')
    check_number = fields.Char(string='Check Number',readonly = True)
    returned_check_id = fields.Many2one(
        'account.payment','Source Check Payment' , readonly = True)

    # commented in17022023 no need for it oin odoo16
    # @api.constrains('line_ids', 'journal_id')
    # def _validate_move_modification(self):
    #     print('_validate_move_modification')
    #     if 'posted' in self.mapped('line_ids.payment_id.state') and 'cancelled' in self.mapped('line_ids.payment_id.check_state'):
    #         raise ValidationError(_("You cannot modify a journal entry linked to a posted payment."))
