# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class f_check_pos_branch_ex(models.Model):
#     _name = 'f_check_pos_branch_ex.f_check_pos_branch_ex'
#     _description = 'f_check_pos_branch_ex.f_check_pos_branch_ex'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
