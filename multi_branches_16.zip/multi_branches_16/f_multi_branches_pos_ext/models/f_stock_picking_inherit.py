from odoo import models, fields, api

class f_stock_picking(models.Model):
    _inherit = 'stock.picking'
    
    #To Set the branch ii picking for POS Orders
    @api.model
    def _create_picking_from_pos_order_lines(self, location_dest_id, lines, picking_type, partner=False):
        
        
        pickings = super(f_stock_picking, self)._create_picking_from_pos_order_lines(location_dest_id, lines, picking_type, partner)
        print('_create_picking_from_pos_order_lines',pickings)
        pickings.write({'f_related_branch':lines[0].order_id.f_related_branch})
        return pickings
    