from odoo import models, fields, api

## Inherit res.partner model and add new three fields to it 
class FResPartnerInherit(models.Model):
      
    _inherit = 'res.partner'
    
    
    
    @api.onchange('company_id')
    def get_branches_domain_by_comp(self):
        if self.company_id:
        
                    branch_ids= []
                    branches=self.env['f.comp.branches'].search([('company_id' , '=', self.company_id.id )]) 
                    for rec in branches :
                        branch_ids.append(rec.id)
                    domain_on_types=[('id' ,'in',branch_ids)]
                    return {'domain': {'f_related_branch': domain_on_types}}



    def get_branches_domain(self):
        if self.env.company:
            branch_ids= []
            branches=self.env['f.comp.branches'].search([('company_id' , '=', self.env.company.id)]) 
            for rec in branches :
                branch_ids.append(rec.id)
            domain_on_types=[('id' ,'in',branch_ids)]
            return domain_on_types

            
        
       
        
        
        
      
        
        
    
    f_related_branch   = fields.Many2one('f.comp.branches' , string = 'Branch', tracking=True,domain=get_branches_domain)



