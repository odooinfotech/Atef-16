from odoo import models, fields, api, _
from datetime import datetime, timedelta,date
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from odoo.osv import expression

class FResBankInherit(models.Model):
    _inherit = 'res.bank'
    f_branchs = fields.One2many('f.bank.branch','bank_id','Branchs')
    def _default_compnay(self):
        self.company_id = self.env.company.id
        return self.env.company.id
    
    company_id = fields.Many2one('res.company', string = 'Company' , default = _default_compnay)
	
    
class FBankBranch(models.Model):
    _name= 'f.bank.branch'
    _description = "Bank Branches"
    _rec_name = 'f_branch_name'

    f_branch_name = fields.Char(string="Branch Name", required=True)
    f_branch_name_id = fields.Char('Branch Code', index=True)
    bank_id = fields.Many2one('res.bank', string='Bank', required=True)
    f_branch_address = fields.Char(string='Branch Address')
    f_branch_phone = fields.Char(string='Phone')
    company_id = fields.Many2one('res.company', related='bank_id.company_id',string='Company')
    
    
    
    def name_get(self):
        result = []
        for branch in self:
            name = branch.f_branch_name + (branch.f_branch_name_id and (' - ' + branch.f_branch_name_id) or '')
            result.append((branch.id, name))
        return result
    
    
    @api.model
    def _name_search(self, name, args=None, operator='ilike', limit=100, name_get_uid=None):
        args = args or []
        domain = []
        if name:
            domain = ['|', ('f_branch_name_id', 'ilike', name + '%'), ('f_branch_name', operator, name)]
            if operator in expression.NEGATIVE_TERM_OPERATORS:
                domain = ['&'] + domain
        return self._search(domain + args, limit=limit, access_rights_uid=name_get_uid)


#For Legacy Usage
class FBankCustom(models.Model):
    _name = 'f.bank.conf'
    _description = "Bank Info"

    f_branch_name = fields.Char(string="Branch Name")
    f_branch_name_id = fields.Char('Branch ID', index=True)
    bank_id = fields.Integer("ID")

