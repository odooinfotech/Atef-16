# -*- coding: utf-8 -*-



from odoo import api, fields, models, _



class PosSession(models.Model):
    _inherit = 'pos.session'


    def _product_pricelist_item_fields(self):
        res = super()._product_pricelist_item_fields()
        res.extend(
            ['f_section','f_group','f_brand','f_season','f_article'])
        return res

    def _loader_params_product_product(self):
        res = super()._loader_params_product_product()
        res.get('search_params').get('fields').extend(
                ['f_section','f_group','f_brand','f_season','f_article'])
        return res







