from odoo import models

class LoyaltyCard(models.Model):
    _inherit = 'loyalty.card'

