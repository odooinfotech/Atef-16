# -*- coding: utf-8 -*-

from . import f_product_group
from . import f_product_section
from . import f_article_category
from . import f_collection_trend
from . import f_product_template_inherit
from . import f_product_product_inherit
from . import f_stock_move_inherit
from . import f_stock_move_line_inherit
from . import f_gen_sale_wizard_inherit
from . import f_account_report
from . import f_purcashe_report_inherit
