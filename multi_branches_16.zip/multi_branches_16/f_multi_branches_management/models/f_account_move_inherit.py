from odoo import models, fields, api

class f_account_move(models.Model):
    _inherit = 'account.move'

    @api.model
    def create(self, vals):
        res = super(f_account_move, self).create(vals)
        if self.env.company.f_default_partner_branch:
            if res.partner_id.f_related_branch:
                res.update({
                    'f_related_branch': res.partner_id.f_related_branch.id or False
                })
            else:
                res.update({
                    'f_related_branch': self.env.user.f_default_branch.id or False
                })



        return res




    def write(self,vals):
        if self.env.company.f_default_partner_branch:
                if 'partner_id' in vals :
                    partner =self.sudo().env['res.partner'].sudo().search([('id', '=', vals['partner_id'])], limit=1)
                    if partner.f_related_branch :
                        vals['f_related_branch'] = partner.f_related_branch.id
                    else:
                        vals['f_related_branch'] = self.env.user.f_default_branch.id


        return super(f_account_move,self).write(vals)





    def _get_default_branch(self):
         user_default_branch = False
         if self.env.company.f_allow_multi_branches ==True :

             if self.env.company.f_allow_multi_branches ==True :

                 print(self.new)   
                 context = self._context
                 current_uid =context.get('uid') or self.env.user.id
                 print('current_uid',current_uid)
                 user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
                 if user_default_branch :
                     comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id

                     if not self.f_related_branch :
                         if comp == self.env.company.id :
                             self.f_related_branch  = user_default_branch
                             print('user_default_branch',user_default_branch)
                         else :
                             print(self.env.user.company_id.id)
                             branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.company.id)],limit=1)
                             print('branch',branch)
                             self.f_related_branch  = branch.id
                             user_default_branch = branch.id
                 else :
                     user_default_branch = self.env['res.users'].browse(current_uid).f_allowed_branches[0]

         return user_default_branch
    
    
    f_related_branch     = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, default=_get_default_branch, tracking=True)
    f_is_multi_branch    = fields.Boolean(related='company_id.f_allow_multi_branches')
    f_partner_branch_id  = fields.Many2one('f.comp.branches',related = 'partner_id.f_related_branch',string = 'Partner Branch',store=True)
    
    
    #OVERRIDE _post to update  branch to the created asset 
    def _post(self, soft=True):
        
        posted = super()._post(soft)
        print('posted',posted)
        for asset in posted.asset_ids :
            asset.write({'f_related_branch':posted.f_related_branch})
            print('asset', asset)
            
            asset_moves = self.env['account.move'].search([('asset_id','=',asset.id),('state','!=','posted')])  
            print('asset_moves',asset_moves)
            for move in asset_moves :
                move.write({'f_related_branch':self.f_related_branch})
        return posted

    


class f_account_move_line(models.Model):
    _inherit = 'account.move.line'
    
#     def _get_default_branch(self):
#          print(self.new)   
#          context = self._context
#          current_uid = context.get('uid')
#          print('current_uid',current_uid)
#          user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
#          comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id
#          
#          if not self.f_related_branch :                 
#              if comp == self.env.user.company_id.id : 
#                  self.f_related_branch  = user_default_branch
#                  print('user_default_branch',user_default_branch)
#              else : 
#                  print(self.env.user.company_id.id)
#                  branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.user.company_id.id)],limit=1)
#                  print('branch',branch)
#                  self.f_related_branch  = branch.id
#                  user_default_branch = branch.id
#                     
#          return user_default_branch
#     
    
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, related = 'move_id.f_related_branch',store =True)
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')


