# -*- coding: utf-8 -*-
{
    'name': "Falak Shkukani Inventory Custom",

    'summary': """ This Module For Shkukani Inventory Customizations""",

    'description': """
        Add Fields:
            Article Number: Product.template & product.product related (views, search & reports) => POS Order => POS Report
            Season: Product.template & product.product related
            Product Index: product.product => artical+season+color+size => make sure it possible to use it in POS search either no need for this field
            Section: Product.template & product.product related
            Taric: product.product
            Group: Product.template & product.product related
            Article Category: Product.template & product.product related
            HS Code: Product.template & product.product related
            Textile Composition: Product.template & product.product related
            Family: Product.template & product.product related
            Sim: Product.template & product.product related
            Brand: Product.template & product.product related
            Gander: Product.template & product.product related
            index: product.product
            Collection Trend: product.product
    """,

    'author': "Falak Solutions",
    #'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['base','stock','product','bi_import_img_from_zip','account','purchase','f_shkukani_contact_custom'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/f_product_group.xml',
        'views/f_product_section.xml',
        'views/f_article_category.xml',
        'views/f_collection_trend.xml',
        'views/f_product_template_inherit.xml',
        'views/f_stock_move_form_inherit.xml',
        'views/f_stock_move_line_inherit.xml',
        'views/f_gen_sale_wizard_inherit.xml',
        'security/ir_rule.xml',
    ],

}
