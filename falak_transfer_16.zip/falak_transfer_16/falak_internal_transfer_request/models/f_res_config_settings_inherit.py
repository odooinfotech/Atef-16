from odoo import models, fields, api,_

## inherit res.config.settings model and add new two fields to it
class FResConfigSettings(models.TransientModel):
      _inherit = 'res.config.settings'
      
      f_operation_type = fields.Many2one('stock.picking.type' , string="Shipment Operation Type")
      f_main_location = fields.Many2one('stock.location', domain="[('usage', '=', 'internal')]",string="Main Location") 
      
## Set values of Shipment operation type and Main location      
      def set_values(self):
        super(FResConfigSettings, self).set_values()
        config_parameters = self.env["ir.config_parameter"].sudo()
        operation_type = self.f_operation_type and self.f_operation_type.id or False
        main_location = self.f_main_location and self.f_main_location.id or False        
        config_parameters.sudo().set_param("falak_internal_transfer_request.f_operation_type", operation_type)
        config_parameters.sudo().set_param("falak_internal_transfer_request.f_main_location", main_location)
        
        
        
## Get the values of shipment operation type and Main location
      def get_values(self):
        res = super(FResConfigSettings, self).get_values()
        f_operation_type = self.env['ir.config_parameter'].sudo().get_param('falak_internal_transfer_request.f_operation_type')
        f_main_location = self.env['ir.config_parameter'].sudo().get_param('falak_internal_transfer_request.f_main_location')
        res.update(
            f_operation_type = int(f_operation_type),
            f_main_location = int(f_main_location),
        )
        return res