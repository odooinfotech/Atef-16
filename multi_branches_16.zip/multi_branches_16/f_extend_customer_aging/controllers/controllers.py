# -*- coding: utf-8 -*-
# from odoo import http


# class FExtendCustomerAging(http.Controller):
#     @http.route('/f_extend_customer_aging/f_extend_customer_aging/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/f_extend_customer_aging/f_extend_customer_aging/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('f_extend_customer_aging.listing', {
#             'root': '/f_extend_customer_aging/f_extend_customer_aging',
#             'objects': http.request.env['f_extend_customer_aging.f_extend_customer_aging'].search([]),
#         })

#     @http.route('/f_extend_customer_aging/f_extend_customer_aging/objects/<model("f_extend_customer_aging.f_extend_customer_aging"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('f_extend_customer_aging.object', {
#             'object': obj
#         })
