from odoo import models, fields, api, _


class FArticleCategory(models.Model):
    _name = 'f.article.category'
    _description = 'Article Category'
    _rec_name = 'f_name'

    f_name = fields.Char(string='Name')
