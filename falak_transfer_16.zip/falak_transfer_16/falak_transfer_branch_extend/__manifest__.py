# -*- coding: utf-8 -*-
{
    'name': "Falak Internal Transfer Branch ",

    'summary': """
        This Module is used to set the Branch Value in the internal transfers
        """,

    'description': """
        This Module is used to set the Branch Value in the internal transfers receiving 
        
        - The Receiving will get the to location related branch  
        
    """,

    'author': "Falak Solutions",
    'license': 'LGPL-3',
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','stock','transfer_module','f_multi_branches_management'],

    # always loaded
    'data': [  ],
    # only loaded in demonstration mode
    'demo': [ ],
}
