from odoo import models, fields, api, _


class FBarcodeDesign(models.Model):
    _name = "f.barcode.design"
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = 'Barcode Design'
    _rec_name = 'f_name'

    f_name = fields.Char(string='Name', required=True)
    f_size = fields.Many2one('report.paperformat', string='Size')
    f_fields = fields.Many2many('f.print.fields', string='Fields')
