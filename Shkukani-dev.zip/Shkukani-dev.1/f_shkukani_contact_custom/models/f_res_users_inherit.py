from odoo import models, fields, api, _


class FResUsersInherit(models.Model):
    _inherit = 'res.users'

    f_contact_brand_ids = fields.Many2many('f.contact.brand', string='Contact Brand')
