
from . import f_inherit_partner
from . import f_check_wizard_inherit
from . import f_account_payment_inherit
from . import f_multi_payment_inherit
from . import f_bulk_check_inherit
