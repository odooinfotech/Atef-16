from odoo import models, fields, api, _
from datetime import datetime, timedelta, date
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT


class FAccountPayment(models.Model):
    _inherit = 'account.payment'
    _description = "Account Payment"
    
    f_seq_num_checks= fields.Integer('Check Seq')

    f_legacy_move = fields.Many2one("account.move",string="Legacy Move Id")

    f_check_image_front = fields.Image(string="Check Image Front")
    f_check_image_back = fields.Image(string="Check Image Back")

    f_am_lines = fields.One2many('account.move.line','f_payment_id', string='Check Journal Items')


    f_bulk_action_ids = fields.Many2many('f.bulk.checks', string='Bulk Actions')
    # This Function is overwritten to stop changing
    # the check number at changing journal or partner
    @api.depends('journal_id', 'payment_method_code')
    def _compute_check_number(self):
        for pay in self:
            pay.check_number = pay.check_number

    @api.constrains('amount')
    def _check_amount(self):
        for payment in self:
            if payment.amount == 0.0:
                raise ValidationError(_('Amount should not be Zero'))


    # Cheque Payment Details Fields
    returned_check_invoice = fields.Many2one(
        'account.move', 'Returned Check Invoice', readonly=True)
    check_details = fields.Boolean('Check Payment', related='journal_id.check_details', store=True)
    payment_method_code = fields.Char('Payment Method', related='payment_method_line_id.payment_method_id.code',
                                      store=True)
    journal_type = fields.Selection( 'Journal Type', related='journal_id.type', store=True, readonly=True)

    bank_id = fields.Many2one('res.bank', string="Bank", tracking=True)
    branch_id = fields.Many2one('f.bank.branch', string="Branch", tracking=True , domain="[('bank_id','=',bank_id)]")
    #Legacy Usage
    #branch_id = fields.Many2one('f.bank.conf', string="Branch", tracking=True)
    #legacy_branch_id = fields.Many2one('f.bank.conf', string="Branch", tracking=True)
    account_number = fields.Char('Account Number')

    # Check_transfer
    f_current_journal = fields.Many2one('account.journal', 'Current-Journal', readonly=True, tracking=True)
    transfer_date = fields.Date(string="Transfer Date", readonly=True, tracking=True)

    f_ex_fromcheck= fields.Boolean('Exclude from check Duplication',default=False)


    f_ret_note = fields.Char('Return Check Reason')


    due_date = fields.Date(string='Check Due Date', tracking=True)
    check_number = fields.Char(string='Check Number', tracking=True, readonly=False)
    check_state = fields.Selection(
        selection=[
            ('draft', 'Draft'),
            ('in_check_box', 'In Check Box'),
            ('under_collection', 'under collection'),
            ('collected', 'Collected'),
            ('returned', 'Returned'),
            ('bounced', 'Bounced'),
            ('cancelled', 'Cancelled'),
            ('issued', 'Issued'),
            ('released', 'Released'),
            ('endorsed', 'Endorsed')],
        string='Check State', default='draft', readonly=True, tracking=True)

    check_comments = fields.Text(string='Comments')

    deposit_date = fields.Date(string="Deposit Date", readonly=True, tracking=True)
    undeposit_date = fields.Date(string="Undeposit Date", readonly=True, tracking=True)
    collection_date = fields.Date(string="Collection Date", readonly=True, tracking=True)
    deposit_collect_bank = fields.Many2one('account.journal', 'Deposit/Collect/Release Bank Account', readonly=True,
                                           tracking=True)
    bounce_date = fields.Date(string="Bounce Date", readonly=True, tracking=True)
    return_date = fields.Date(string="Return Date", readonly=True, tracking=True)

    uncollect_date = fields.Date(string="Uncollect Date", readonly=True, tracking=True)


    endorse_date = fields.Date(string="Endorse Date", readonly=True, tracking=True)
    unendorse_date = fields.Date(string="Unendorse Date", readonly=True, tracking=True)
    release_date = fields.Date(string="Release Date", readonly=True, tracking=True)
    source_payment = fields.Many2one('account.payment', 'Source Payment', readonly=True, tracking=True)
    source_payment_partner = fields.Many2one(related='source_payment.partner_id', string='Source Payment Partner')
    des_payment = fields.Many2one('account.payment', 'Supplier Payment', readonly=True, tracking=True)

    bounced_check_received = fields.Boolean('Bounced Check Received')
    bounced_check_returned_to_customer = fields.Boolean('Bounced Check Returned To Customer ')
    f_responsible_emp = fields.Many2one('hr.employee', 'Responsible Employee',
                                        default=lambda self: self.env.user.employee_ids.id, tracking=True)
    f_received_in_hq = fields.Boolean('Received In HQ')

    def write(self, vals):
        if 'check_number' in vals:
            check_number = vals.get('check_number')
            if check_number and not check_number.isdigit():
                raise ValidationError("Check Number should contain only numeric values.")
        return super(FAccountPayment, self).write(vals)


    #Commented in17022023 and added in default parameter in field definition
    # Override by falak
    # def write(self, vals):
    #     print('write')
    #     if not self.f_current_journal:
    #         vals['f_current_journal'] = self.journal_id.id
    #     res = super().write(vals)
    #     return res

    def _get_valid_liquidity_accounts(self):
        print('Call Function _get_valid_liquidity_accounts')
        result = super()._get_valid_liquidity_accounts()
        return (result |
                self.journal_id.outward_checks_account |
                self.f_current_journal.default_account_id |
                self.f_current_journal.company_id.account_journal_payment_debit_account_id |
                self.f_current_journal.company_id.account_journal_payment_credit_account_id |
                self.f_current_journal.inbound_payment_method_line_ids.payment_account_id |
                self.f_current_journal.outbound_payment_method_line_ids.payment_account_id |
                self.f_current_journal.outward_checks_account)

    ############################################################
    # Commented in17022023  since no nedd for this Function in odoo16
    # # Override by falak
    # def _prepare_move_line_default_vals(self, write_off_line_vals=None):
    #     print('55555555')
    #     line_vals_list = super(FAccountPayment, self)._prepare_move_line_default_vals(write_off_line_vals)
    #     for rec in line_vals_list:
    #         acc_id = self.env['account.account'].search([('id', '=', rec['account_id'])])
    #         if self.payment_type == 'outbound' and self.payment_method_code == 'check_printing' and self.journal_id.f_without_statement:
    #             # print('in if 11')
    #             if acc_id.id in (self.company_id.account_journal_payment_debit_account_id.id,
    #                              self.f_current_journal.company_id.account_journal_payment_credit_account_id.id):
    #                 rec['account_id'] = self.journal_id.outward_checks_account.id
    #                 # print('in if ')
    #
    #         elif self.journal_id.f_without_statement:
    #
    #             print('acc_id', acc_id, acc_id.account_type)
    #             if acc_id.id in (self.company_id.account_journal_payment_debit_account_id.id,
    #                              self.f_current_journal.company_id.account_journal_payment_credit_account_id.id):
    #                 rec['account_id'] = self.journal_id.default_account_id.id
    #
    #     # print('line_vals_list after update', line_vals_list)
    #     return line_vals_list

    def button_journal_entries(self):
        print('self.ids', self.ids)
        return {
            'name': _('Journal Items'),
            'view_mode': 'tree,form',
            'res_model': 'account.move.line',
            'view_id': False,
            'type': 'ir.actions.act_window',
            'domain': ['|', ('f_payment_id', 'in', self.ids), ('payment_id', 'in', self.ids)],
        }

    @api.onchange('journal_id', 'payment_type')
    def _onchange_journl_id(self):
        print('_onchange_journl_id')
        self.f_current_journal = self.journal_id.id

        self.payment_method_line_id = False
        if self.payment_type=='outbound' and not self.journal_id.check_details:
            for method_id in self.journal_id.outbound_payment_method_line_ids.filtered(lambda l : l.payment_method_id.code == 'manual'):
                self.payment_method_line_id =method_id.id
                
        if self.payment_type=='outbound' and self.journal_id.check_details:
            for method_id in self.journal_id.outbound_payment_method_line_ids.filtered(lambda l : l.payment_method_id.code != 'manual'):
                self.payment_method_line_id =method_id.id

            self.account_number = False
            self.bank_id = False
            self.branch_id = False
            self.check_number = False
            self.due_date = False
            self.check_state = False
            self.check_comments = False


    #commented in17022023 and added af field domain
    # @api.onchange('bank_id')
    # def _onchange_bank_id(self):
    #     branchs = self.env['f.bank.branch'].search([('bank_id', '=', self.bank_id.id)])
    #     domain_on_types = [('bank_id', '=', self.bank_id.id)]
    #     print('In _onchange_bank_id')
    #     return {'domain': {'branch_id': domain_on_types}}

    @api.onchange('due_date')
    def _onchange_check_due_date(self):
        res = self.validate_check_due_date()
        print('_onchange_check_due_date')
        payment_id = self._origin.id
        move_lines = self.env['account.move.line'].sudo().search(
            [('payment_id', '!=', False), ('payment_id', '=', payment_id),
             ('maturity_date_ref', 'in', ('current_payment.due_date', 'self.due_date'))])
        for line in move_lines:
            line.write({'date_maturity': self.due_date})
        if res:
            return res


    def return_bounced(self):
        print('return_bounced')
        return self.write({'bounced_check_received': True})

    def unreturn_bounced(self):
        print('unreturn_bounced')
        return self.write({'bounced_check_received': False})

    ##@api.multi
    def action_draft(self):
        # print('In Custom Draft')
        if self.check_state == 'endorsed' :
            if self.des_payment :
                if  self.des_payment.check_state == 'released':
                    raise ValidationError("There is a supplier payment related to this payment ")

        super(FAccountPayment, self).action_draft()
        moves = self.env['account.move'].search([('f_payment_id', '=', self.id), ('state', '!=', 'cancel')])
        print('moves', moves)

        for m in moves:
            print('m', m.line_ids)
            if m.id == self.move_id.id :
                m.button_draft()
            # Updated by shireen to stop depending on action type
            # if m.line_ids[0].action_type == 'confirm' or m.line_ids[0].action_type == False:
            #     m.button_draft()
            else:
                print('In elseee')
                m.button_cancel()

        return self.write({'state': 'draft', 'check_state': 'draft','f_current_journal':self.journal_id.id})

    def action_cancel(self):
        print('In Custom Cancel', self.id)
        if self:
            print('In Custom Cancel', self.id)
            ''' draft -> cancelled '''
            super(FAccountPayment, self).action_cancel()

            moves = self.env['account.move'].search([('f_payment_id', '=', self.id)])
            for m in moves:
                # print('state',m.state,'m.id',m.id)
                m.button_cancel()
                # m.unlink()
            self.write({'state': 'cancel', 'check_state': 'cancelled'})

    def action_post(self):

        # Validation on Check Due Date if the feature is enabled .
        res = self.validate_check_due_date() or False
        for rec in self:
            super(FAccountPayment, rec).action_post()
            print('rec.id>>>>>>>', rec.id)
            if rec.ref != False:
                ref = 'Confirm' + '/' + str(rec.check_number) + '/' + str(rec.ref)
            else:
                ref = 'Confirm' + '/' + str(rec.check_number)
            if rec.journal_id.check_details == True or rec.payment_method_code == 'check_printing':
                print(rec.payment_type)

                if rec.payment_type == 'inbound':
                    print('payment_type ', rec.payment_type)
                    rec.write({'check_state': 'in_check_box'})
                    print('Payment_id ', rec.id)
                    move_lines = rec.env['account.move.line'].search(
                        [('payment_id', '=', rec.id), ('action_type', '=', False)], order='create_date desc', limit=2)
                    print('move_lines ', move_lines)
                    for line in move_lines:
                        if line.credit == 0:
                            # line.name.startswith("Customer Payment") or  line.name.startswith( "سداد الزبون" ):
                            # if line.name == 'Customer Payment' :
                            line.write(
                                {'date_maturity': rec.date, 'maturity_date_ref': 'self.date', 'action_type': 'confirm',
                                 'ref': ref, 'f_payment_id': rec.id})
                        else:
                            line.write({'date_maturity': rec.due_date, 'maturity_date_ref': 'self.due_date',
                                        'action_type': 'confirm', 'ref': ref, 'f_payment_id': rec.id})

                elif rec.payment_type == 'outbound':
                    print('payment_type ', rec.payment_type)
                    rec.write({'check_state': 'issued'})
                    #This Condition is added to Change the status of the vendor payment from endorce action to released directly
                    if rec.source_payment :
                        rec.write({'check_state': 'released','release_date' : rec.date})


                    print('Payment_id ', rec.id)
                    move_lines = rec.env['account.move.line'].search(
                        [('payment_id', '=', rec.id), ('action_type', '=', False)], order='create_date desc', limit=2)
                    print('move_lines ', move_lines)
                    for line in move_lines:
                        print('Tesetttttt', line.name.startswith("Vendor Payment"))
                        if line.credit == 0:
                            line.write(
                                {'date_maturity': rec.date, 'maturity_date_ref': 'self.date', 'action_type': 'confirm',
                                 'ref': ref, 'f_payment_id': rec.id})
                        else:
                            if rec.journal_id.outward_checks_account.id == False:
                                raise UserError('Outward Check Account is Empty in journal Definition ! ')
                            line.write({'date_maturity': rec.due_date, 'maturity_date_ref': 'self.due_date',
                                        'action_type': 'confirm', 'ref': ref, 'f_payment_id': rec.id})
            #rec.write({'state': 'posted'})
           # rec.f_current_journal = rec.journal_id.id
        if res :
            return res
        else:
            return True

    def validate_check_due_date(self):
           # self.restrict_check_due_date()
            for rec in self:
                if rec.due_date:
                    check_due_date = rec.due_date
                    today = date.today()

                    block_before = today - timedelta(days=int(self.env['ir.config_parameter'].sudo().get_param(
            'check_management.f_check_due_block_period')))
                    warn_before = today - timedelta(days=int(self.env['ir.config_parameter'].sudo().get_param(
            'check_management.f_check_due_warn_period')))

                    due_date_limit = today + timedelta(days=int(self.env['ir.config_parameter'].sudo().get_param(
            'check_management.f_due_date_limit_period')))

                    if rec.payment_type == 'inbound' and not rec.env.user.has_group(
                            'check_management.f_bypass_check_due_date_res') and self.env['ir.config_parameter'].sudo().get_param(
            'check_management.f_set_due_date_limit') and int(self.env['ir.config_parameter'].sudo().get_param(

            'check_management.f_due_date_limit_period'))!= 0 and check_due_date >= due_date_limit:
                        # raise UserError(
                        #     'Check Due Date Should Not Exceed  ' + str(due_date_limit))
                        return {'warning': {
                            'title': _('Warning'),
                            'message': _('Check Due Date Should Not Exceed  ' + str(due_date_limit))
                        }}

                    if rec.payment_type == 'inbound' and not rec.env.user.has_group(
                            'check_management.f_bypass_check_due_date_res') and self.env['ir.config_parameter'].sudo().get_param(
            'check_management.f_restrict_check_due_date') and int(self.env['ir.config_parameter'].sudo().get_param(
            'check_management.f_check_due_block_period')) != 0 and check_due_date <= block_before:
                        raise UserError(
                            'Check Due Date Should Not Be before  ' + str(block_before))
                    if rec.payment_type == 'inbound' and not rec.env.user.has_group(
                            'check_management.f_bypass_check_due_date_res') and self.env['ir.config_parameter'].sudo().get_param(
            'check_management.f_warn_check_due_date') and int(self.env['ir.config_parameter'].sudo().get_param(
            'check_management.f_check_due_warn_period')) != 0 and warn_before >= check_due_date:
                        print('0000000000000000000000000000000000000000000000000000000000000000000000')
                        return {'warning': {
                                'title': _('Warning'),
                                'message': _('Check Due Date Should Not be before  ' + str(warn_before))
                                            }}


    @api.constrains('check_number', 'journal_id','account_number','bank_id')
    def _constrains_check_number_unique(self):
        payment_checks = self.filtered('check_number')

        if not payment_checks:
            return


        duplicate_checks = list()
        duplicate_checks_txt = ''
        
        
        
        for payment_check in payment_checks:
                check_ids = []
                account_ids= []
                banks_ids =[]
                pay_types = []
            #if payment_check.payment_type == 'inbound':
                check_ids.append(payment_check.check_number)
                if payment_check.account_number :
                    account_ids.append(payment_check.account_number)
                if payment_check.bank_id :
                    banks_ids.append(payment_check.bank_id.id)
                pay_types.append(payment_check.payment_type)



              #  _logger.info('checksssss %s',check_ids)

                if not payment_check.check_number.isdecimal():
                    raise ValidationError(_('Check numbers can only consist of digits'))

                query_base = """
                    SELECT payment.check_number, move.journal_id
                    FROM account_payment payment
                    JOIN account_move move ON move.id = payment.move_id
                    JOIN account_journal journal ON journal.id = move.journal_id,
                    account_payment other_payment
                    JOIN account_move other_move ON other_move.id = other_payment.move_id
                    WHERE payment.id != other_payment.id
                    and move.company_id = %s
                    and other_move.company_id = %s
                    AND payment.id IN %s
                    AND other_move.state = 'posted'
                    AND payment.check_number IS NOT NULL
                    AND other_payment.check_number IS NOT NULL
                    AND (payment.bank_id IS NOT NULL AND other_payment.bank_id IS NOT NULL)
                    AND other_payment.check_state NOT IN ('returned', 'endorsed')
                   AND  COALESCE(other_payment.f_ex_fromcheck,FALSE) = FALSE 
              
                 
                
                """
                conditions = []
                params = [self.env.company.id, self.env.company.id, tuple(payment_checks.ids)]
                
                if check_ids:
                    conditions.append("other_payment.check_number IN %s")
                    params.append(tuple(check_ids))
                if banks_ids:
                    conditions.append("other_payment.bank_id IN %s")
                    params.append(tuple(banks_ids))
                if account_ids:
                    conditions.append("other_payment.account_number IN %s")
                    params.append(tuple(account_ids))
                if pay_types:
                    conditions.append("other_payment.payment_type IN %s  ")
                    params.append(tuple(pay_types))
                
                if conditions:
                    query_base += " AND " + " AND ".join(conditions)
                
                self.env.cr.execute(query_base, params)
                
        
                res = self.env.cr.dictfetchall()
               # _logger.info('ressssssssssssssssssssssssssssssss %s',res)
                for r in res :
                    duplicate_checks.append('''Check :  %s , Journal :  %s'''% (r['check_number'], self.env['account.journal'].browse(r['journal_id']).display_name))

    
        if  len(duplicate_checks) > 0 :
            duplicate_checks_txt = '\n'.join(duplicate_checks).strip(' + ')
            raise ValidationError(_(  '  The following numbers are already used:\n%s',duplicate_checks_txt
                                   
            ))
            
                

        # if res:
        #     raise ValidationError(_(
        #         '  The following numbers are already used:\n%s',
        #         '\n'.join(_(
        #             '%(number)s in journal %(journal)s',
        #             number=r['check_number'],
        #             journal=self.env['account.journal'].browse(r['journal_id']).display_name,
        #         ) for r in res)
        #     ))
    @api.constrains('payment_method_code', 'check_number', 'journal_id', 'account_number')
    def _f_check_account_num(self):
        if self.env['ir.config_parameter'].sudo().get_param('check_management.f_required_account'):
            for rec in self:
                if rec.journal_id.check_details and rec.payment_type == 'inbound' :
                    if rec.account_number == False:
                        raise ValidationError(_("Required Account Number"))
