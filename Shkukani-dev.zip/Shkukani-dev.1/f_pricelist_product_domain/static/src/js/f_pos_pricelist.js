odoo.define('f_pricelist_product_domain_pos_ex.f_pos_pricelist', function(require) {
    "use strict";

    var {Product }  = require('point_of_sale.models');
    const Registries = require('point_of_sale.Registries');


    const FPriclistProduct= (Product) =>
    class extends Product {




    isPricelistItemUsable(item, date) {


        var f_section = [];
        f_section.push(this.f_section[0]);

        var f_group = [];
        f_group.push(this.f_group[0]);





        return (
            (!item.categ_id || _.contains(this.parent_category_ids.concat(this.categ.id), item.categ_id[0])) &&
            (!item.date_start || moment.utc(item.date_start).isSameOrBefore(date)) &&
            (!item.date_end || moment.utc(item.date_end).isSameOrAfter(date)) &&
            (!item.f_section || _.contains(item.f_section, f_section[0]))&&
            (!item.f_group|| _.contains(item.f_group, f_group[0]))&&
            (!item.f_brand|| (item.f_brand == this.f_brand))&&
            (!item.f_season|| (item.f_season == this.f_season))&&
            (!item.f_article|| (item.f_article == this.f_article))
        );
    }


     }
    Registries.Model.extend(Product, FPriclistProduct);














});