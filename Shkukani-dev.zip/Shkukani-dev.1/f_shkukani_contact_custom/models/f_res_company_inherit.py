from odoo import models, fields, api, _


class FResCompanyInherit(models.Model):
    _inherit = 'res.company'

    @api.model_create_multi
    def create(self, vals_list):
        results = super(FResCompanyInherit, self).create(vals_list)
        for res in results:
            partner = res.partner_id
            partner.write({"company_id": res.id})
        return results