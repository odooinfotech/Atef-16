from odoo import models, api


class FProductLabelReport(models.AbstractModel):
    _name = 'report.f_shkukani_print_labels.f_product_label_custom_template'

    @api.model
    def _get_report_values(self, docids, data=None):
        records = self.env['f.product.copies'].browse(docids)
        print("////////////////////////////// ",docids)
        copies = records.filtered(lambda record: not record.f_printed and record.f_copy > 0)
        number_of_label = 0
        copy_records = self.env['f.product.copies']
        for record in copies:
            if number_of_label + record.f_copy < 300:
                number_of_label += record.f_copy
                copy_records |= record
            else:
                break
        return {
            'docs': copy_records,
        }