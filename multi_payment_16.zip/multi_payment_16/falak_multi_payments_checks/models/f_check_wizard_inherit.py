from odoo import models, fields, api, _
import itertools
class FChequeWizardInerit(models.TransientModel):
    _inherit = 'cheque.wizard'

    def create_repay_payment(self,vals):
        return True

    def repay_prepare_payment_vals(self,current_payment,account_repay):
        prepared_vals = super(FChequeWizardInerit, self).repay_prepare_payment_vals(
            current_payment,account_repay)

        lines = []
        lines.append((0, 0, prepared_vals))

        multi_payment = self.env['f.multi.payments']
        multi_payment_vals = {
            'f_payment_type': 'inbound',
            'f_partner_type': 'customer',
            'f_partner_id': current_payment.partner_id.id,
            'f_payment_date': self.action_date,
            'f_payment_lines': lines,
            'f_destination_account_id': account_repay
        }

        multi_payment = multi_payment.create(multi_payment_vals)
        multi_payment.f_post_payment()
    
    
    def create_endorse_supplier_payment (self,vals):
        #This function is overritten to stop creating the payment since it is already 
        #created in the prepare_endorse_payment_vals function
        # So here we just returned the multi payment id instead of the payment id
        return True
        
    
    def prepare_endorse_payment_vals(self,selected_payments):
        #In this Fucntion we create the multi payment and the payment is created in POST action 

        multi_payment_id, prepared_vals = super(FChequeWizardInerit, self).prepare_endorse_payment_vals(selected_payments)
        print('prepared_vals',prepared_vals)
        lines = []
        for  payment in prepared_vals :
            lines.append((0,0,payment))

        print('lines',lines)
        multi_payment = self.env['f.multi.payments']
        multi_payment_vals = {
            'f_payment_type' : 'outbound',
            'f_partner_type' : 'supplier',
            'f_partner_id'   : self.supplier_id.id,
            #'f_currency_id'  : payments[0]['currency_id'],
            'f_payment_date' : self.action_date,
            'f_pay_reference': 'Endorsed Payment',
            'f_payment_lines': lines,
            'f_destination_account_id' :  self.supplier_id.property_account_payable_id.id
            }


        print('multi_payment_vals',multi_payment_vals)
        multi_payment = multi_payment.create(multi_payment_vals)
        multi_payment.f_post_payment()
        print ('Multi Payment Id ',multi_payment)
        for  pay in prepared_vals:
            print('pay',pay)
            des_payment    = self.env['account.payment'].sudo().search([('source_payment', '=', pay['source_payment']),('state','=','posted'),('f_parent_id','=',multi_payment.id)],limit=1)
            source_payment = self.env['account.payment'].sudo().search([('id', '=', pay['source_payment'])])
            source_payment.write(
                {'des_payment': des_payment.id, 'endorse_date': self.action_date, 'check_state': 'endorsed'})
           # print('source_payment.f_endorse_exchange_rate*****************',source_payment.f_endorse_exchange_rate)
            des_payment.sudo().write(
                {'invoice_user_id':multi_payment.user_id.id,'exchange_rate': source_payment.f_endorse_exchange_rate,'f_endorse_exchange_rate': source_payment.f_endorse_exchange_rate})





        return multi_payment,prepared_vals
    
