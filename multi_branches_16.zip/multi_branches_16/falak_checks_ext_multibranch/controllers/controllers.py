# -*- coding: utf-8 -*-
# from odoo import http


# class FalakChecksExtMultibranch(http.Controller):
#     @http.route('/falak_checks_ext_multibranch/falak_checks_ext_multibranch/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/falak_checks_ext_multibranch/falak_checks_ext_multibranch/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('falak_checks_ext_multibranch.listing', {
#             'root': '/falak_checks_ext_multibranch/falak_checks_ext_multibranch',
#             'objects': http.request.env['falak_checks_ext_multibranch.falak_checks_ext_multibranch'].search([]),
#         })

#     @http.route('/falak_checks_ext_multibranch/falak_checks_ext_multibranch/objects/<model("falak_checks_ext_multibranch.falak_checks_ext_multibranch"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('falak_checks_ext_multibranch.object', {
#             'object': obj
#         })
