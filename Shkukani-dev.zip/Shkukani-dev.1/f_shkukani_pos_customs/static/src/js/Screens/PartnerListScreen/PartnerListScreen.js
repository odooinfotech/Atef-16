odoo.define('f_shkukani_pos_customs.PartnerListScreen', function (require) {
    'use strict';

    const PartnerListScreen = require('point_of_sale.PartnerListScreen');
    const Registries = require('point_of_sale.Registries');
    const { isConnectionError } = require('point_of_sale.utils');

    const FPartnerListScreenExtend = (PartnerListScreen) =>
        class extends PartnerListScreen {
            async saveChanges(event) {
                console.log('/////////////////////// pos.config', this.env.pos.config)
                event.detail.processedChanges.f_brand_id = this.env.pos.config.f_contact_brand_id[0];
                return super.saveChanges(event);
            }
        };

    Registries.Component.extend(PartnerListScreen, FPartnerListScreenExtend);

    return FPartnerListScreenExtend;
});
