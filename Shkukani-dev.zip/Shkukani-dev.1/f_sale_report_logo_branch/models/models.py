from odoo import models, fields, api


class f_multi_branches_management(models.Model):
    _inherit = 'f.comp.branches'


    f_logo = fields.Binary(string='Logo')