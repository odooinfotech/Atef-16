# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class f_ex_multipay_receipt_print_balance(models.Model):
#     _name = 'f_ex_multipay_receipt_print_balance.f_ex_multipay_receipt_print_balance'
#     _description = 'f_ex_multipay_receipt_print_balance.f_ex_multipay_receipt_print_balance'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
