odoo.define('f_pos_customs_shuk.posconfigScreen', function (require) {
    'use strict';
    const PosComponent = require('point_of_sale.PosComponent');
    const Registries = require('point_of_sale.Registries');
    const useSelectpos = require('f_pos_customs_shuk.useSelectpos');
    const { useBarcodeReader } = require('point_of_sale.custom_hooks');

    class posconfigScreen extends useSelectpos(PosComponent) {
       setup() {
            super.setup();
        }

        back() {

                this.props.resolve({ confirmed: false, payload: false });
                this.trigger('close-temp-screen');
                this.showScreen('ProductScreen');

            }





        confirm() {
            this.props.resolve({ confirmed: true, payload: true });
            this.trigger('close-temp-screen');
        }


         async selectCashier() {
            if (await super.selectCashier()) {
                this.back();
            }
        }




    }
    posconfigScreen.template = 'posconfigScreen';

    Registries.Component.add(posconfigScreen);

    return posconfigScreen;
});
