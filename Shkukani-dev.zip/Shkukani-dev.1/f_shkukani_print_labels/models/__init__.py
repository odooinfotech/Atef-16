# -*- coding: utf-8 -*-

from . import f_print_fields
from . import f_barcode_design
from . import f_report_paperformat_inherit
from . import f_account_move_inherit
from . import f_stock_picking_inherit
from . import f_product_product_inherit
