# -*- coding: utf-8 -*-
{
    'name': "f_ex_branch_contact_vendor_access",

    'summary': """
        new access right to control access on cutomer /vendor contact 
    
        """,

    'description': """
        
        In config : these 2 record rule must be archived when install this app to work correctly :
        1-	res.partner.rule.private.employee
        2-res.partner.rule.private.group
     
    """,

    'author': "Falak Solutions",
    'license': 'LGPL-3',

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0',

    # any module necessary for this one to work correctly
    'depends': ['base','contacts','f_multi_branches_management'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/f_inherit_users_groups.xml',
        'views/f_record_rule.xml',
    ],

}
