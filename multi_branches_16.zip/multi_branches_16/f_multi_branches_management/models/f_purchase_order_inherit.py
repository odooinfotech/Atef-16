from odoo import models, fields, api

class f_purchase_order(models.Model):
    _inherit = 'purchase.order'

    @api.model
    def create(self, vals):
        res = super(f_purchase_order, self).create(vals)
        if self.env.company.f_default_partner_branch:
            if res.partner_id.f_related_branch:
                res.update({
                    'f_related_branch': res.partner_id.f_related_branch.id or False
                })
            else:
                res.update({
                    'f_related_branch': self.env.user.f_default_branch.id or False
                })

        return res

    def write(self, vals):
        if self.env.company.f_default_partner_branch:
            if 'partner_id' in vals:
                partner = self.sudo().env['res.partner'].sudo().search([('id', '=', vals['partner_id'])], limit=1)
                if partner.f_related_branch:
                    vals['f_related_branch'] = partner.f_related_branch.id
                else:
                    vals['f_related_branch'] = self.env.user.f_default_branch.id

        return super(f_purchase_order, self).write(vals)
    

    def _get_default_branch(self):
         user_default_branch = False
         if self.env.company.f_allow_multi_branches ==True : 

             context = self._context
             current_uid = context.get('uid')
             print('current_uid',current_uid)

             user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
             if user_default_branch :
                 comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id

                 if comp == self.env.company.id :
                     self.f_related_branch  = user_default_branch
                     print('user_default_branch',user_default_branch)
                 else :
                     print(self.env.user.company_id.id)
                     branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.company.id)],limit=1)
                     print('branch',branch)
                     self.f_related_branch  = branch.id
                     user_default_branch = branch.id
             else :
                 user_default_branch = self.env['res.users'].browse(current_uid).f_allowed_branches[0]
         return user_default_branch
    
    
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, default=_get_default_branch, tracking=True)
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')
    @api.model
    def _prepare_picking(self):
        res = super(f_purchase_order, self)._prepare_picking()
        branch_id = False
        if self.picking_type_id.f_related_branch:
            branch_id = self.picking_type_id.f_related_branch.id
        elif self.env.user.f_related_branch:
            branch_id = self.env.user.f_related_branch.id
        res.update({
            'f_related_branch' : branch_id
        })
        return res


    def _prepare_invoice(self):
        result = super(f_purchase_order, self)._prepare_invoice()
        branch_id = False
        if self.f_related_branch:
            branch_id = self.f_related_branch.id
        elif self.env.user.f_related_branch:
            branch_id = self.env.user.f_related_branch.id

        result.update({
                
                'f_related_branch' : branch_id
            })
        
        return result
   
