# -*- coding: utf-8 -*-

from . import models
from . import f_wizard
from . import f_pos_details
from . import f_pos_product_wizard
from . import f_inherit_sale_report