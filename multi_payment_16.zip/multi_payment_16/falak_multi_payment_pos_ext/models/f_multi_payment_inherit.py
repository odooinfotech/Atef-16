from odoo import models,fields

class FMultiPaymentnherit(models.Model):
    _inherit = 'f.multi.payments'
    
    f_pos_session_id = fields.Many2one('pos.session', string="POS Session",copy=False,readonly=True)
    f_pos_order_id = fields.Many2one('pos.order', string="POS Order",copy=False,readonly=True)
     
