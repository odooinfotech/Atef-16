from odoo import models, fields, api,tools, _
from datetime import datetime, timedelta, date
from odoo.exceptions import UserError, ValidationError


class FChequeWizard(models.TransientModel):
    _name = 'cheque.wizard'
    _description = "Check Wizard"

    @api.onchange('action_date')
    def _onchange_action_date(self):
        # print(self.action_date , date.today())
        if self.action_date > date.today():
            self.action_date = date.today()
            # raise ValidationError('Date Can not be in Future!' )
            return self._origin

    def applyfees(self,current_payment,action_type,debit_ac,credit_ac,fees_cr_acc,fees_db_acc):

        vals = {
            'date': self.action_date,  # current_payment.due_date,
            'journal_id': current_payment.f_current_journal.id,
            'currency_id': current_payment.f_current_journal.currency_id.id,
            'company_id': current_payment.company_id.id,
            'f_payment_id': current_payment.id,
            'amount_total': self.f_fees_amount,
            'ref': 'Checks Fees'+ action_type ,
            'partner_id': current_payment.partner_id.id,
            # 'f_bulk_action_seq': self.bulk_seq,
            # 'account_che_id' : current_payment.check_number
            'line_ids': [
                (0, 0, {
                    'partner_id': current_payment.partner_id.id,
                    'account_id': fees_db_acc,
                    'debit': self.f_fees_amount,
                    'credit': 0,
                    'date_maturity': self.action_date,
                    # 'move_id' : account_move.id,
                    'company_id': current_payment.company_id.id,
                    'f_payment_id': current_payment.id,
                    # 'maturity_date_ref': db_maturity_date_ref,
                    'action_type':action_type+ 'Checks Fees -d',
                    'date': self.action_date,
                    'amount_currency': debit_ac,
                    'currency_id': current_payment.f_current_journal.currency_id.id,
                    # 'f_bulk_action_seq': self.bulk_seq,
                }),
                (0, 0, {
                    'partner_id': current_payment.partner_id.id,
                    'account_id': fees_cr_acc,
                    'credit': self.f_fees_amount,
                    'debit': 0,
                    # 'amount_currency' : current_payment.amount,
                    'date_maturity': self.action_date,
                    # 'move_id' : account_move.id,
                    'company_id': current_payment.company_id.id,
                    'f_payment_id': current_payment.id,
                    # 'maturity_date_ref': cr_maturity_date_ref,
                    'action_type': action_type+'Checks Fees -c',
                    'date': self.action_date,
                    'amount_currency': credit_ac,
                    'currency_id': current_payment.f_current_journal.currency_id.id,
                    # 'f_bulk_action_seq': self.bulk_seq,

                })]
        }

        account_move = self.env['account.move'].sudo().create(vals)
        account_move.action_post()

    # @api.multi
    def bulk_actions_validations(self, action_type, selected_payments):
        result = 'ok'

        # get Currency
        ctx_currency_id = self._context.get('default_currency_id')
        print('ctx_currency_id', ctx_currency_id)
        for pay in selected_payments:
            if pay.currency_id.id != ctx_currency_id and pay.payment_type == 'inbound' and action_type not in ('bounce','endorse','unendorse','return','v_return','undeposit','uncollect'):
                result = 'All selected check payments should be with the same currency'
                return result

        for pay in selected_payments:
            if pay.state != 'posted':
                result = 'All selected check payments should be posted'
                return result

        for payment in selected_payments:
            if not payment.f_current_journal:
                payment.f_current_journal = payment.journal_id.id
                #Check Repay
                if (action_type == 'repay'):
                    if payment.check_details != True:
                        result = 'Payment ' + payment.name + 'is not check payment !'
                        return result
                    if payment.payment_type != 'inbound':
                        result = 'Payment ' + payment.name + 'is not receive payment ! '
                        return result
                    if payment.check_state not in ('returned'):
                        result = 'Payment ' + payment.name + 'check status is ' + payment.check_state
                        return result



                # check_transfer
            if (action_type == 'transfer'):
                if payment.check_details != True:
                    result = 'Payment ' + payment.name + 'Could not Be Transfered , because it is not check payment !'
                    return result
                if payment.payment_type != 'inbound':
                    result = 'Payment ' + payment.name + 'Could not Be Transfered , because it is not receive payment ! '
                    return result
                if payment.check_state not in ('in_check_box', 'bounced'):
                    result = 'Payment ' + payment.name + 'Could not Be Transfered , because check status is ' + payment.check_state
                    return result
                if self.transfer_to_account_id.id == payment.f_current_journal.id:
                    result = 'You Could not Transfer Payment to the Same Box : ' + payment.f_current_journal.name + ' !'
                    return result

            elif (action_type == 'release'):
                if payment.check_state not in ('issued'):
                    result = 'Payment ' + payment.name + 'Could not Be Released , because check status is ' + payment.check_state
                    return result
                if payment.payment_type != 'outbound':
                    result = 'Payment ' + payment.name + 'Could not Be Released , because it is not receive payment ! '
                    return result

            elif (action_type == 'endorse'):
                # check_state', 'not in', ('draft' ,'in_check_box','bounced')),('check_details', '=', False),('payment_type', '=', 'outbound')
                if payment.check_details != True:
                    result = 'Payment ' + payment.name + 'Could not Be Endorsed , because it is not check payment !'
                    return result
                if payment.payment_type != 'inbound':
                    result = 'Payment ' + payment.name + 'Could not Be Endorsed , because it is not receive payment ! '
                    return result
                if payment.check_state not in ('bounced', 'in_check_box'):
                    result = 'Payment ' + payment.name + 'Could not Be Endorsed , because check status is ' + payment.check_state
                    return result


            elif (action_type == 'deposit'):
                # check_state', 'not in', ('draft' ,'in_check_box','bounced')),('check_details', '=', False),('payment_type', '=', 'outbound')
                if payment.check_details != True:
                    result = 'Payment ' + payment.name + 'Could not Be Deposited , because it is not check payment !'
                    return result
                if payment.payment_type != 'inbound':
                    result = 'Payment ' + payment.name + 'Could not Be Deposited , because it is not receive payment ! '
                    return result
                if payment.check_state not in ('draft', 'in_check_box', 'bounced'):
                    result = 'Payment ' + payment.name + 'Could not Be Deposited , because check status is ' + payment.check_state
                    return result

            elif (action_type == 'collect'):
                if payment.check_details != True:
                    result = 'Payment ' + payment.name + 'Could not Be Collected , because it is not check payment !'
                    return result
                if payment.payment_type != 'inbound':
                    result = 'Payment ' + payment.name + 'Could not Be Collected , because it is not receive payment ! '
                    return result
                if payment.check_state not in ('draft', 'bounced', 'in_check_box', 'under_collection'):
                    result = 'Payment ' + payment.name + 'Could not Be Collected , because check status is ' + payment.check_state
                    return result


            elif (action_type == 'return'):

                if payment.check_state  in ('under_collection','collected','endorsed'):
                    result = 'Payment ' + payment.name + 'Could not Be Returned , because check status is ' + payment.check_state
                    return result

            elif (action_type == 'bounce'):
                if payment.check_details != True:
                    result = 'Payment ' + payment.name + 'Could not Be Bounced , because it is not check payment !'
                    return result
                if payment.payment_type != 'inbound':
                    result = 'Payment ' + payment.name + 'Could not Be Bounced , because it is not receive payment ! '
                    return result
                if payment.check_state not in ('collected'):
                    result = 'Payment ' + payment.name + 'Could not Be Bounced , because check status is ' + payment.check_state
                    return result

        return result

    #############################################################################################
    # this Function is used for all custom Transactions for checks
    # - deposit,collect,bounce,undeposit,endorse,unendorse for inward checks
    #
    # The function is called from the wizard popup confirm action and a parameter is passes to detrmine the action
    #
    ############################################################################################
    # @api.multi
    def get_debt_account(self,pay):
        return pay
        
        
    def get_vals(self, action_type, current_payment):

        # init vals
        amount_currency = False
        currency_id = False
        debit = 0
        credit = 0
        debit_ac = 0
        credit_ac = 0
        credit_acc = ''
        debt_acc = ''
        trans_amount = 0
        cr_date_maturity = False
        db_date_maturity = False
        db_maturity_date_ref = 'self.action_date'
        cr_maturity_date_ref = 'self.action_date'

        # set the debt credit amount based on currency
        aml_obj = self.env['account.move.line'].with_context(check_move_validity=False)

        move_line = self.env['account.move.line'].search(
            #Commented to depend on the move id instaed of the confirm action type
            #[('payment_id', '=', current_payment.id), ('action_type', '=', 'confirm'), ('debit', '>', 0)])
            [('move_id', '=', current_payment.move_id.id), ('debit', '>', 0)])
        print(move_line)
        debit = move_line['debit']
        debit_ac = move_line['amount_currency']


        move_line = self.env['account.move.line'].search(
            #[('payment_id', '=', current_payment.id), ('action_type', '=', 'confirm'), ('credit', '>', 0)])
            [('move_id', '=', current_payment.move_id.id),  ('credit', '>', 0)])
        print(move_line)
        credit = move_line['credit']
        credit_ac = move_line['amount_currency']


        amount_currency = move_line['amount_currency']
        currency_id = move_line['currency_id']

        # Set Due Date , debt , credit based on action type


        if action_type == 'entry_endorse':
                credit_acc = self.f_entry_endorsed_account_id.id
                cr_date_maturity = self.action_date
                cr_maturity_date_ref = 'self.action_date'

                debt_acc = self.get_debt_account(current_payment.destination_account_id.id)
               # debt_acc = current_payment.destination_account_id.id
                db_date_maturity = self.action_date
                db_maturity_date_ref = 'self.action_date'
                print('cr',credit_acc,'db',debt_acc)



        print('action_type',action_type)
        if action_type == 'repay':
            if self.repay_option == 'journal':
                credit_acc = current_payment.destination_account_id.id
                cr_date_maturity = self.action_date
                cr_maturity_date_ref = 'self.action_date'

                debt_acc = current_payment.journal_id.default_account_id.id
                db_date_maturity = self.action_date
                db_maturity_date_ref = 'self.action_date'
                print('cr',credit_acc,'db',debt_acc)


        if action_type == 'return':

            # returned_checks_account = self.env['account.account'].sudo().search([('f_returned_checks_acc', '=', True)],
            #                                                                     limit=1).id
            # if not returned_checks_account:
            #     raise UserError(_("No account is defined for Returned Checks."))

            credit_acc = current_payment.f_current_journal.default_account_id.id
            cr_date_maturity = current_payment.date
            cr_maturity_date_ref = 'current_payment.date'
            #debt_acc = current_payment.partner_id.property_account_receivable_id.id
            #debt_acc = returned_checks_account
            debt_acc = self.return_account_id.id
            db_date_maturity = current_payment.due_date
            db_maturity_date_ref = 'current_payment.due_date'
            if  self.f_enable_fees:
                fees_cr_acc = self.f_fees_account.id
                fees_db_acc = current_payment.partner_id.property_account_receivable_id.id
                self.applyfees(current_payment,action_type,debit_ac,credit_ac,fees_cr_acc,fees_db_acc)

        if action_type == 'v_return':
            print('v_return--vals')
            credit_acc = current_payment.partner_id.property_account_payable_id.id
            cr_date_maturity = current_payment.date
            cr_maturity_date_ref = 'current_payment.date'

            if current_payment.check_state == 'issued':
                #debt_acc = current_payment.f_current_journal.outward_checks_account.id
                #debt_acc = current_payment.payment_method_line_id.payment_account_id.id

                method_id = current_payment.payment_method_line_id.payment_method_id.id
                debt_acc=current_payment.f_current_journal.outbound_payment_method_line_ids.filtered(
                    lambda m: m.payment_method_id.id == method_id).payment_account_id.id


            else:
                debt_acc = current_payment.f_current_journal.default_account_id.id


            db_date_maturity = current_payment.due_date
            db_maturity_date_ref = 'current_payment.due_date'



        if action_type == 'deposit':

            if current_payment.check_state == 'draft':
                credit_acc = current_payment.partner_id.property_account_receivable_id.id
                cr_date_maturity = current_payment.date
                cr_maturity_date_ref = 'current_payment.date'

            else:
                credit_acc = current_payment.f_current_journal.default_account_id.id
                cr_date_maturity = current_payment.due_date
                cr_maturity_date_ref = 'current_payment.due_date'

            debt_acc = self.deposit_to_account_id.deposite_account.id
            db_date_maturity = current_payment.due_date
            db_maturity_date_ref = 'current_payment.due_date'

        # Check_transfer
        elif action_type == 'transfer':

            credit_acc = current_payment.f_current_journal.default_account_id.id

            # if current_payment.f_current_journal.f_without_statement:
            #                 credit_acc = current_payment.f_current_journal.default_account_id.id
            #             else:
            #                 credit_acc = current_payment.f_current_journal.company_id.account_journal_payment_credit_account_id.id

            cr_date_maturity = current_payment.due_date
            cr_maturity_date_ref = 'current_payment.due_date'

            print('CCCCc', self.transfer_to_account_id, credit_acc)

            debt_acc = self.transfer_to_account_id.default_account_id.id
            db_date_maturity = current_payment.due_date
            db_maturity_date_ref = 'current_payment.due_date'
            print('elif action_type == transfer')



        elif action_type == 'release':

            #debt_acc = current_payment.f_current_journal.outward_checks_account.id
            #debt_acc  =  current_payment.payment_method_line_id.payment_account_id.id

            method_id = current_payment.payment_method_line_id.payment_method_id.id
            debt_acc=current_payment.f_current_journal.outbound_payment_method_line_ids.filtered(lambda m: m.payment_method_id.id == method_id).payment_account_id.id



            db_date_maturity = self.action_date
            db_maturity_date_ref = 'self.action_date'
            cr_date_maturity = current_payment.due_date
            cr_maturity_date_ref = 'self.action_date'
            credit_acc = current_payment.f_current_journal.default_account_id.id
            #cedit_acc = current_payment.f_current_journal.company_id.account_journal_payment_credit_account_id.id


        elif action_type == 'collect':
            # print('In Collect ')

            if (
                    current_payment.deposit_collect_bank != self.collect_from_account_id and current_payment.check_state == 'under_collection'):
                raise UserError(_("You Can't Change Deposit Account Id ."))

            if (current_payment.check_state in ('draft')):
                credit_acc = current_payment.partner_id.property_account_receivable_id.id
                cr_date_maturity = current_payment.date
                cr_maturity_date_ref = 'current_payment.date'

            elif (current_payment.check_state in ('in_check_box', 'bounced')):
                credit_acc = current_payment.f_current_journal.default_account_id.id
                cr_date_maturity = self.action_date
                cr_maturity_date_ref = 'self.action_date'

            elif (current_payment.check_state in ('under_collection')):
                credit_acc = current_payment.deposit_collect_bank.deposite_account.id
                cr_date_maturity = self.action_date
                cr_maturity_date_ref = 'self.action_date'

            if self.collect_from_account_id:
                move_lines = self.env['account.move.line'].search(
                    [('f_payment_id', '=', current_payment.id), ('action_type', 'in', ('deposit-c', 'collect-c'))],
                    order='create_date desc', limit=2)
                for l in move_lines:
                    db_maturity_date_ref = l['maturity_date_ref']
                    # print('Value Found >>>>>',db_maturity_date_ref)

                debt_acc = self.collect_from_account_id.default_account_id.id
                db_date_maturity = cr_date_maturity

            else:
                debt_acc = current_payment.deposit_collect_bank.default_account_id.id

                db_date_maturity = self.action_date
                db_maturity_date_ref = 'self.action_date'
                # cr_maturity_date_ref = 'current_payment.due_date'



        elif action_type == 'bounce':

            credit_acc = current_payment.deposit_collect_bank.default_account_id.id
            cr_date_maturity = self.action_date
            cr_maturity_date_ref = 'self.action_date'

            debt_acc = current_payment.f_current_journal.default_account_id.id
            db_date_maturity = self.action_date
            db_maturity_date_ref = 'self.action_date'

            #apply fees on returned checks
            if  self.f_enable_fees:
                fees_cr_acc = current_payment.deposit_collect_bank.default_account_id.id
                fees_db_acc = self.f_fees_account.id
                self.applyfees(current_payment,action_type,debit_ac,credit_ac,fees_cr_acc,fees_db_acc)

        elif action_type == 'undeposit':

            credit_acc = current_payment.deposit_collect_bank.deposite_account.id
            cr_date_maturity = current_payment.due_date
            cr_maturity_date_ref = 'current_payment.due_date'

            debt_acc = current_payment.f_current_journal.default_account_id.id
            db_date_maturity = current_payment.due_date
            db_maturity_date_ref = 'current_payment.due_date'

        elif action_type == 'uncollect':

            if current_payment.check_state == 'collected':
                if current_payment.deposit_date:
                    credit_acc = current_payment.deposit_collect_bank.default_account_id.id
                    cr_date_maturity = current_payment.due_date
                    cr_maturity_date_ref = 'current_payment.due_date'

                    debt_acc = current_payment.deposit_collect_bank.deposite_account.id
                    db_date_maturity = current_payment.due_date
                    db_maturity_date_ref = 'current_payment.due_date'

                else:
                    credit_acc = current_payment.deposit_collect_bank.default_account_id.id
                    cr_date_maturity = current_payment.due_date
                    cr_maturity_date_ref = 'current_payment.due_date'

                    debt_acc = current_payment.f_current_journal.default_account_id.id
                    db_date_maturity = current_payment.due_date
                    db_maturity_date_ref = 'current_payment.due_date'



            #********************* udated by shireen
            #Commented to stop depending on action type
            # account_move_obj = self.env['account.move.line'].search(
            #     [('f_payment_id', '=', current_payment.id), ('ref', 'like', 'deposit%')], order='create_date desc',
            #     limit=2)
            # print(account_move_obj)
            # for line in account_move_obj:
            #     # print('Accounts',credit_acc,debt_acc)
            #     if line.action_type == 'deposit-c':
            #         debt_acc = line.account_id.id
            #
            #         db_date_maturity = current_payment.due_date
            #         db_maturity_date_ref = 'current_payment.due_date'
            #
            #     elif line.action_type == 'deposit-d':
            #         credit_acc = line.account_id.id
            #
            #         cr_date_maturity = current_payment.due_date
            #         cr_maturity_date_ref = 'current_payment.due_date'

        #print('Accounts', credit_acc, debt_acc)
        print(credit_ac, debit_ac, credit, debit, credit_acc, debt_acc, cr_maturity_date_ref, db_maturity_date_ref, cr_date_maturity, db_date_maturity, trans_amount, amount_currency, currency_id)
        return credit_ac, debit_ac, credit, debit, credit_acc, debt_acc, cr_maturity_date_ref, db_maturity_date_ref, cr_date_maturity, db_date_maturity, trans_amount, amount_currency, currency_id

        # @api.multi



    def set_payment_name(self, current_payment):
        # print('In seeeeeeeeeeeeeeeeeeet')
        sequence_code = ''
        # Set Payment name 
        if not current_payment.name:
            # Use the right sequence to set the name
            if current_payment.payment_type == 'transfer':
                sequence_code = 'account.payment.transfer'
            else:
                if current_payment.partner_type == 'customer':
                    if current_payment.payment_type == 'inbound':
                        sequence_code = 'account.payment.customer.invoice'
                    if current_payment.payment_type == 'outbound':
                        sequence_code = 'account.payment.customer.refund'
                if current_payment.partner_type == 'supplier':
                    if current_payment.payment_type == 'inbound':
                        sequence_code = 'account.payment.supplier.refund'
                    if current_payment.payment_type == 'outbound':
                        sequence_code = 'account.payment.supplier.invoice'

            current_payment.name = self.env['ir.sequence'].with_context(
                ir_sequence_date=current_payment.date).next_by_code(sequence_code)
            # print('Payment Name',current_payment.name,sequence_code)
            if not current_payment.name and current_payment.payment_type != 'transfer':
                raise UserError(_("You have to define a sequence for %s in your company.") % (sequence_code,))

        return current_payment

        # @api.one

    def validate_vals(self, credit_acc, debt_acc=True):

        message = 'ok'

        if credit_acc == False:
            message = 'Credit Accound Id is empty !'

        elif debt_acc == False:
            message = 'Debt Accound Id is empty !'

        return message

    def create_endorse_supplier_payment(self, vals):
        # print('99999999999999999999999999999999999999999999999999999999999999999999999')
        vendor_pay_obj = self.env['account.payment'].browse()
        for payment in vals :
            supplier_payment = vendor_pay_obj.create(payment)
            source_payment = self.env['account.payment'].sudo().search([('id','=',payment['source_payment'])])
            source_payment.write(
                {'des_payment': supplier_payment, 'endorse_date': self.action_date, 'check_state': 'endorsed'})
        return  True


    def prepare_endorse_payment_vals(self, selected_payments):

        vals = []
        print('selected_payments',selected_payments)
        for current_payment in  selected_payments :
            print('current_payment',current_payment)
            if current_payment.payment_type == 'inbound':
                sequence_code = 'account.payment.supplier.refund'
            if current_payment.payment_type == 'outbound':
                sequence_code = 'account.payment.supplier.invoice'
            supplier_pay_name = self.env['ir.sequence'].with_context(
                ir_sequence_date=current_payment.date).next_by_code(sequence_code)


            for method_id in current_payment.f_current_journal.outbound_payment_method_line_ids.filtered(
                    lambda l: l.payment_method_id.code == 'check_printing'):
                payment_method_line_id = method_id.id

            vals.append( {
                #'name': supplier_pay_name,
                'state': 'draft',
                'payment_type': 'outbound',
                'partner_type': 'supplier',
                'partner_id': self.supplier_id.id,
                'date' : self.action_date,
                'amount': current_payment.amount,
                'currency_id': current_payment.currency_id.id,
                'journal_id': current_payment.f_current_journal.id,
                'payment_method_id': 2,
                'payment_method_line_id' : payment_method_line_id,
                'due_date': current_payment.due_date,
                'check_number': current_payment.check_number,
                'ref': 'Endorsed From : ' + current_payment.check_number,
                'source_payment': current_payment.id,
                'bank_id': current_payment.bank_id.id,
                'branch_id': current_payment.branch_id.id,
                'account_number': current_payment.account_number,
                # 'payment_group_id':group_id.id,
            })

        return False,vals

    def create_repay_payment(self,vals):
        pay = self.sudo().env['account.payment'].create(vals)
        pay.action_post()
        return True




    def repay_prepare_payment_vals(self,current_payment,account_repay):
        vals = {
            'date': self.action_date,
            'state': 'draft',
            'payment_type': current_payment.payment_type,
            'partner_type': current_payment.partner_type,
            'partner_id': current_payment.partner_id.id,
            'journal_id': current_payment.journal_id.id,
            'amount': current_payment.amount,
            'currency_id': current_payment.journal_id.currency_id.id,
            'check_number': current_payment.check_number,
            'check_state': 'in_check_box',
            'bank_id': current_payment.bank_id.id,
            'branch_id': current_payment.branch_id.id,
            'account_number': current_payment.account_number,
            'due_date': current_payment.due_date,
            'invoice_user_id': current_payment.user_id.id,
           # 'f_parent_id': current_payment.f_parent_id.id,
            'payment_method_line_id': current_payment.payment_method_line_id.id,
            'destination_account_id': account_repay,
            'ref': current_payment.name
        }
        return vals
       # payment_vals_new = self.env['account.payment'].sudo().create(vals)

    def get_bulk_seq(self, f_action_date):
        if f_action_date:
            if type(f_action_date) == str:
                f_action_date = datetime.strptime(f_action_date, '%Y-%m-%d')
            year = f_action_date.year
            month = '{:02d}'.format(f_action_date.month)
        else:
            year = datetime.today().year
            month = '{:02d}'.format(datetime.today().month)
            # print(month)
        seq_no = self.env['ir.sequence'].next_by_code('Bulk Checks Sequence')
        seq_number = str(year) + '/' + str(month) + '/' + str(seq_no)
        return seq_number


    def f_check_sleceted_payment_warn(self,pays,action_type):
        f_warn_release = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_release')
        f_warn_deposit = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_deposit')
        f_warn_collect = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_collect')
        f_warn_return = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_return')
        f_warn_endorse = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_endorse')
        f_warn_bounc = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_bounc')
        f_warn_unendorse = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_unendorse')
        f_warn_undeposit = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_undeposit')
        f_warn_uncollect = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_uncollect')
        f_warn_repay = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_repay')
        f_warn_entry_endorse = self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_entry_endorse')
        partner_acrived_list = []
        archived_parts = ''
        for rec_part in pays:
            partner_state = self.env['res.partner'].search(
                [('id', '=', rec_part.partner_id.id), ('active', '=', False)])
            if partner_state:
                partner_acrived_list.append('%s' % (rec_part.partner_id.name))
        archived_parts = '\n'.join(partner_acrived_list).strip(' + ')
        if f_warn_release and action_type =='release':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))

        if f_warn_deposit and action_type =='deposit':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))

        if f_warn_collect and action_type =='collect':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))

        if f_warn_return and action_type =='return':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))


        if f_warn_endorse and action_type =='endorse':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))


        if f_warn_bounc and action_type =='bounce':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))

        if f_warn_unendorse and action_type =='unendorse':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))


        if f_warn_undeposit and action_type =='undeposit':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))


        if f_warn_uncollect and action_type =='uncollect':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))

        if f_warn_repay and action_type =='repay':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))

        if f_warn_entry_endorse and action_type =='entry_endorse':
            if len(partner_acrived_list) > 0:
                raise ValidationError(
                    _("You Can't Complete this transaction because this contact :  %s , is archived") % (
                    archived_parts,))


        return True



    def check_actions(self):

        if self.f_entry_endorsed_account_id:
            if self.f_entry_endorsed_account_id.account_type  in ('liability_payable','asset_receivable'):
                if not self.f_entry_endorsed_partner_id :
                    raise ValidationError('Required Partner !' )



        action_type = self._context.get('action_type')
        supplier_payment = ''
        account_move = ''
        # print('action_type',action_type)
        # print('action_type',self.action_date)
        if self.action_date > date.today():
            raise UserError('Date Can not be in Future!')

        selected_payments = self.env['account.payment'].browse(self._context.get('active_ids'))
        self.f_check_sleceted_payment_warn(selected_payments,action_type)

        validation_result = self.bulk_actions_validations(action_type, selected_payments)
        # print('validation_result', validation_result[0])

        if validation_result != 'ok':
            raise UserError(_(validation_result))

        if action_type == 'endorse':

            for current_payment in selected_payments:

                previous_payments = self.env['account.payment'].search(
                    ['&', '&', ('source_payment', '=', current_payment.id), ('state', '!=', 'cancel'),
                     ('check_state', '!=', 'returned')])
                if len(previous_payments) > 0:
                    raise ValidationError(
                        _("You cannot endorse a check that had related not cancelled Payments , Please Cancel these payments first ."))



            ######################################################
            pay_id,vals = self.prepare_endorse_payment_vals( selected_payments)

            self.create_endorse_supplier_payment(vals)



        # Set the required values for each payment to do the check action this for loop if for bulk transactioms
        for current_payment in selected_payments:

            if not current_payment.f_current_journal:
                current_payment.f_current_journal = current_payment.journal_id.id

            old_state = current_payment.state

            current_payment = self.set_payment_name(current_payment)
            # print('current_payment>>>',current_payment)

            # ???????????????? i should add validation here
            # Validations on Mandatory Wizard Fields
            # Deposit
            if not self.deposit_to_account_id and self._context.get('action_type') == 'deposit':
                raise UserError(_("You Have to Enter the Deposit Account !"))

                # Check_transfer
            if not self.transfer_to_account_id and self._context.get('action_type') == 'transfer':
                raise UserError(_("You Have to Fill the Transfer Account !"))

                # create the journal entries for all actions except the below

            #if action_type == 'unendorse':

                # previous_payments = self.env['account.payment'].search(
                #     ['&', '&', ('source_payment', '=', current_payment.id), ('state', '!=', 'cancel'),
                #      ('check_state', '!=', 'returned')])
                #
                #
                # print(previous_payments)
                #Commented by shireen to return the vendor payments automatically
                # if len(previous_payments) > 0:
                #     raise ValidationError(
                #         _("You cannot unendorse a check that had related not cancelled Payments , Please Cancel these payments first ."))


            # create the journal entries for all actions except the below

            entry_case = False
            if action_type not in ('endorse', 'unendorse') :
                entry_case = True
            if self.repay_option == 'payment'  and action_type == 'repay':
                    print('new Payment')
                    if self.f_repay_option_account_id :
                        account_repay = self.f_repay_option_account_id.id
                    else :
                        account_repay = current_payment.destination_account_id.id
                    repay_vals_payment = self.repay_prepare_payment_vals(current_payment,account_repay)
                    self.create_repay_payment(repay_vals_payment)


                    entry_case = False


            if entry_case :
                credit_ac, debit_ac, credit, debit, credit_acc, debt_acc, cr_maturity_date_ref, db_maturity_date_ref, cr_date_maturity, db_date_maturity, trans_amount, amount_currency, currency_id = self.get_vals(
                    action_type, current_payment)

                print('>>>>>>>',credit,debit,trans_amount)
                if current_payment.ref != False:
                    ref = action_type + '/' + str(current_payment.check_number) + '/' + str(current_payment.ref)
                else:
                    ref = action_type + '/' + str(current_payment.check_number)
                    if action_type == 'entry_endorse':
                        ref = action_type + '/' + str(current_payment.check_number) + '/' + str(
                            current_payment.due_date)

                message = self.validate_vals(credit_acc, debt_acc)

                if message != 'ok':
                    raise UserError(message)

                # current_payment.write({'state':'draft'})
                print(current_payment.state,self._context.get('active_ids'))
                debt_partner_data = current_payment.partner_id.id
                credit_partner_data  = current_payment.partner_id.id
                if action_type == 'entry_endorse':
                    credit_partner_data = self.f_entry_endorsed_partner_id.id
                move_lines = []
                vals = {
                    'date': self.action_date,  # current_payment.due_date,
                    'journal_id': current_payment.f_current_journal.id,
                    'currency_id': currency_id.id,
                    'company_id': current_payment.company_id.id,
                    'f_payment_id': current_payment.id,
                    'amount_total': current_payment.amount,
                    'ref': ref,
                    'partner_id': debt_partner_data,
                    'f_bulk_action_seq':self.bulk_seq,
                    # 'account_che_id' : current_payment.check_number
                    'line_ids': [
                        (0, 0, {
                            'partner_id': debt_partner_data,
                            'account_id': debt_acc,
                            'debit': debit,
                            'credit': 0,
                            'date_maturity': db_date_maturity,
                            # 'move_id' : account_move.id,
                            'company_id': current_payment.company_id.id,
                            'f_payment_id': current_payment.id,
                            'maturity_date_ref': db_maturity_date_ref,
                            'action_type': action_type + '-d',
                            'date': self.action_date,
                            'amount_currency': debit_ac,
                            'currency_id': currency_id.id,
                            'f_bulk_action_seq':self.bulk_seq,
                        }),
                        (0, 0, {
                            'partner_id': credit_partner_data,
                            'account_id': credit_acc,
                            'credit': credit,
                            'debit': 0,
                            # 'amount_currency' : current_payment.amount,
                            'date_maturity': cr_date_maturity,
                            # 'move_id' : account_move.id,
                            'company_id': current_payment.company_id.id,
                            'f_payment_id': current_payment.id,
                            'maturity_date_ref': cr_maturity_date_ref,
                            'action_type': action_type + '-c',
                            'date': self.action_date,
                            'amount_currency': credit_ac,
                            'currency_id': currency_id.id,
                            'f_bulk_action_seq': self.bulk_seq,

                        })]
                }
                print("vals",vals)
                account_move = self.env['account.move'].sudo().create(vals)

                if current_payment.currency_id.id != current_payment.company_id.currency_id.id:
                    list = []
                    for line in account_move.line_ids:
                        vals = {}
                        #print('In Lines', line)
                        currency_rate = current_payment.amount / debit
                        vals['currency_rate'] = currency_rate
                        if line.credit == 0 :
                            vals['credit'] = 0
                            vals['debit'] = debit

                        elif line.debit == 0 :
                            vals['credit'] = credit
                            vals['debit'] =  0
                        list.append((1, line.id ,vals ))
                        print(list)
                    account_move.write({'line_ids':list})

                    print('account_move', account_move, vals)
                account_move.action_post()

            # Do the required updated on selected payment based on action type 

            
            msg_list_log = ''
            old_check_state = current_payment.check_state
            
            if action_type == 'repay':
                if  self.repay_option == 'journal':
                    #current_payment.write({'check_state': 'in_check_box'})
                    
                    update_qry = """ update account_payment set check_state ='in_check_box'  where id = %s """
                    self.env.cr.execute(update_qry, (current_payment.id,))
                    msg_list_log= 'Check State updated from %s  to  In Check Box' % (old_check_state)
                    
                    


            if action_type == 'entry_endorse':
                    #current_payment.write({'check_state': 'returned','return_date':self.action_date})
                    update_qry = """ update account_payment set check_state ='returned',  return_date = %s  where id = %s """
                    self.env.cr.execute(update_qry,
                                        (self.action_date, current_payment.id))

                    update_qry_DES = """ update account_payment set f_ex_fromcheck = true  where id = %s"""
                    self.env.cr.execute(update_qry_DES, (current_payment.des_payment.id,))




                    msg_list_log= 'Check State updated from %s  to Returned and return date to %s   ' % (old_check_state,self.action_date)


            if action_type == 'deposit':
                if self.env['ir.config_parameter'].sudo().get_param('check_management.f_validate_due_date_deposit') :
                    if current_payment.due_date > self.action_date :
                        raise UserError('Due Date Greater than Deposit date ! ')
                # current_payment.write({'deposit_date': self.action_date, 'state': 'posted',
                #                        'deposit_collect_bank': self.deposit_to_account_id.id,
                #                        'check_state': 'under_collection', 'name': current_payment.name})
                update_qry = """ update account_payment set check_state ='under_collection',  deposit_date = %s ,deposit_collect_bank =%s  where id = %s """
                self.env.cr.execute(update_qry, (self.action_date, self.deposit_to_account_id.id, current_payment.id))
                msg_list_log= 'Check State updated from %s  to Under Collection and deposite date to %s   and deposit_collect_bank to %s ' % (old_check_state,self.action_date,self.deposit_to_account_id.name)



            if action_type == 'release':
                if self.env['ir.config_parameter'].sudo().get_param('check_management.f_due_date_check_onchecks') and current_payment.payment_type == 'outbound' and current_payment.check_state == 'issued':
                    if current_payment.due_date > date.today() :
                        raise UserError('Due Date Greater than Current date ! ')


                # current_payment.write({'release_date': self.action_date, 'state': 'posted',
                #                        'deposit_collect_bank': self.collect_from_account_id.id,
                #                        'check_state': 'released', 'name': current_payment.name})
                collect_account = self.collect_from_account_id.id
                if collect_account == False :
                    collect_account = None 
                    
                update_qry = """ update account_payment set check_state ='released',  release_date = %s ,deposit_collect_bank =%s  where id = %s """
                self.env.cr.execute(update_qry, (self.action_date, collect_account, current_payment.id))
                msg_list_log= 'Check State updated from %s  to  Released and Release date to %s   and deposit_collect_bank to %s ' % (old_check_state,self.action_date,self.deposit_to_account_id.name)


            

            # Check_transfer
            if action_type == 'transfer':
                # current_payment.write(
                #     {'transfer_date': self.action_date, 'f_current_journal': self.transfer_to_account_id.id, })

                update_qry = """ update account_payment set  transfer_date = %s ,f_current_journal =%s  where id = %s """
                self.env.cr.execute(update_qry, (self.action_date,  self.transfer_to_account_id.id, current_payment.id))
                msg_list_log= 'Transfer date to %s   and Journal to %s ' % (self.action_date,self.transfer_to_account_id.name)

            if action_type == 'collect':
                if self.env['ir.config_parameter'].sudo().get_param('check_management.f_due_date_check_onchecks') and current_payment.payment_type == 'inbound' and current_payment.check_state in ('under_collection','in_check_box','bounced'):
                    if current_payment.due_date > date.today() :
                        raise UserError('Due Date Greater than Current date ! ')


                # current_payment.write({'collection_date': self.action_date, 'state': 'posted',
                #                        'deposit_collect_bank': self.collect_from_account_id.id,
                #                        'check_state': 'collected', 'name': current_payment.name})
                update_qry = """ update account_payment set  check_state ='collected' ,collection_date = %s ,deposit_collect_bank =%s  where id = %s """
                self.env.cr.execute(update_qry,( self.action_date, self.collect_from_account_id.id,current_payment.id))
                msg_list_log= 'Check State updated from %s  to  Collected and Collect date to %s   and deposit_collect_bank to %s ' % (old_check_state,self.action_date,self.collect_from_account_id.name)
                




            if action_type == 'uncollect':
                # invoice=self.action_create_invoice( 'customer', current_payment.partner_id, current_payment.f_current_journal.default_account_id.id,current_payment)
                # current_payment.write(
                #     {'return_date': self.action_date, 'check_state': 'returned', 'name': current_payment.name,'f_ret_note':self.f_note})
                if current_payment.deposit_date:
                    update_qry = """ update account_payment set  check_state ='under_collection' ,uncollect_date = %s    where id = %s """
                    self.env.cr.execute(update_qry, (self.action_date,current_payment.id))
                    msg_list_log= 'Check State updated from %s  to  Under Collection  and UnCollect date to %s ' % (old_check_state,self.action_date)
                
                
                else:

                    update_qry = """ update account_payment set  check_state ='in_check_box' ,uncollect_date = %s   where id = %s """
                    self.env.cr.execute(update_qry, (self.action_date,current_payment.id))
                    msg_list_log= 'Check State updated from %s  to  In check Box and UnCollect date to %s ' % (old_check_state,self.action_date)

                
                    
                

            

            if action_type == 'bounce':
                # current_payment.write(
                #     {'bounce_date': self.action_date, 'check_state': 'bounced', 'name': current_payment.name})
                update_qry = """ update account_payment set  check_state ='bounced' ,bounce_date = %s   where id = %s """
                self.env.cr.execute(update_qry, (self.action_date,  current_payment.id))
                msg_list_log= 'Check State updated from %s  to  Bounce and Bounce date to %s ' % (old_check_state,self.action_date)


                # self.action_create_activity(invoice,current_payment)


            if action_type == 'return':
                # invoice=self.action_create_invoice( 'customer', current_payment.partner_id, current_payment.f_current_journal.default_account_id.id,current_payment)
                # current_payment.write(
                #     {'return_date': self.action_date, 'check_state': 'returned', 'name': current_payment.name,'f_ret_note':self.f_note})
                update_qry = """ update account_payment set  check_state ='returned' ,return_date = %s , f_ret_note = %s   where id = %s """
                self.env.cr.execute(update_qry, (self.action_date,self.f_note, current_payment.id))
                msg_list_log= 'Check State updated from %s  to  Returned and Return date to %s ' % (old_check_state,self.action_date)

                # self.action_create_activity(invoice,current_payment)

            if action_type == 'v_return':
                print('v_return')

                # current_payment.write(
                #     {'return_date': self.action_date, 'check_state': 'returned', 'name': current_payment.name})
                update_qry = """ update account_payment set  check_state ='returned' ,return_date = %s    where id = %s """
                self.env.cr.execute(update_qry, (self.action_date, current_payment.id))
                msg_list_log= 'Check State updated from %s  to  Returned and Return date to %s ' % (old_check_state,self.action_date)

                # self.action_create_activity(invoice,current_payment)

            if action_type == 'undeposit':
                # current_payment.write(
                #     {'undeposit_date': self.action_date, 'deposit_date': False, 'deposit_collect_bank': False,
                #      'check_state': 'in_check_box', 'name': current_payment.name})
                update_qry = """ update account_payment set  check_state ='in_check_box' ,undeposit_date = %s ,deposit_date = null ,deposit_collect_bank = NULL   where id = %s """
                self.env.cr.execute(update_qry, (self.action_date,  current_payment.id))
                msg_list_log= 'Check State updated from %s  to  In Check Box and Undeposite date to %s  and Deposit date to Null and eposit_collect_bank to null' % (old_check_state,self.action_date)

            

            if action_type == 'unendorse':

                self.unendorse_action(current_payment)

            current_payment.message_post(body=msg_list_log)

            bulk_seq_obj = self.env['f.bulk.checks'].sudo().search([('id','=',self.bulk_id.id)],limit=1)
            bulk_seq_obj.write({'f_bulk_state':'done','f_bulk_sequence':self.get_bulk_seq(self.action_date)})

        return account_move

    bulk_id  = fields.Many2one('f.bulk.checks', 'Bulk Id')

    repay_option = fields.Selection(selection ='f_get_repay_option', string='Repay Options',default='payment')

    def f_get_repay_option(self):
        list_options = [('journal','Journal'),('payment','Payment')]
        return list_options




    f_repay_option_account_id = fields.Many2one('account.account', string='Repay Payment - Account' , help ='For Payment Only')

    f_entry_endorsed_account_id= fields.Many2one('account.account',string='Account')
    f_entry_endorsed_partner_id = fields.Many2one('res.partner', string='Partner')



    bulk_seq = fields.Char('Bulk Seq #')
    context_active_id = fields.Many2one('account.payment',
                                        default=lambda self: self.env.context.get('active_id', False), store=True,
                                        readonly=True)
    currency_id = fields.Many2one('res.currency', 'Currency', related='context_active_id.currency_id', store=True,
                                  groups='base.group_multi_currency')
    action_date = fields.Date(string="Date", default=fields.Date.today())
    deposit_to_account_id = fields.Many2one('account.journal', 'Deposit To Account',
                                            domain=([('currency_id', '=', currency_id)]))
    collect_from_account_id = fields.Many2one('account.journal', 'Collect From Account',
                                              domain=([('currency_id', '=', currency_id)]))
    supplier_id = fields.Many2one('res.partner', 'Vendors')
    # check_transfer
    transfer_to_account_id = fields.Many2one('account.journal', 'Transfer To Account', domain=(
    [('currency_id', '=', currency_id), ('allow_transfer', '=', True)]))

    def _get_default_value(self):
        return self.env['account.account'].search([('f_returned_checks_acc', '=', True)], limit=1).id
    f_note = fields.Char('Note')

    return_account_id = fields.Many2one('account.account', 'Return Account',
                                              domain=([('account_type', '=', 'asset_receivable')]), default=lambda self: self._get_default_value() )


    # @api.onchange('f_enable_fees')
    # def onchangeEnable(self):
    #     selected_payments = self.env['account.payment'].browse(self._context.get('active_ids'))
    #     list =[]
    #     for pay in selected_payments :
    #         default_bounce_acct = pay.deposit_collect_bank.f_bounced_fees_account.id
    #         partner_acct = pay.partner_id.property_account_receivable_id.id
    #         if default_bounce_acct not in list :
    #             list.append(default_bounce_acct)
    #         if partner_acct not in list :
    #             list.append(partner_acct)
    #     print('list of bounced fees accounts',list)
    #     return {'domain': {'f_bounced_fees_account': [('id','in',list)]}}


    def unendorse_action (self,current_payment):

        previous_payments = self.env['account.payment'].search(
            ['&', '&', ('source_payment', '=', current_payment.id), ('state', '!=', 'cancel'),
             ('check_state', '!=', 'returned')])
        for payment in previous_payments :
            self.v_return_action(payment)
        current_payment.write(
            {'des_payment': False, 'unendorse_date': self.action_date, 'check_state': 'in_check_box',
             'name': current_payment.name})
        return True


    def v_return_action(self,payment):

            credit_acc = payment.partner_id.property_account_payable_id.id
            cr_date_maturity = payment.date
            cr_maturity_date_ref = 'payment.date'

            if payment.check_state == 'issued':
                # debt_acc = current_payment.f_current_journal.outward_checks_account.id
                # debt_acc = current_payment.payment_method_line_id.payment_account_id.id

                method_id = payment.payment_method_line_id.payment_method_id.id
                debt_acc = payment.f_current_journal.outbound_payment_method_line_ids.filtered(
                    lambda m: m.payment_method_id.id == method_id).payment_account_id.id
            else:
                debt_acc = payment.f_current_journal.default_account_id.id

            move_line = self.env['account.move.line'].sudo().search(
                [('move_id', '=', payment.move_id.id), ('debit', '>', 0)])
            debit = move_line['debit']
            debit_ac = move_line['amount_currency']

            move_line = self.env['account.move.line'].sudo().search(
                # [('payment_id', '=', current_payment.id), ('action_type', '=', 'confirm'), ('credit', '>', 0)])
                [('move_id', '=', payment.move_id.id), ('credit', '>', 0)])
            credit = move_line['credit']
            credit_ac = move_line['amount_currency']
            currency_id = move_line['currency_id'].id

            vals = {
                'date': self.action_date,  # current_payment.due_date,
                'journal_id': payment.f_current_journal.id,
                'currency_id': currency_id,
                'company_id': payment.company_id.id,
                'f_payment_id': payment.id,
                'amount_total': payment.amount,
                'ref': 'Return By Unendorse ' + '/'+payment.check_number +'/'+str(payment.due_date) ,
                'partner_id': payment.partner_id.id,

                'line_ids': [
                    (0, 0, {
                        'partner_id': payment.partner_id.id,
                        'account_id': debt_acc,
                        'debit': debit,
                        'credit': 0,
                        'date_maturity': self.action_date,
                        # 'move_id' : account_move.id,
                        'company_id': payment.company_id.id,
                        'f_payment_id': payment.id,
                        'maturity_date_ref': ' ',
                        'action_type': 'return-d',
                        'date': self.action_date,
                        'amount_currency': debit_ac,
                        'currency_id': currency_id,
                        # 'f_bulk_action_seq': self.bulk_seq,
                    }),
                    (0, 0, {
                        'partner_id': payment.partner_id.id,
                        'account_id': credit_acc,
                        'credit': credit,
                        'debit': 0,
                        # 'amount_currency' : current_payment.amount,
                        'date_maturity': self.action_date,
                        # 'move_id' : account_move.id,
                        'company_id': payment.company_id.id,
                        'f_payment_id': payment.id,
                        'maturity_date_ref': ' ',
                        'action_type': 'return-c',
                        'date': self.action_date,
                        'amount_currency': credit_ac,
                        'currency_id': currency_id,
                        #  'f_bulk_action_seq': self.bulk_seq,

                    })]
            }
            print(vals)
            account_move = self.env['account.move'].sudo().create(vals)
            account_move.action_post()
            payment.write(
                {'return_date': self.action_date, 'check_state': 'returned', 'name': payment.name})
            return True



    def get_default_fees_account(self):
        action_type = self._context.get('action_type')
        if action_type == 'bounce':
            account_id =  self.env['account.account'].search([('account_type', '=', 'asset_receivable'),'|',('company_id','=', self.env.company.id),('company_id','=',False)], limit=1)
            return  account_id.id
        elif action_type == 'return':
            account_id = self.env['account.account'].search(
                [('f_returned_to_customer_checks_acc', '=', True), '|', ('company_id', '=', self.env.company.id),
                 ('company_id', '=', False)], limit=1)
            return account_id.id


    @api.onchange('f_fees_account')
    def f_get_fees_vals(self):
        if self.f_fees_account :
            self.f_fees_amount = self.f_fees_account.f_fee_value





    def _get_default_fees_option(self):
        value = self.env.company.f_enable_fees

        return value


    @api.onchange('f_fees_account')
    def f_get_domain(self):
        if self._context.get('action_type') == 'bounce':
            account_ids = self.env['account.account'].search(
                [('account_type', '=', 'asset_receivable'), '|',
                 ('company_id', '=', self.env.company.id), ('company_id', '=', False)])
            ac_domain = [('id', 'in', account_ids.ids)]
            return {'domain': {'f_fees_account': ac_domain}}
        if self._context.get('action_type') == 'return':
            account_ids = self.env['account.account'].search(
                [ ('f_returned_to_customer_checks_acc', '=', True), '|',
                 ('company_id', '=', self.env.company.id),
                 ('company_id', '=', False)]
            )
            ac_domain = [('id', 'in', account_ids.ids)]
            return {'domain': {'f_fees_account': ac_domain}}





    def _get_default_fees_val(self):
        if self._context.get('action_type') == 'bounce' and self.env.company.f_enable_bounce_fees:
            return True

        if self._context.get('action_type') == 'return' and self.env.company.f_enable_return_fees:
            return True

    f_disable_fees = fields.Boolean('Enable Fees', default=_get_default_fees_option)
    f_enable_fees = fields.Boolean('Apply Fees',default=_get_default_fees_val)
    f_fees_amount = fields.Float(' Fees Amount', default=0)
    f_fees_account = fields.Many2one('account.account', 'Account',default=lambda self: self.get_default_fees_account())

    # related_account           = fields.Char(string = "related" ,  related='payment_id.deposit_collect_bank')

    #############################################################################################
    # this Function is to create new invoice  for bounced checks
    ############################################################################################

    # @api.multi
    def action_create_invoice(self, partner_type, partner, account, payment):
        self.ensure_one()
        action_date = self.action_date

        if partner_type == 'supplier':
            invoice_type = 'in_invoice'
            journal_type = 'purchase'
            view_id = self.env.ref('account.view_move_form').id
        else:
            invoice_type = 'out_invoice'
            journal_type = 'sale'
            view_id = self.env.ref('account.view_move_form').id

        journal = self.env['account.journal'].search([
            ('company_id', '=', payment.company_id.id),
            ('type', '=', journal_type),
        ], limit=1)

        sequence = journal.sequence

        name = '%s - Ret.check - %s ' % (sequence, payment.check_number)

        #         # si pedimos rejected o reclamo, devolvemos mensaje de rechazo y cuenta
        #         # de rechazo
        #         if operation in ['rejected', 'reclaimed']:
        #             name = 'Rechazo cheque "%s"' % (self.name)
        #         # si pedimos la de holding es una devolucion
        #         elif operation == 'returned':
        #             name = 'Devolución cheque "%s"' % (self.name)
        #         else:
        #             raise ValidationError(_(
        #                 'Debit note for operation %s not implemented!' % (
        #                     operation)))

        inv_line_vals = {
            # 'product_id': self.product_id.id,
            'name': name,
            'account_id': account,
            'price_unit': payment.amount,
            # 'invoice_id': invoice.id,
        }

        inv_vals = {
            # this is the reference that goes on account.move.line of debt line
            # 'name': name,
            # this is the reference that goes on account.move
            'returned_check_id': payment.id,
            'check_number': payment.check_number,
            'ref': name,
            'invoice_date': action_date,
            'invoice_origin': name,
            # 'invoice_payment_ref': name,
            # 'journal_id': journal.id,
            # this is done on muticompany fix
            # 'company_id': journal.company_id.id,
            'partner_id': partner.id,
            'move_type': invoice_type,
            # 'payment_ids':[(0, 0, payment)],
            'invoice_line_ids': [(0, 0, inv_line_vals)],
        }
        if payment.currency_id:
            inv_vals['currency_id'] = payment.currency_id.id
        # we send internal_type for compatibility with account_document
        invoice = self.env['account.move'].with_context(
            internal_type='debit_note').create(inv_vals)
        # self._add_operation(operation, invoice, partner, date=action_date)

        return invoice



    #############################################################################################
    # this Function is to create new activity to follow up the created invoice for bounced checks
    ############################################################################################
    # @api.multi
    def action_create_activity(
            self, invoice, payment):

        # print(invoice._name)
        self.ensure_one()
        action_date = self.action_date

        modelsObj = self.env.cr.execute("""SELECT id FROM ir_model 
                          WHERE model = %s""", (str(invoice._name),))
        # info = modelsObj.dictfetchall()
        for obj in self.env.cr.dictfetchall():
            model_id = obj['id']
            # print (model_id)

        act_vals = {

            'date_deadline': payment.due_date,
            'summary': payment.name,
            # 'date_invoice': self.action_date,
            'user_id': self.env.uid,
            'note': 'Hi, Please Follow Up This Invoice , Top Priorety !!',
            'res_id': invoice.id,
            'res_name': invoice.name,
            'res_model': invoice._name,
            'res_model_id': model_id,

        }

        print('Helooooooooooooooooooo', act_vals)
        activity = self.env['mail.activity'].with_context(
            activity_type_id='to_do').sudo().create(act_vals)
        print('Helooooooooooooooooooo22', act_vals)

        return activity

