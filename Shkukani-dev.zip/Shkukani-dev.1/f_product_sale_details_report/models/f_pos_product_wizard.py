# -*- coding: utf-8 -*-

from odoo import models, fields, api, _, tools


class FPosConfigInherit(models.Model):
    _inherit = 'pos.config'

    f_number_shk = fields.Char(string='Customer Number')

class FProductprofit(models.TransientModel):
    _name = 'f.sales.productreport.wiz.csv'
    _description = "Product Sales Analysis / POS  Wizard "



    from_date = fields.Date(string='From',required=True)
    to_date = fields.Date(string='To',required=True)
    f_season = fields.Char(string='Season')
    shop = fields.Many2many('pos.config', string='POS',required=True)

    def _where_prod(self):
        whr = ''
        if self.f_season :
            whr =  whr + "and pt.f_season ilike '%s'"%(self.f_season)

        return whr


    def _query(self):
        return """

        select id as id ,
        customer_no as customer_no , 
        order_no as order_no ,
        type as type,
        date as date ,
        barcode as barcode,
        f_season as f_season,
        qty as qty,
        company_id as company_id,
        price as price ,
        CASE 
        WHEN price < 1 THEN 
            REPLACE(TO_CHAR(price, 'FM0.00'), '.', ',')
        ELSE 
            REPLACE(TO_CHAR(price, 'FM9999999.00'), '.', ',') 
    END AS price_char,
    
        case when total_price_with_disc !=  price then total_price_with_disc else 0 end as price_with_disc , 
           CASE 
        WHEN  (case when total_price_with_disc !=  price then total_price_with_disc else 0 end )< 1 THEN 
            REPLACE(TO_CHAR(case when total_price_with_disc !=  price then total_price_with_disc else 0 end ,'FM0.00'), '.', ',')
        ELSE 
            REPLACE(TO_CHAR(case when total_price_with_disc !=  price then total_price_with_disc else 0 end , 'FM9999999.00'), '.', ',') 
    END AS price_with_disc_char,

  
        product_id as product_id ,
        pos_shop as pos_shop
        
        
        
        from 
     (   
        select l.id as id ,
         c.f_number_shk as customer_no , 
        regexp_replace(o.pos_reference, '[^0-9]', '', 'g') AS order_no,
        case when l.qty >= 0 then 'S'  else 'R' end as type ,
        date(o.date_order) as date ,
        pp.barcode as barcode,
        pt.f_season as f_season,
        abs(l.qty) as qty ,
        %s as company_id,
        pt.list_price /( CASE COALESCE(o.currency_rate, 0) WHEN 0 THEN 1.0 ELSE o.currency_rate END ) AS price ,
        case when abs(l.qty)  != 0 then abs(l.price_subtotal_incl )/abs(l.qty)  else 0 end  as total_price_with_disc, 
    
        l.product_id as product_id ,
        c.id as pos_shop
        
        
        
        
        from pos_order_line l 
        left join product_product pp on (pp.id = l.product_id )
        left join product_template pt  on( pp.product_tmpl_id = pt.id)
        left join pos_order o on (l.order_id = o.id)
        LEFT JOIN pos_session s ON (s.id = o.session_id)
      LEFT JOIN pos_config c ON (c.id = s.config_id)
      
      where o.company_id = %s
     	 and date(o.date_order) >= date('%s')
		 	 and date(o.date_order) <= date('%s')
		 	 and c.id = ANY(ARRAY[%s]) 
		 	 %s

     ) as pos_details

        
        
        """%(self.env.company.id,self.env.company.id,self.from_date
             ,self.to_date,self.shop.ids,self._where_prod())


    def get_product_details(self):

        tools.drop_view_if_exists(self.env.cr, 'f_sales_productreportcsv')
        self.env.cr.execute("""CREATE or REPLACE VIEW f_sales_productreportcsv as (%s)""" % (self._query()))

        tree_id = self.env.ref('f_product_sale_details_report.view_reporscvt_fproductsol_tree').id
        form_id = False
        action = {
            'name': _('Product Sales Analysis Report'),
            'type': 'ir.actions.act_window',
            'view_mode': 'tree',
            'res_model': 'f.sales.productreportcsv',
        }

        return action



