# -*- coding: utf-8 -*-

from . import f_pos_report_products
from . import f_pos_report_payment
from . import f_loyality_card_inherit