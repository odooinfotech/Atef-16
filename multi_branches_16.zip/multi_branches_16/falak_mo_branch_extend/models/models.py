from odoo import models, fields, api

class f_stock_pickingInherit(models.Model):
    _inherit = 'stock.picking'
    
    @api.model
    def create(self, vals):
        
        res = super(f_stock_pickingInherit, self).create(vals)
        print('res',res)
        mo_branch_id = self.env['mrp.production'].search([('name','=',res.origin)]).id
        print('mo_branch_id',mo_branch_id)
        if mo_branch_id :
            print('MO Hereeeee',mo_branch_id)
            res.update({
                'f_related_branch' : res.picking_type_id.f_related_branch.id or False
            })
            
        return res
    
