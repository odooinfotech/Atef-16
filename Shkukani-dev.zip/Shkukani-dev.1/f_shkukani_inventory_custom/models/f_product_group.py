from odoo import models, fields, api, _


class FProductGroup(models.Model):
    _name = 'f.product.group'
    _description = 'Product Group'
    _rec_name = 'f_name'

    f_name = fields.Char(string='Name')