# -*- coding: utf-8 -*-
from odoo import models, fields, api

class f_res_company(models.Model):
    _inherit = 'res.company'
    
    f_allow_multi_branches = fields.Boolean('Allow Multi Branches', help = 'Allow this Company use multiple branches')
    f_comp_branch          = fields.One2many('f.comp.branches','company_id',string ='Branches' ,help = 'List of Branches related to this Company')
    f_default_partner_branch= fields.Boolean('Partner Default Branch')


    @api.onchange('f_allow_multi_branches')
    def _empty_branches(self):
        if not self.f_allow_multi_branches:
            print(self.id,self.name,self)
            
            self.env['f.comp.branches'].search([('company_id.id','=',self._origin.id)]).write({'company_id':False})
            
            #self.write({'f_comp_branch' : False})
        else :
            
            domain =  ['|',('company_id' , '=',self._origin.id),('company_id' , '=',False)]    
            return {'domain': {'f_comp_branch': domain}}


