from odoo import models, fields, api, _


class FAccountJournalInherit(models.Model):
    _inherit = "account.journal"
    
    f_short_name = fields.Char(string=' Short Description')
       


