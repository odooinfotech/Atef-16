from odoo import models, fields, api, _
from collections import defaultdict
from odoo.exceptions import ValidationError


class FProductProductInherit(models.Model):
    _inherit = 'product.product'

    # New Fields
    f_article = fields.Char(string='Article', related='product_tmpl_id.f_article', store=True)
    f_season = fields.Char(string='Season', related='product_tmpl_id.f_season', store=True)
    f_index = fields.Char(string='Index')
    f_section = fields.Many2one(string='Section', related='product_tmpl_id.f_section', store=True)
    f_brand_id = fields.Many2one(related='product_tmpl_id.f_brand_id', string='Brand Name', store=True)
    f_taric = fields.Char(string='Taric')
    f_group = fields.Many2one(string='Group', related='product_tmpl_id.f_group', store=True)
    f_article_category = fields.Many2one(string='Article Category', related='product_tmpl_id.f_article_category',
                                         store=True)
    f_hs_code = fields.Char(string='HS Code', related='product_tmpl_id.f_hs_code', store=True)
    f_textile_composition = fields.Char(string='Textile Composition')
    f_sim = fields.Char(string='Sim', related='product_tmpl_id.f_sim', store=True)
    f_collection_trend = fields.Many2one('f.collection.trend', string='Collection Trend')
    f_brand = fields.Char(string='Brand', related='product_tmpl_id.f_brand', store=True)
    f_gander = fields.Char(string='Gander', related='product_tmpl_id.f_gander', store=True)
    f_safety_warning = fields.Char(string='Safety Warning', related='product_tmpl_id.f_safety_warning', store=True)

    f_color_code = fields.Char(string="Color Code", compute='_compute_f_color_code', store=True)

    @api.depends('product_template_attribute_value_ids.attribute_id',
                 'product_template_attribute_value_ids.product_attribute_value_id')
    def _compute_f_color_code(self):
        for product in self:
            color_code = False
            for ptav in product.product_template_attribute_value_ids:
                if ptav.attribute_id.f_type == 'color':
                    if ptav.product_attribute_value_id in ptav.attribute_id.value_ids:
                        color_code = ptav.product_attribute_value_id.f_code
                        break
            product.f_color_code = color_code

    @api.constrains('barcode')
    def _check_barcode_uniqueness(self):
        """Ensure that the barcode is unique among products and packagings within the same company."""
        for record in self:
            if not record.barcode:
                continue

            domain = [
                ('barcode', '=', record.barcode),
                '|',
                ('company_id', '=', self.env.company.id),
                ('company_id', '=', False),
            ]

            matched_products = self.sudo().search(domain, order='id')
            if len(matched_products) > 1:
                products_by_barcode = defaultdict(list)
                for product in matched_products:
                    products_by_barcode[product.barcode].append(product)

                duplicates_as_str = "\n".join(
                    _("- Barcode \"%s\" already assigned to product(s): %s") %
                    (barcode, ", ".join(p.display_name for p in products))
                    for barcode, products in products_by_barcode.items() if len(products) > 1
                )
                raise ValidationError(_("Barcode(s) already assigned:\n\n%s") % duplicates_as_str)

            if self.env['product.packaging'].sudo().search(domain, order="id", limit=1):
                raise ValidationError(_("A packaging already uses the barcode in this company"))
