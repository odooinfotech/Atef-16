# -*- coding: utf-8 -*-
{
    'name': "Falak Generate Shkukani Files",

    'summary': """ This Module For Generate Shkukani Files""",

    'description': """
        
    """,

    'author': "Falak Solutions",
    #'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['base','stock','product','point_of_sale','hr'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/f_product_attribute_value_inherit.xml',
        'views/f_sale_file.xml',
        'views/f_hr_employee_inherit.xml',
        'views/f_pos_payment_method_inherit.xml',
        'views/f_pos_config_inherit.xml',
    ],

}
