# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models


class SaleReport(models.Model):
    _inherit = 'sale.report'

    f_article = fields.Char(string='Artical')
    f_section = fields.Many2one('f.product.section',string= 'Section')

    def _select_additional_fields(self):
        res = super()._select_additional_fields()
        res['f_article'] = """ t.f_article """
        res['f_section'] = """ t.f_section """
        return res

    def _group_by_sale(self):
        res = super()._group_by_sale()
        res += """,
            t.f_article,t.f_section"""
        return res
