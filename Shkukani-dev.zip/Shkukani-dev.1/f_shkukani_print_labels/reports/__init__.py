from . import f_product_label_template
