# -*- coding: utf-8 -*-

#from . import f_multi_payments_lines
from . import f_inherit_partner
from . import f_inherit_user
from . import f_multi_payments
from . import f_account_payment_inherit
from . import f_account_register_payment_inherit
from . import f_account_move_iherit
from . import f_multi_paymeny_report
from . import f_account_journal_inherit
from . import f_payment_purpose

