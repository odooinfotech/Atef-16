from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError


class FPosConfigInherit(models.Model):
    _inherit = 'pos.config'

    f_number = fields.Char(string='Number')

    @api.onchange('f_number')
    def _f_onchange_number(self):
        for rec in self:
            number = rec.f_number
            if number and len(number) > 3:
                raise ValidationError(_('Number must be less than 3 letters.'))
            if number and not number.isdigit():
                raise ValidationError(_('Number must be only numbers.'))