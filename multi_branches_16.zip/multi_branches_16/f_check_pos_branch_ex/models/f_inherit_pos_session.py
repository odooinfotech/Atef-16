from odoo import models, _
import logging

_logger = logging.getLogger(__name__)


class FPosSessionInherit(models.Model):
    _inherit = 'pos.session'

    def create_payment(self, vals):

        

        # Override function to create multi payment header and payment details
        lines = []
        lines.append((0, 0, vals))

        multi_payment = self.env['f.multi.payments'].search([('f_pos_order_id', '=', vals['pos_order_id'])])

        branch = self.env.user.f_default_branch.id
        if self.env.company.f_default_partner_branch:
            if 'f_partner_id' in vals:
                partner = self.sudo().env['res.partner'].sudo().search([('id', '=', vals['f_partner_id'])], limit=1)
                if partner.f_related_branch:
                    branch = partner.f_related_branch.id
                else:
                    branch = self.env.user.f_default_branch.id



        if multi_payment:
            result = multi_payment.sudo().write({'f_payment_lines': lines, 'f_multi_pay_state': 'draft'})





            for pay in multi_payment:
                for pay_line in pay.f_payment_lines.sudo():
                    pay_line.sudo().write({
                        'f_related_branch': branch
                    })

                    
                    move = self.sudo().env['account.move'].sudo().search([('id', '=', pay_line.move_id.id)])
                    move.sudo().write({
                        'f_related_branch': branch
                    })
           
                
        else:
            multi_payment = self.env['f.multi.payments'].sudo().create({

                'f_payment_type': 'inbound',
                'f_partner_type': 'customer',
                'f_partner_id': vals['partner_id'],
                'f_currency_id': vals['currency_id'],
                'f_payment_date': vals['date'],
                'f_pay_reference': vals['ref'],
                'f_pos_session_id': vals['pos_session_id'],
                'f_pos_order_id': vals['pos_order_id'],
                'f_payment_lines': lines

            })
        for pay_line in multi_payment.f_payment_lines.sudo():
                pay_line.sudo().write({
                        'f_related_branch': branch
                    })
                move = self.sudo().env['account.move'].search([('id', '=', pay_line.move_id.id)])
                move.sudo().write({
                    'f_related_branch': branch
                })
        multi_payment.sudo().f_post_payment()
        
        return multi_payment
