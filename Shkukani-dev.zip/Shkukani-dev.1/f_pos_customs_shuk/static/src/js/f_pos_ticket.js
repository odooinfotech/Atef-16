odoo.define('f_pos_customs_shuk.f_pos_ticket', function (require) {
    "use strict";


			var {Orderline,PosGlobalState }  = require('point_of_sale.models');
		    var utils = require('web.utils');
		    const Registries = require('point_of_sale.Registries');



    const PosexattrPosGlobalState = (PosGlobalState) => class PosexattrPosGlobalState extends PosGlobalState {
        async _processData(loadedData) {

                this.attrabiuts_all_custom = loadedData['product.attribute.value'] || [];
                await super._processData(...arguments);



        }

    }
    Registries.Model.extend(PosGlobalState, PosexattrPosGlobalState);





		    const FOrderline = (Orderline) =>
    class extends Orderline {
        constructor(obj, options) {
            super(...arguments);
		         }

		         export_for_printing() {
    const result = super.export_for_printing.apply(this, arguments);

    const name_pr = this.get_product().display_name;

    // Extract the product name before parentheses
    const productName_char = name_pr.split(" (")[0].trim();

    // Extract values inside parentheses (if they exist)
    let extractedValues = [];
    const match = name_pr.match(/\((.*?)\)/);

    if (match && match[1]) {
        extractedValues = match[1].split(', ').map(val => val.trim());
    }

    // Find matching objects from the attributes array
    const matchedValues = extractedValues.map(value => {
    const match = this.pos.attrabiuts_all_custom.find(obj => obj.name === value);
    console.log('5555555',match ? (match.f_code || match.name) : value)
    return match ? (match.f_code || match.name) : value; // Return code if exists, otherwise return name
});

console.log('5555555extractedValues',extractedValues)
console.log('5555555',matchedValues)


    result.F_DETAILS =  matchedValues.join(" . ");
    result.productName_char = productName_char;

    return result;
}






		             }
    Registries.Model.extend(Orderline, FOrderline);



});


