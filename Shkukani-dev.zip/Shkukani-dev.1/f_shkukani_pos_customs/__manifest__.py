# -*- coding: utf-8 -*-
{
    'name': "Falak Shkukani POS Custom",

    'summary': """ This Module For Shkukani POS Customizations""",

    'description': """
        - Add Product Index in Product search in POS Product Screen
    """,

    'author': "Falak Solutions",
    #'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['base','point_of_sale','f_shkukani_inventory_custom','sale_management','f_shkukani_contact_custom'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/f_report_pos_order_inherit.xml',
        'views/f_hide_dots_custom.xml',
        'views/f_pos_config_inherit.xml',
        'data/f_sale_order_menuitem_custom.xml',
        'data/f_qmenuitem_custom.xml',
        'data/f_pos_order_pivot.xml',

    ],

    'assets': {
        'point_of_sale.assets': [
            'f_shkukani_pos_customs/static/src/js/db.js',
            'f_shkukani_pos_customs/static/src/js/Screens/PartnerListScreen/PartnerListScreen.js',
        ],
    },

}
