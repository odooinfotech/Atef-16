from odoo import models, fields, api


class FCheckSetting(models.TransientModel):
    _inherit = 'res.config.settings'

    f_set_due_date_limit = fields.Boolean(string='Due Date Limit')
    f_warn_archive_contacts = fields.Boolean(string='Prevent checks actions on archived contacts')

    f_warn_deposit= fields.Boolean(string=' deposit')
    f_warn_collect= fields.Boolean(string=' collect')
    f_warn_return = fields.Boolean(string=' return')
    f_warn_endorse= fields.Boolean(string=' endorse')
    f_warn_bounc = fields.Boolean(string=' bounce')
    f_warn_unendorse = fields.Boolean(string=' unendorse')
    f_warn_release = fields.Boolean(string=' release')
    f_warn_undeposit = fields.Boolean(string=' undeposit')
    f_warn_uncollect = fields.Boolean(string=' uncollect')
    f_warn_repay = fields.Boolean(string=' repay')
    f_warn_entry_endorse = fields.Boolean(string=' entry endorse')












    f_due_date_limit_period = fields.Integer(string='Limit Period', default=0)

    f_warn_check_due_date = fields.Boolean(string='Show Warning on Due Date ')
    f_check_due_warn_period = fields.Integer(string='Period to Warn', default=0, help="Number of Days to Show warning "
                                                                                      "on Check due date")

    f_restrict_check_due_date = fields.Boolean(string='Restrict Check Due Date ')
    f_check_due_block_period = fields.Integer(string='Period to Block', default=0, help="Number of Days to Block Check "
                                                                                        "due date")

    f_required_account = fields.Boolean('Account Number')
    f_validate_due_date_deposit = fields.Boolean('Due Date on Deposit')

    f_due_date_check_onchecks = fields.Boolean('Prevent Collect checks or Send/Receive Payment If due date greater than current date')

    def get_values(self):
        res = super(FCheckSetting, self).get_values()

        res.update(

            f_warn_release=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_release'),
            f_warn_deposit=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_deposit'),
            f_warn_collect=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_collect'),
            f_warn_return=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_return'),
            f_warn_endorse=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_endorse'),
            f_warn_bounc=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_bounc'),
            f_warn_unendorse=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_unendorse'),
            f_warn_undeposit=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_undeposit'),
            f_warn_uncollect=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_uncollect'),
            f_warn_repay=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_repay'),
            f_warn_entry_endorse=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_entry_endorse'),

            f_warn_archive_contacts=self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_archive_contacts'),

           


            f_restrict_check_due_date=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_restrict_check_due_date'),
            f_check_due_block_period=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_check_due_block_period'),

            f_required_account=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_required_account'),

            f_warn_check_due_date=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_warn_check_due_date'),
            f_check_due_warn_period=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_check_due_warn_period'),
            f_validate_due_date_deposit=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_validate_due_date_deposit'),
            f_set_due_date_limit=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_set_due_date_limit'),
            f_due_date_limit_period=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_due_date_limit_period'),

            f_due_date_check_onchecks=self.env['ir.config_parameter'].sudo().get_param(
                'check_management.f_due_date_check_onchecks'),

        )

        return res

    def set_values(self):
        super(FCheckSetting, self).set_values()
        param = self.env['ir.config_parameter'].sudo()

        f_warn_archive_contacts = self.f_warn_archive_contacts or False

        f_restrict_check_due_date = self.f_restrict_check_due_date or False
        f_check_due_block_period = self.f_check_due_block_period or False
        f_required_account = self.f_required_account or False
        f_validate_due_date_deposit = self.f_validate_due_date_deposit or False

        f_warn_check_due_date = self.f_warn_check_due_date or False
        f_check_due_warn_period = self.f_check_due_warn_period or False

        f_set_due_date_limit = self.f_set_due_date_limit or False
        f_due_date_limit_period = self.f_due_date_limit_period or False

        f_due_date_check_onchecks = self.f_due_date_check_onchecks or False
    

        f_warn_release = self.f_warn_release or False
        f_warn_deposit = self.f_warn_deposit or False
        f_warn_collect = self.f_warn_collect or False
        f_warn_return = self.f_warn_return or False
        f_warn_entry_endorse = self.f_warn_entry_endorse or False
        f_warn_endorse = self.f_warn_endorse or False
        f_warn_bounc = self.f_warn_bounc or False
        f_warn_unendorse = self.f_warn_unendorse or False
        f_warn_undeposit = self.f_warn_undeposit or False
        f_warn_uncollect = self.f_warn_uncollect or False
        f_warn_repay = self.f_warn_repay or False

        param.sudo().set_param('check_management.f_restrict_check_due_date', f_restrict_check_due_date)
        param.sudo().set_param('check_management.f_check_due_block_period', f_check_due_block_period)
        param.sudo().set_param("check_management.f_required_account", f_required_account)
        param.sudo().set_param("check_management.f_validate_due_date_deposit", f_validate_due_date_deposit)
        param.sudo().set_param('check_management.f_warn_check_due_date', f_warn_check_due_date)
        param.sudo().set_param('check_management.f_check_due_warn_period', f_check_due_warn_period)
        param.sudo().set_param('check_management.f_set_due_date_limit', f_set_due_date_limit)
        param.sudo().set_param('check_management.f_due_date_limit_period', f_due_date_limit_period)
        param.sudo().set_param('check_management.f_due_date_check_onchecks', f_due_date_check_onchecks)
    
        param.sudo().set_param('check_management.f_warn_archive_contacts', f_warn_archive_contacts)

        param.sudo().set_param('check_management.f_warn_release', f_warn_release)
        param.sudo().set_param('check_management.f_warn_deposit', f_warn_deposit)
        param.sudo().set_param('check_management.f_warn_collect', f_warn_collect)
        param.sudo().set_param('check_management.f_warn_return', f_warn_return)
        param.sudo().set_param('check_management.f_warn_entry_endorse', f_warn_entry_endorse)
        param.sudo().set_param('check_management.f_warn_endorse', f_warn_endorse)
        param.sudo().set_param('check_management.f_warn_bounc', f_warn_bounc)
        param.sudo().set_param('check_management.f_warn_unendorse', f_warn_unendorse)
        param.sudo().set_param('check_management.f_warn_undeposit', f_warn_undeposit)
        param.sudo().set_param('check_management.f_warn_uncollect', f_warn_uncollect)
        param.sudo().set_param('check_management.f_warn_repay', f_warn_repay)











