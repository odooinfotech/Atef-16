# -*- coding: utf-8 -*-
{
    'name': "Multi Branches POS Ext",

    'summary': """
        Multi Branches Management extenssion for POS
        """,

    'description': """
        This Module Manages  the concept of Multi Branches in Odoo 15 for POS 
    """,

    'author': "Falak Solutions",
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0',

    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['point_of_sale','f_multi_branches_management'],

    # always loaded
    'data': [
        
        'security/f_record_rules.xml',
        'views/f_pos_config_view_inherit.xml',
        
    ],

    
}
