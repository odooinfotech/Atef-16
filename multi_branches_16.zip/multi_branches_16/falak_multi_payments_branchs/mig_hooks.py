# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
import logging
from odoo import api, SUPERUSER_ID
_logger = logging.getLogger(__name__)


def update_multi_payments_branches(cr, registry):
    """
    Update the Brach for  Multi payment Header to be same as existing  payment
    """
    env = api.Environment(cr, SUPERUSER_ID, {})
    payments = env['account.payment'].search(
        [('partner_id', '!=', False), ('f_related_branch', '!=', False)])
    for payment in payments:
        _logger.info('Updatung Multi payment Header Branch for payment %s' % payment.id)
        try :
            payment.f_parent_id.write({'f_related_branch':payment.f_related_branch.id})
        except ValueError:
            _logger.error('result ' % ValueError)