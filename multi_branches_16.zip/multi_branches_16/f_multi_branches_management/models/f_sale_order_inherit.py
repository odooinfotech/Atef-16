from odoo import models, fields, api


class FSaleAdvancePayment(models.TransientModel):
    _inherit ="sale.advance.payment.inv"
    
    
    def _prepare_invoice_values(self, order, name, amount, so_line):
        res = super(FSaleAdvancePayment, self)._prepare_invoice_values(order, name, amount, so_line)
        #print('order',order)
        res['f_related_branch'] = order.f_related_branch.id
        return res




class f_sale_order(models.Model):
    _inherit = 'sale.order'

    @api.model
    def create(self, vals):
        res = super(f_sale_order, self).create(vals)
        if self.env.company.f_default_partner_branch:
            if res.partner_id.f_related_branch:
                res.update({
                    'f_related_branch': res.partner_id.f_related_branch.id or False
                })
            else:
                res.update({
                    'f_related_branch': self.env.user.f_default_branch.id or False
                })

        return res

    def write(self, vals):
        if self.env.company.f_default_partner_branch:
            if 'partner_id' in vals:
                partner = self.sudo().env['res.partner'].sudo().search([('id', '=', vals['partner_id'])], limit=1)
                if partner.f_related_branch:
                    vals['f_related_branch'] = partner.f_related_branch.id
                else:
                    vals['f_related_branch'] = self.env.user.f_default_branch.id

        return super(f_sale_order, self).write(vals)

    
    #Override to add f_related_branch
    def _get_invoice_grouping_keys(self):
        if self.env.user.company_id.f_allow_multi_branches :
            return ['company_id', 'partner_id', 'currency_id','f_related_branch']
        else : 
            return ['company_id', 'partner_id', 'currency_id']
    
    #Override to update branch 
    def _prepare_invoice(self):
        res = super(f_sale_order, self)._prepare_invoice()
        res['f_related_branch'] = self.f_related_branch.id
        return res

    # defaultValue 
    def _get_default_branch(self):
         #user_default_branch = 'None' 
         user_default_branch = False
         if self.env.company.f_allow_multi_branches ==True : 
                 

             context = self._context
             current_uid = context.get('uid')
             print('current_uid',current_uid)
             user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
             if user_default_branch :
                 comp = self.env['f.comp.branches'].search([('id', '=', user_default_branch.id)]).company_id.id
                 if comp != self.env.company.id :
                     print(self.env.user.company_id.id)
                     branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.company.id)],limit=1)
                     print('branch',branch)
                     user_default_branch = branch.id
             else :
                 f_user_branches = self.env['res.users'].browse(current_uid).f_allowed_branches
                 if len(f_user_branches.ids) >= 1 :
                     user_default_branch = self.env['res.users'].browse(current_uid).f_allowed_branches[0]
                 else :
                    user_default_branch = self.env['f.comp.branches'].search(
                 [('company_id.id', '=', self.env.company.id), ('f_for_website', '=', True)], limit=1)




         print('user_default_branch',user_default_branch)
         return user_default_branch


    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, default=_get_default_branch, tracking=True)
    
    
    

class f_sale_orderline(models.Model):
    _inherit = 'sale.order.line'
     
    f_related_branch = fields.Many2one('f.comp.branches',check_company=True,string = 'Related Branch',related="order_id.f_related_branch",store=True)
