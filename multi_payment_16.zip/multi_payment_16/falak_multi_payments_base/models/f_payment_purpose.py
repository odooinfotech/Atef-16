from odoo import models, fields, api
class F_Account_Payment_Purpose(models.Model):
    _name = 'f.payment.purpose'
    _description = " Payment Purpose"
    _rec_name = 'f_name'

    f_name = fields.Char('Payment Purpose')
