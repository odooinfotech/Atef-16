# -*- coding: utf-8 -*-
{
    'name': "Multi Payments Base",

    'summary': """
       this Module allows the user to pay multiple payments in one transaction""",

    'description': """
       - Add Special Access for the original payments list in vendors and customers 
          the access is allowed by enabling "See Payments Menu " in user access.
           
       - Disable Create & Edit for the original payments list in vendors and customers.
       
       - Add Customer/Vendor Receipts new Menus in 
         Accounting->Customers/Vendors Menus for Multi Payment Usage.  
         
       - In the Installation of the Module it gets all the previous payments and 
         create new multi payment header for each one so 
         all payments in the system should be in the same structure.
          
       - Multi Payments Features : 
           - Define one payment header with multi lines for multi payments 
           
           - show the Total of the payments using the Company Currency 
           - Show  each payment amount in Company Currency 
           - Showing The EX if the payment is done using forien currency 
           - Ability to change the final Value in Company Currency and the EX is changed based on the value 
        
        - The New Action "View Payments" in the bottom of the invoice to Display the Related Multi payment/s
            - This works in both cases if the invoice is paid by one or many Multi Payments 
        
        - Add New Field For the Multi Payment Id in the Payment View 
        
        - change the Behavior of Register Payment in the Invoice Screen : 
            - if the Action is Done for one invoice the system will create a multi payment 
            - if the user chooses more than one invoice the system will use the same current behavior
               with creating multi payment for each payment 
            - in case of using Group payment in the register payment the system will use the same current behavior
               with creating multi payment for each payment
               
        - Add The transfer payment under new item in the accounting menue named "Transfer " 
           from this screen the user can only create transfer payment 
       
    """,

    'author': "Falak Solutions",
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0.1.0.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['base','account','web','account_accountant','base_automation'],

    # always loaded
    'data': [
        'security/f_group_access.xml',
        'security/f_rules.xml',
        'security/ir.model.access.csv',
        'reports/f_multi_payment_receipt_action.xml',
        'reports/f_multi_payment_receipt.xml',
        'reports/f_multi_payment_receipt_action_thermal.xml',
        'reports/f_multi_payment_receipt_thermal.xml',
        'views/f_multi_payments_view.xml',
        #'wizard/f_multi_payments_lines_view.xml',
        'views/f_account_payment_view_inherited.xml',
        'views/f_account_move_form_view_inherit.xml',
        'views/f_account_journal_form_view_inherit.xml',
        'demo/data.xml',
        'demo/f_sequence.xml',
        'views/f_inherit_user.xml',
        'views/f_payment_purpose.xml',
        'views/f_inherit_partner.xml',
    ],
    # only loaded in demonstration mode
    'demo': [
        'demo/f_sequence.xml',
    ],
    'post_init_hook': 'multi_payment_init',
}
