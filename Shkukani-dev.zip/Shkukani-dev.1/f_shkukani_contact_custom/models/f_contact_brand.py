from odoo import models, fields, api, _


class FContactBrand(models.Model):
    _name = 'f.contact.brand'
    _description = 'Contact Brand'
    _rec_name = 'f_name'

    f_name = fields.Char(string='Name')
