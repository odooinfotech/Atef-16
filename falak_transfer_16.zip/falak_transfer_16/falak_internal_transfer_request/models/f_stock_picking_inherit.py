from odoo import models, fields, api,_
from datetime import datetime
from odoo.exceptions import UserError


## Inherit stock.picking model         
class FShipmentHeader(models.Model): 
    _inherit = 'stock.picking'
    
    f_internal_transfer_id = fields.Many2one('f.internal.request.header',string="Internal Transfer Request", readonly=True)

    def button_validate(self):
        res = super(FShipmentHeader, self).button_validate()

        for picking in self:
            if picking.f_internal_transfer_id:
                receive_transaction = self.env['stock.picking'].sudo().search([
                    ('f_name_sequance', '=', picking.f_name_sequance)
                ])

                receive_transaction.write({'f_internal_transfer_id': picking.f_internal_transfer_id.id})

        return res
               