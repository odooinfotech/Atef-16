# -*- coding: utf-8 -*-
{
    'name': "f_pos_customs_shuk",

    'summary': """
        Short (1 phrase/line) summary of the module's purpose, used as
        subtitle on modules listing or apps.openerp.com""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Falak Solutions",
    'license': 'LGPL-3',

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','pos_hr','point_of_sale','f_shkukani_inventory_custom','f_generate_shkukani_files','bi_pos_gift_receipt','f_pos_shop_logo'],

    # always loaded
    'data': [
       #  'security/ir.model.access.csv',
        'views/f_pos_order.xml',
        'views/f_employee_inherit.xml',
        'views/f_sale_inherit.xml',

      #  'views/templates.xml',
    ],

    'assets': {

        'point_of_sale.assets': [
            'f_pos_customs_shuk/static/src/css/pos.css',
            '/f_pos_customs_shuk/static/src/xml/*.xml',
            '/f_pos_customs_shuk/static/src/js/*.js',
        ]

    },




}
