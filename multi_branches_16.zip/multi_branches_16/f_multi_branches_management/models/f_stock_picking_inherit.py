from odoo import models, fields, api

class FStockPickingInherit(models.Model):
    _inherit = 'stock.picking'




    def _valid_field_parameter(self, field, name):
        
        return name == 'tracking' or super()._valid_field_parameter(field, name)
    
    @api.model
    def create(self, vals):
        
        res = super(FStockPickingInherit, self).create(vals)

        wh_branch_id = self.env['sale.order'].sudo().search([('name','=',res.origin)]).warehouse_id.f_related_branch.id
        print('wh_branch_id',wh_branch_id)
        if wh_branch_id :
            res.update({
                'f_related_branch' : wh_branch_id or False
            })
        else :
          print('self.picking_type_id.f_related_branch.id',vals['picking_type_id'])
          pt_branch =  self.env['stock.picking.type'].sudo().search([('id','=',vals['picking_type_id'])]).f_related_branch.id
          res.update({
            'f_related_branch' : pt_branch
        })
        return res
    
    def _get_default_branch(self):
         user_default_branch = False
         
         if self.env.company.f_allow_multi_branches ==True :
             if self.env.company.f_allow_multi_branches ==True : 
                     
                 print(self)
                 context = self._context
                 current_uid = context.get('uid')
                 if not current_uid : 
                     current_uid = self.env.user.id
                 print('current_uid',current_uid,self.env.user.id)
                 user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
                 if user_default_branch :
                     comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id
                     if not self.f_related_branch  :
                         if comp == self.env.company.id :
                             self.f_related_branch  = user_default_branch
                             print('user_default_branch',user_default_branch)
                         else :
                             print(self.env.user.company_id.id)
                             branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.company.id)],limit=1)
                             print('branch',branch)
                             self.f_related_branch  = branch.id
                             user_default_branch = branch.id

                 else:
                    user_default_branch = self.env['res.users'].browse(current_uid).f_allowed_branches[0]
         return user_default_branch
    
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, default=_get_default_branch, tracking=True)
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')


class f_stock_picking_type(models.Model):
    _inherit = 'stock.picking.type'
    
    def _valid_field_parameter(self, field, name):
        
        return name == 'tracking' or super()._valid_field_parameter(field, name)
    
    
    
    def _get_default_branch(self):
         user_default_branch = False
         if self.company_id.f_allow_multi_branches ==True :    
             if self.env.user.company_id.f_allow_multi_branches ==True : 
                      
                 context = self._context
                 current_uid =  context.get('uid')
                 print('current_uid',current_uid)
                 user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
                 comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id
                 print('comp',comp)
                 if not self.f_related_branch  :
                     print('In IFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFFF')
                     self.f_related_branch  = user_default_branch
                     if comp != self.env.user.company_id.id :
                         #print(self.env.user.company_id.id)
                         branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.user.company_id.id)],limit=1)
                         #print('branch',branch)
                         self.f_related_branch  = branch.id
                         user_default_branch = branch.id                    
         return user_default_branch
    
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, default=_get_default_branch, tracking=True)
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')


