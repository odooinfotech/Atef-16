from odoo import models, fields, api, _


class FAccountMoveInherit(models.Model):
    _inherit = "account.move"

    def f_print_custom_label(self):
        copies = []
        for rec in self:
            for line in rec.invoice_line_ids:
                vals = {
                    'f_product_id': line.product_id.id,
                    'f_copy': line.quantity
                }
                copies.append((0, 0, vals))

        return {
            'name': _('Print Options'),
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'f.print.options.wizard',
            'target': 'new',
            'context': {
                'default_f_print_copy': copies
            },
        }
