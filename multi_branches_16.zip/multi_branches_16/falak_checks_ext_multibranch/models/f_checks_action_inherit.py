from odoo import models, fields, api, _


class FChequeWizardInherit(models.TransientModel):
    _inherit = 'cheque.wizard'
    
    
    #@api.multi
    def check_actions(self):
         super(FChequeWizardInherit,self).check_actions()
         print('check_actions check_actions check_actions check_actions')
         
         selected_payments = self.env['account.payment'].browse(self._context.get('active_ids'))
         action_type = self._context.get('action_type')
         
         print(selected_payments,action_type)
         for current_payment in selected_payments :
             print(current_payment.f_is_multi_branch)
             if   current_payment.f_is_multi_branch :
                 
                 moves = self.env['account.move'].search([('payment_id','=',current_payment.id)])
                 for move in moves : 
                     move.write({'f_related_branch':current_payment.f_related_branch})
                 #print(current_payment.move_id.line_ids,current_payment.move_id)
                 
                 move_lines = self.env['account.move.line'].search([('payment_id','=',current_payment.id),('action_type','ilike',action_type)])
                 for line in move_lines : 
                     print('line',line)
                     line.write({'f_related_branch':current_payment.f_related_branch})
                     
                 if action_type == 'endorse':    
                     endorsed_payments =  self.env['account.payment'].search([('source_payment','=',current_payment.id)])
                     for pay in endorsed_payments :
                         pay.write({'f_related_branch':current_payment.f_related_branch})
                 
                 if action_type == 'return' :
                     returned_check_invoices =  self.env['account.move'].search([('returned_check_id','=',current_payment.id)])           
                     for inv in returned_check_invoices : 
                         inv.write({'f_related_branch':current_payment.f_related_branch})

    