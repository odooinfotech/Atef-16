# -*- coding: utf-8 -*-
{

    'name': "Check Management Base",
    'summary': """
       """,
    

    'description': """
    Check Management Base 
    """,

    'author': "Falak Solutions",
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/12.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    #'category': 'Uncategorized',
    'version': '16.0.1.0.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    #'account_accountant_check_printing'
    'depends': ['account','base','contacts','mail','hr','account_accountant','account_check_printing'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/f_rules.xml',
        'demo/f_data.xml',
        'wizard/f_check_payment_details_view.xml',
        'wizard/f_print_bulk_report.xml',
        'views/f_account_reg_payment_inherit.xml',
        'views/f_account_journal_view_inherit.xml',
        'views/f_account_move_line_view_inherit.xml',
       
       'views/f_account_move_view_inherit.xml',
        'views/f_bank_config_inherit.xml',
        'views/f_bank_branches_view.xml',
        'views/f_res_config_inherit.xml',
        'views/f_account_account_view_inherit.xml',
        'views/f_bulk_actions.xml',
        'reports/f_bulk_check_report.xml',
        'reports/f_bulk_check_report_tmp.xml',
        'reports/f_check_info_report_temp.xml',
        'views/f_res_partner_inherit_view.xml',
         'views/f_account_payment_view_inherit.xml',
        'views/f_company_inherit.xml',




    ],
}
