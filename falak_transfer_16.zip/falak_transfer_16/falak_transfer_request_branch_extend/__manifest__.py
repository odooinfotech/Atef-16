# -*- coding: utf-8 -*-
{
    'name': "Falak Internal Transfer Request Branch",

    'summary': """
        This Module is an extension for the internal transfer request to support Multi Branches 
        """,

    'description': """
        
    """,

    'author': "Falak Solutions",
    'license': 'LGPL-3',
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','stock','f_multi_branches_management','falak_internal_transfer_request'],

    # always loaded
    'data': [
        'security/f_record_rules.xml',
        'views/f_tranfer_req_inherit_view.xml',
    ],

}
