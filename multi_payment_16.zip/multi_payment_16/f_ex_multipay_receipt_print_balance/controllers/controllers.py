# -*- coding: utf-8 -*-
# from odoo import http


# class FExMultipayReceiptPrintBalance(http.Controller):
#     @http.route('/f_ex_multipay_receipt_print_balance/f_ex_multipay_receipt_print_balance', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/f_ex_multipay_receipt_print_balance/f_ex_multipay_receipt_print_balance/objects', auth='public')
#     def list(self, **kw):
#         return http.request.render('f_ex_multipay_receipt_print_balance.listing', {
#             'root': '/f_ex_multipay_receipt_print_balance/f_ex_multipay_receipt_print_balance',
#             'objects': http.request.env['f_ex_multipay_receipt_print_balance.f_ex_multipay_receipt_print_balance'].search([]),
#         })

#     @http.route('/f_ex_multipay_receipt_print_balance/f_ex_multipay_receipt_print_balance/objects/<model("f_ex_multipay_receipt_print_balance.f_ex_multipay_receipt_print_balance"):obj>', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('f_ex_multipay_receipt_print_balance.object', {
#             'object': obj
#         })
