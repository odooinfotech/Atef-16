odoo.define('f_pos_customs_shuk.LoginScreen', function (require) {
    'use strict';
    const PosComponent = require('point_of_sale.PosComponent');
    const Registries = require('point_of_sale.Registries');
    const useSelectEmployee = require('f_pos_customs_shuk.FcustomdSelectCashierMixin');
    const { useBarcodeReader } = require('point_of_sale.custom_hooks');

    class FdasspinLoginScreen extends useSelectEmployee(PosComponent) {
       setup() {
            super.setup();
        }

        back() {

                this.props.resolve({ confirmed: false, payload: false });
                this.trigger('close-temp-screen');
                this.showScreen('ProductScreen');

            }





        confirm() {
            this.props.resolve({ confirmed: true, payload: true });
            this.trigger('close-temp-screen');
        }


         async selectCashier() {
            if (await super.selectCashier()) {
                this.back();
            }
        }




    }
    FdasspinLoginScreen.template = 'FdasspinLoginScreen';

    Registries.Component.add(FdasspinLoginScreen);

    return FdasspinLoginScreen;
});
