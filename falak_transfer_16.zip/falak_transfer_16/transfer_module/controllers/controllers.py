# -*- coding: utf-8 -*-
# from odoo import http


# class TransferModule(http.Controller):
#     @http.route('/transfer_module/transfer_module/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/transfer_module/transfer_module/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('transfer_module.listing', {
#             'root': '/transfer_module/transfer_module',
#             'objects': http.request.env['transfer_module.transfer_module'].search([]),
#         })

#     @http.route('/transfer_module/transfer_module/objects/<model("transfer_module.transfer_module"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('transfer_module.object', {
#             'object': obj
#         })
