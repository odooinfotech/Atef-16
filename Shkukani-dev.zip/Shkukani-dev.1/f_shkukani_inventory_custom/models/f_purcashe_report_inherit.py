# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

import re

from odoo import api, fields, models
from odoo.exceptions import UserError
from odoo.osv.expression import expression


class PurchaseReport(models.Model):
    _inherit = "purchase.report"

    f_article = fields.Char(string='Artical')


    def _select(self):
        return super(PurchaseReport, self)._select() + ", t.f_article as f_article"



    def _group_by(self):
        return super(PurchaseReport, self)._group_by() + ", t.f_article"
