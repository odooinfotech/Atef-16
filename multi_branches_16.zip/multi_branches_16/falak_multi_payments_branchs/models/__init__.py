# -*- coding: utf-8 -*-

from . import f_account_payment_inherit
from . import f_multi_payments_inherit
from . import f_check_wizard_inherit
