# -*- coding: utf-8 -*-

from . import f_inherit_product_item_pricelist
from . import f_inherit_product_pricelist
from . import  f_pos_session