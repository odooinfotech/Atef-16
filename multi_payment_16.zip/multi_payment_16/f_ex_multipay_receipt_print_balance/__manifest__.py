# -*- coding: utf-8 -*-
{
    'name': "f_ex_multipay_receipt_print_balance",

    'summary': """
        balance to be total balance not credit only in printed payment receipt """,

    'description': """
        Long description of module's purpose
    """,

    'author': "falak-solutions",
    'license': 'LGPL-3',
   # 'website': "https://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','f_contact_balance_customs','falak_multi_payments_base'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
        'views/views.xml',
        #'views/templates.xml',
    ],
    # only loaded in demonstration mode
    #'demo': [
     #   'demo/demo.xml',
    #],
}
