from odoo import models, fields, api

class ResPartner(models.Model):
    _inherit = 'res.partner'

    company_id = fields.Many2one('res.company', string="Company", default=lambda self: self.env.company)
    f_brand_id = fields.Many2one('f.contact.brand', string='Brand')
