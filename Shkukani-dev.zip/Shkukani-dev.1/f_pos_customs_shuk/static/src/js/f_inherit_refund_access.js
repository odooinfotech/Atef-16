odoo.define('f_pos_button_access_on_employee.f_inherit_refund_access', function(require) {
    'use strict';

    
    
    const PosComponent = require('point_of_sale.PosComponent');
    const ProductScreen = require('point_of_sale.ProductScreen');
    const { useListener } = require("@web/core/utils/hooks");
    const Registries = require('point_of_sale.Registries');
    const RefundButton = require('point_of_sale.RefundButton');
    const { _t } = require('web.core');
    const { Gui } = require('point_of_sale.Gui');
    


    const FteaccessRefundButton = RefundButton => class extends RefundButton {
    	
    	
    	_onClick() {

            	
            	 super._onClick();

           const partner = this.env.pos.get_order().get_partner();
            const searchDetails = partner ? { fieldName: 'PARTNER', searchTerm: partner.name } : {};
            	 this.showScreen('TicketScreen', {
                ui: {searchDetails },
                destinationOrder: this.env.pos.get_order(),
            });




             
             
           
         }
    	 
    	 
    	

        
    	
    	
     
        
        
        
        
        
        
    };

    
    
    
    Registries.Component.extend(RefundButton, FteaccessRefundButton);

    return RefundButton;
 });