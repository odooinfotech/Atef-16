# -*- coding: utf-8 -*-
{
    'name': "f_check_pos_branch_ex",

    'summary': """
       inherit create payment to pass branch as user branch in check pay when create from pos""",

    'description': """
    
    """,

    'author': "falak-solutions",
    'license': 'LGPL-3',

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0',

    # any module necessary for this one to work correctly
    'depends': ['base','falak_multi_payment_pos_ext','f_multi_branches_management'],


}
