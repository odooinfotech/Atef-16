# -*- coding: utf-8 -*-

from itertools import chain

import time
import logging

from ast import literal_eval

from odoo import _, api, fields, models, tools
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from odoo.tools.safe_eval import safe_eval

_logger = logging.getLogger(__name__)


class ProductPricelist(models.Model):
    _inherit = 'product.pricelist'

    def _get_applicable_rules_domain(self, products, date, **kwargs):
        domain = super(ProductPricelist, self)._get_applicable_rules_domain(products, date, **kwargs)

        additional_domains = [
            '|',('f_section', '=', False), ('f_section', 'in', products.f_section.ids)
            ,'|', ('f_group', '=', False), ('f_group', 'in', products.f_section.ids)
            , '|', ('f_brand', '=', False), ('f_brand', '=', products.f_brand)
            , '|', ('f_season', '=', False), ('f_season', '=', products.f_season)
            , '|', ('f_article', '=', False), ('f_article', '=', products.f_article)
        ]

        return domain + additional_domains




#