# License AGPL-3.0 or later (http://www.gnu.org/licenses/agpl).
import logging
from odoo import api, SUPERUSER_ID

_logger = logging.getLogger(__name__)


def multi_payment_init(cr, registry):
    """
    Create a Multi payment Header for every existint payment
    """
    env = api.Environment(cr, SUPERUSER_ID, {})

    payments = env['account.payment'].search(
        [('partner_id', '!=', False), ('state', 'in', ('sent', 'reconciled', 'posted'))])

    for payment in payments:

        _logger.info('creating Multi payment Header for payment %s')
        try:

            result = env['f.multi.payments'].create({
                'f_payment_type': payment.payment_type,
                'f_partner_type': payment.partner_type,
                'f_partner_id': payment.partner_id.id,
                'f_currency_id': payment.currency_id.id,
                'f_payment_date': payment.date,
                'f_pay_reference': payment.payment_reference,
                # pos
                #                 'f_pos_session_id': payment.pos_session_id.id,
                #                 'f_pos_order_id' : payment.pos_order_id.id,
                'f_payment_lines': [(4, payment.id, False)],
                'company_id': payment.company_id.id,
                'f_multi_pay_state': (
                        payment.state in ['sent', 'reconciled', 'posted'] and
                        'posted' or payment.state),
            })

        except ValueError:
            _logger.error('result ' % ValueError)
