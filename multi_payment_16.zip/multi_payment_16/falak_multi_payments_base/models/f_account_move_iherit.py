from odoo import models, fields, api, _


class FAccountMoveInherit(models.Model):
    _inherit = "account.move"

    f_payment_purpose = fields.Many2one('f.payment.purpose', string="Payment Purpose")
    f_multi_payment_ids = fields.Many2many(
        'f.multi.payments',   compute='_compute_multi_payments_ids',
        string='Payments', readonly =True    )

    def _compute_multi_payments_ids(self):
        print('9999999999999999999999')
        multi_payment_ids =[]
        foreign_currency = self.currency_id if self.currency_id != self.company_id.currency_id else False
        print('9999999999999999999999',self.currency_id)
        #print('Ahmad 1')
        #print(self)
        reconciled_vals = []
        
        pay_term_line_ids = self.line_ids.filtered(lambda line: line.account_id.account_type in ('asset_receivable', 'liability_payable'))
        #print(pay_term_line_ids)
        partials = pay_term_line_ids.mapped('matched_debit_ids') + pay_term_line_ids.mapped('matched_credit_ids')
        #print('partials',partials)
        for partial in partials:
            counterpart_lines = partial.debit_move_id + partial.credit_move_id
            #print('counterpart_lines',counterpart_lines)
            counterpart_line = counterpart_lines.filtered(lambda line: line not in self.line_ids)
           
            
            multi_payment_ids.append(counterpart_line.payment_id.f_parent_id.id)
                
        self.f_multi_payment_ids = multi_payment_ids
        
        #print( self.f_multi_payment_ids)
    
    
    def action_view_multi_payments(self):
        if self.move_type in ('in_invoice', 'in_refund'):
            action = self.env.ref(
                'falak_multi_payments_base.supplier_account_multi_payments_action')
        else:
            action = self.env.ref('falak_multi_payments_base.cust_account_multi_payments_action')

        result = action.read()[0]

        if len(self.f_multi_payment_ids) != 1:
            result['domain'] = [('id', 'in', self.f_multi_payment_ids.ids)]
        elif len(self.f_multi_payment_ids) == 1:
            res = self.env.ref(
                'falak_multi_payments_base.f_multi_payments_form_view', False)
            result['views'] = [(res and res.id or False, 'form')]
            result['res_id'] = self.f_multi_payment_ids.id
        return result

