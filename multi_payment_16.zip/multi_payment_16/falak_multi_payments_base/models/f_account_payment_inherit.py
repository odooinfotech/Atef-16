from odoo import models, fields, api,SUPERUSER_ID, _
from lxml import etree
from odoo.exceptions import UserError

class FAccountPaymentInherit(models.Model):
    _inherit = "account.payment"
    
    f_seq_num_line = fields.Integer('Seq')

    f_payment_purpose = fields.Many2one('f.payment.purpose', string="Payment Purpose")
    def f_calculate_total_create(self):
        if self.f_parent_id:
            total=0
            for payment in self.f_parent_id.f_payment_lines:
                total += payment.amount_company_currency_signed
            self.f_parent_id.write({'f_payment_total':total})

    def f_calculate_total_delete(self):
        if self.f_parent_id:
            update_query = "UPDATE F_MULTI_PAYMENTS SET F_PAYMENT_TOTAL = (SELECT COALESCE(SUM(AP.AMOUNT_COMPANY_CURRENCY_SIGNED), 0)  FROM ACCOUNT_PAYMENT AP , ACCOUNT_MOVE AM WHERE AP.MOVE_ID = AM.ID AND AM.STATE !='cancel' AND F_PARENT_ID = %s AND AP.ID != %s) WHERE ID = %s"
            self.env.cr.execute(update_query, [self.f_parent_id.id, self.id,      self.f_parent_id.id])

    def f_calculate_total(self):
        if self.f_parent_id :
            cancel_amount  = 0
            current_payment_amt = self.amount_company_currency_signed

            if self.state == 'cancel':
                cancel_amount = self. amount_company_currency_signed
            print('In update', self, self.state, current_payment_amt,cancel_amount, self.id)
            update_query = "UPDATE F_MULTI_PAYMENTS SET F_PAYMENT_TOTAL = (SELECT COALESCE(SUM(AP.AMOUNT_COMPANY_CURRENCY_SIGNED), 0) FROM ACCOUNT_PAYMENT AP , ACCOUNT_MOVE AM WHERE AP.MOVE_ID = AM.ID AND AM.STATE !='cancel' AND F_PARENT_ID = %s AND AP.ID != %s) + %s - %s WHERE ID = %s"
            res = self.env.cr.execute(update_query , [self.f_parent_id.id,self.id, current_payment_amt,cancel_amount,self.f_parent_id.id])


    f_payment_channel = fields.Char('Payment Channel')
    f_pay_reference = fields.Char('Receipt Manual Reference', copy=False, related="f_parent_id.f_pay_reference", store=True)
    f_partner_ref   = fields.Char('Partner Reference' , copy=False, related="partner_id.ref", store=True)
    available_payment_method_ids = fields.Many2many(related='journal_id.available_payment_method_ids')
    #reconciled_invoice_ids = fields.Many2many('account.move', string="Reconciled Invoices" , related = 'f_parent_id.f_to_pay_invoices')
    f_show_internal_transfer = fields.Boolean('Show Internal Transfer', default = False)
    f_enable_create = fields.Boolean('Enable Create', default = False)
    f_parent_id = fields.Many2one('f.multi.payments','Multi Payment',readonly=True,ondelete='cascade')
    #pos
    #f_partner_debit = fields.Monetary('Debt',related='partner_id.f_credit_with_paid',readonly=True,currency_field='company_currency_id')
    f_multi_pay_state = fields.Selection(related = 'f_parent_id.f_multi_pay_state')
    
    #multi_payment_line_id = fields.Many2one('f.multi.payments.lines','Multi Payment Line',readonly=True)
    f_payment_type = fields.Selection(related = 'f_parent_id.f_payment_type')
    
    f_sales_person = fields.Many2one('res.users',related = 'partner_id.user_id',readonly=True, string ='Old Field Sales Person',store=True)    
    company_currency_id = fields.Many2one(
        related='company_id.currency_id',
        string='Company currency',
    )
    exchange_rate = fields.Float( string='Exchange Rate', compute='_compute_exchange_rate',inverse='_update_exchange_rate', default = False,digits=(16, 4))
    is_forien_currency = fields.Boolean(  compute='_is_forien_currency')
    is_des_forien_currency = fields.Boolean()
    
#     f_dest_gl_currency_id = fields.Many2one(
#         related='destination_journal_id.currency_id',
#         string='Dest Journal Currency'  )
#     
    f_payment_amount_company_currency = fields.Monetary(
        string='Amount on Company Currency',
        compute='_compute_amount_company_currency',
        inverse='_inverse_amount_company_currency',
        currency_field='company_currency_id'
    )
    
    force_amount_company_currency = fields.Monetary(
        string='Forced Amount on Company Currency',
        currency_field='company_currency_id',
        copy=False)

    # commented in17022023 seems not needed
    # def _get_payment_method_codes_to_exclude(self):
    #     print('_get_payment_method_codes_to_exclude')
    #     for rec in self :
    #         res = super(FAccountPaymentInherit, rec)._get_payment_method_codes_to_exclude()
    #
    #         # can be overriden to exclude payment methods based on the payment characteristics
    #         rec.ensure_one()
    #         return res
    

    def action_cancel(self):
            super(FAccountPaymentInherit, self).action_cancel()
            self.write({'state': 'cancel','check_state':'cancelled'})
         
    
    def action_draft(self):
            super(FAccountPaymentInherit, self).action_draft()
            self.write({'state': 'draft','check_state':'draft'})
            

    
    
    
    #This Function is used to force the amount of the company currency if the user change it
    @api.model
    def _prepare_move_line_default_vals(self, write_off_line_vals=None):
        #print('_prepare_move_line_default_vals---1')
        line_vals_list = super(FAccountPaymentInherit,self)._prepare_move_line_default_vals(write_off_line_vals)
        print('_prepare_move_line_default_vals---2',line_vals_list)
        if self.f_payment_amount_company_currency :
            for val in line_vals_list :
                if val['currency_id'] == False :
                    val['currency_id'] = self.currency_id.id
                if val['credit'] == 0 :
                    val['debit'] = self.f_payment_amount_company_currency
                if val['debit'] == 0 :
                    val['credit'] = self.f_payment_amount_company_currency
            print('line_vals_list',line_vals_list)
        return line_vals_list

                                        
    def f_open_form_action(self):
        print('action',self)
        #self.env.ref('falak_multi_payments_base.f_acc_payments_custom_form_view').id,
        return {
             'type': 'ir.actions.act_window',
             'name': 'Payment Line',
             'view_mode': 'form',
             'view_id':self.env.ref('account.view_account_payment_form').id,
             'res_model': self._name,
             'res_id': self.id,
             'target': 'new',
                }

    # # commented in17022023 and added in Context in Multi Payment
    # @api.model
    # def default_get(self,field_lst):
    #     print('Defaultttttttttttttttttttttttttttttttttttttttttttttttttttt',self)
    #     res = super(FAccountPaymentInherit, self).default_get(field_lst)
    #     print(res, self.f_parent_id,self.f_parent_id.f_partner_id)
    #     if self.f_parent_id :
    #         #print('Iif ')
    #         res['partner_id'] = self.f_parent_id.f_partner_id.id
    #         res['partner_type'] = self.f_parent_id.f_partner_type
    #         res['payment_type'] = self.f_parent_id.f_payment_type
    #         res['date'] = self.f_parent_id.f_payment_date
    #         res['f_default_journal'] = self.f_parent_id.f_default_journal.id
    #
    #
    #     print('resssssssssssssssss',res)
    #     return res
    #
    
    
    @api.depends('currency_id')#,'f_dest_gl_currency_id')
    def _is_forien_currency(self):
        print('_is_forien_currency')
        for rec in self:
            rec.is_forien_currency = False
            #comment - fix expense
         #   rec.is_des_forien_currency = False
            if rec.company_currency_id and rec.currency_id and \
               rec.company_currency_id != rec.currency_id:
                rec.is_forien_currency = True
        return self
        
#             elif rec.payment_type == 'transfer' and rec.company_currency_id and rec.f_dest_gl_currency_id and \
#                        rec.company_currency_id != rec.f_dest_gl_currency_id:
#                         rec.is_des_forien_currency =  True
#     

    @api.onchange('exchange_rate')
    def _update_exchange_rate(self):
        for rec in self:


            if rec.exchange_rate  :
                rec.f_payment_amount_company_currency =  rec.exchange_rate * rec.amount




    @api.depends('amount',  'f_payment_amount_company_currency')
    def _compute_exchange_rate(self):
        print('_compute_exchange_rate')        
        for rec in self:
            rec.exchange_rate = rec.amount and (rec.f_payment_amount_company_currency / rec.amount) or 0.0

    
    @api.onchange('f_payment_amount_company_currency')
    def _inverse_amount_company_currency(self):
        print('_inverse_amount_company_currency')
        for rec in self:   
            if rec.currency_id.id != rec.company_id.currency_id.id and rec.f_payment_amount_company_currency != \
                    rec.currency_id._convert(
                        rec.amount, rec.company_id.currency_id,
                        rec.company_id, rec.date):
                force_amount_company_currency = rec.f_payment_amount_company_currency
            else:
                force_amount_company_currency = False


#re uncomment  
            rec.force_amount_company_currency = force_amount_company_currency



            #print('start',rec._origin.id)
            if rec._origin.id and rec.force_amount_company_currency :
                move = self.env['account.move'].search([('payment_id','=',rec._origin.id)])
                #print('move',move)
                lines = self.env['account.move.line'].search([('payment_id','=',rec._origin.id)])
                list = []
                for line in lines :
                    vals = {}    
                    #print('In Lines', line) 

                    if line.credit == 0 :
                        #print('In credit', line.credit,line.debit,rec.f_payment_amount_company_currency)
                        vals['credit'] = 0
                        vals['debit'] =  rec.f_payment_amount_company_currency
                    elif line.debit == 0 :
                        #print('In dept', line.credit,line.debit,rec.f_payment_amount_company_currency)
                        vals['credit'] = rec.f_payment_amount_company_currency
                        vals['debit'] =  0
                    list.append((1, line.id ,vals ))
                    #print(list)
                move.write({'line_ids':list})
                 
    
            

    @api.depends('amount', 'force_amount_company_currency','exchange_rate','journal_id')
    def _compute_amount_company_currency(self):
        for rec in self:
        
                #print('_compute_amount_company_currency',rec.force_amount_company_currency)
                if not rec.currency_id.id != rec.company_id.currency_id.id:
                    f_payment_amount_company_currency = rec.amount
                elif rec.force_amount_company_currency:
                    f_payment_amount_company_currency = rec.force_amount_company_currency
                else:
                    f_payment_amount_company_currency = rec.currency_id._convert(
                        rec.amount, rec.company_id.currency_id,
                        rec.company_id, rec.date)
                
                
                rec.f_payment_amount_company_currency = f_payment_amount_company_currency
                print('1')
                if rec._origin.id and rec.state == 'draft' and rec.f_multi_pay_state == 'draft' and rec.currency_id.id != rec.company_id.currency_id.id:
                    print('122233333333')
                    move = self.env['account.move'].search([('payment_id','=',rec._origin.id)])
                    #print('move',move)
                    lines = self.env['account.move.line'].search([('payment_id','=',rec._origin.id)])
                    list = []
                    for line in lines :
                        vals = {}    


                        #print('In Lines', line) 
                        if line.credit == 0 :
                            #print('In credit', line.credit,line.debit,rec.f_payment_amount_company_currency)
                            vals['credit'] = 0
                            vals['debit'] =  rec.f_payment_amount_company_currency
                        elif line.debit == 0 :
                            #print('In dept', line.credit,line.debit,rec.f_payment_amount_company_currency)
                            vals['credit'] = rec.f_payment_amount_company_currency
                            vals['debit'] =  0
                        list.append((1, line.id ,vals ))
                        #print(list)
                    move.write({'line_ids':list})

    # commented in17022023 no need for this in odoo 16
    # # this function is overritten to disable the create/edit in case the payment
    # #list is opened from the original screen and enable it from internal transfer on;y
    # @api.model
    # def fields_view_get(self, view_id=None, view_type='form',
    #                     toolbar=False, submenu=False):
    #     print('fields_view_get')
    #     res = super(FAccountPaymentInherit, self).fields_view_get(
    #         view_id=view_id, view_type=view_type,
    #         toolbar=toolbar, submenu=submenu)
    #     if view_type != 'search' and self.env.uid != SUPERUSER_ID:
    #         # Check f_enable_create
    #         #has_my_group = self.env.user.has_group('my_group_with_more_access')
    #         #if self.f_enable_create:
    #         root = etree.fromstring(res['arch'])
    #         root.set('create', 'false')
    #         #root.set('edit', 'false')
    #         if self._context.get('default_f_enable_create')  :
    #             root.set('create', 'true')
    #             #root.set('edit', 'true')
    #         res['arch'] = etree.tostring(root)
    #     return res


    @api.onchange('journal_id')
    def _onchange_journal_id(self):
        if self.state == 'draft' :
            if self._origin.journal_id: 
                    raise UserError(_("You Can't Change the Journal ,Please Delete the line and add it again"))

    @api.depends('journal_id', 'partner_id', 'partner_type', 'is_internal_transfer', 'destination_journal_id')
    def _compute_destination_account_id(self):
        print(self.destination_account_id)
        self.destination_account_id =self.f_parent_id.f_destination_account_id.id
        #    super(FAccountPaymentInherit, self)._compute_destination_account_id()
