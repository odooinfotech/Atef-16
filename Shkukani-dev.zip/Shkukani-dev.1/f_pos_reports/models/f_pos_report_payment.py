# -*- coding: utf-8 -*-

from odoo import models, tools, api, fields
from datetime import datetime


from odoo import models, tools, api, fields,_


class FReportdiscsaless(models.AbstractModel):
    _name = 'report.f_pos_reports.report_discpos_pay'
    _description = 'POS Product Details Report'

    @api.model
    def get_total_sales(self, f_date=False,t_date=False, config_id=False):


        groups={}
        orders = self.env['pos.order'].sudo().search([('config_id', '=', config_id),
                                                      ('date_order', '>=',f_date),
                                                      ('date_order', '<=', t_date)])
        for order in orders:
            payments = self.env['pos.payment'].sudo().search([('pos_order_id', '=', order.id)])
            for pay in payments:
                dic_name = pay.payment_method_id.id
                if not groups.get(dic_name):
                        groups[dic_name] = {}
                        groups[dic_name].update({
                            'name': pay.payment_method_id.name,
                            'amount': pay.paid_amount


                        })
                else:
                        groups[dic_name].update({
                            'amount': groups[dic_name].get('amount') +pay.paid_amount
                        })


        print('groups',groups)
        config = self.env['pos.config'].search([('id', '=', config_id)])

        result = {

            'groups': groups,
            'config_pos': config.name,
            'f_date':f_date,
            't_date':t_date


        }

        return result

    @api.model
    def _get_report_values(self, docids, data=None):
        data = dict(data or {})
        print("data['f_date']", data['f_date'])
        data.update(self.get_total_sales(data['f_date'], data['t_date'],data['pos_config_id']))
        return data




class Fsalereporting(models.TransientModel):
    _name = "f.sale.report.disc.pay"
    _description = "f.sale.report.disc"



    f_date = fields.Datetime(string='From Date')
    t_date = fields.Datetime(string='To Date')
    pos_config_id = fields.Many2one('pos.config', "POS")

    def generate_salereport(self):
        data = {'f_date': self.f_date,'t_date':self.t_date, 'pos_config_id': self.pos_config_id.id}
        return self.env.ref('f_pos_reports.f_posdisc_report_pay').report_action(self, data=data)

