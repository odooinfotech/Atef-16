
from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class FCheckActions(models.Model):
        _inherit = 'f.bulk.checks'

        f_endorse_exchange_rate = fields.Float(string='Endorse EX.Rate', default=False, digits=(16, 4))
        f_endorsecurrency_id = fields.Many2one('res.currency', string='Endorse Currency')

        def f_submit_bulk(self):
            if self.f_endorse_exchange_rate :
                if not self.f_endorsecurrency_id :
                    raise UserError(
                        _("Can't Confirm !!Fill Endorse Currency First"))

                if self.f_endorsecurrency_id :
                    domain = [('company_id', '=', self.company_id.id), ('state', '=', 'posted'),
                              ('payment_type', '=', self.f_check_action.f_checks_type),
                              ('check_number', '!=', False), '|', '|',
                              ('check_state', '=', self.state1), ('check_state', '=', self.state2),
                              ('check_state', '=', self.state3)]

                    if self.f_endorsecurrency_id.id:
                        domain += [('currency_id', '=', self.f_endorsecurrency_id.id)]

                    checks_ids = self.env['account.payment'].search(domain)

                    ex_check_ids = list()
                    ex_check_ids_msg = ''
                    for rec in self.f_checks_to_action:
                        rec.sudo().write( {'f_endorse_exchange_rate': self.f_endorse_exchange_rate})
                        if rec.id not in checks_ids.ids:
                            ex_check_ids.append('''%s ''' % (rec.name))

                    ex_check_ids_msg = '\n'.join(ex_check_ids).strip(' + ')

                    if len(ex_check_ids) > 0:
                        raise UserError(_("Can't Confirm !! wrong Payments  : %s ,With selected Action . :  %s   , please check Endorse Currency too " % (
                            ex_check_ids_msg, self.f_check_action.f_action_name)))


            return super().f_submit_bulk()





        @api.onchange('f_check_action','f_action_account_id','f_endorsecurrency_id')
        def onchange_check_action(self):
            res = super().onchange_check_action()
            if self.f_endorse_exchange_rate:
                if self.f_endorsecurrency_id:
                    res['domain']['f_checks_to_action'] +=[('currency_id', '=', self.f_endorsecurrency_id.id)]
            return res







        @api.onchange('f_endorse_exchange_rate')
        def f_get_ex_rate_pay(self):
            if self.f_endorse_exchange_rate :

                if self.f_checks_to_action :
                    for rec in  self.f_checks_to_action :
                        pay = self.sudo().env['account.payment'].sudo().search([('name','=',rec.name)])
                        pay.sudo().write( {'f_endorse_exchange_rate': self.f_endorse_exchange_rate})









