from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

class FAccountAccountInherit(models.Model):
    _inherit = 'account.account'

    f_returned_to_customer_checks_acc = fields.Boolean(string='Checks Returned To Customer Fees Account',copy=False)
    f_returned_checks_acc = fields.Boolean(string='Returned Checks Account',
                                   help="If this flag is True this account will be used for returned checks, "
                                        "each company should have only one account for returned checks.",copy=False)


    f_fee_value = fields.Float(string='Default Fees Value')

    @api.constrains('f_returned_checks_acc')
    def _check_retcheck(self):
        check_one = self.env['account.account'].sudo().search([('f_returned_checks_acc', '=', True), ('company_id', '=', self.company_id.id),('id', '!=', self.id)])

        if check_one:
            raise ValidationError("There another Returned Checks Account for this company , only one returned checks account is allowed" )

    @api.constrains('f_returned_to_customer_checks_acc')
    def _check_retToCustCheck(self):
        check_one = self.env['account.account'].sudo().search(
            [('f_returned_to_customer_checks_acc', '=', True), ('company_id', '=', self.company_id.id), ('id', '!=', self.id)])

        if check_one:
            raise ValidationError(
                "There another Returned To Customer Fees Account for this company , only one account is allowed per Company ")
