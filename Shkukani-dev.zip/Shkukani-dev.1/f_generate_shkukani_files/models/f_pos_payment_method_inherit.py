from odoo import models, fields, api, _

class FPosPaymentMethodInherit(models.Model):
    _inherit = 'pos.payment.method'

    f_type = fields.Selection([('M','Cash'), ('T','Credit Card'), ('L','Paycheck')], string='Type')