from odoo import models, fields, api, _


class FProductSection(models.Model):
    _name = 'f.product.section'
    _description = 'Product Section'
    _rec_name = 'f_name'

    f_name = fields.Char(string='Name')
