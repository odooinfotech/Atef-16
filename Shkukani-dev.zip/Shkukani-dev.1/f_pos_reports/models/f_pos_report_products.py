# -*- coding: utf-8 -*-

from odoo import models, tools, api, fields
from datetime import datetime


from odoo import models, tools, api, fields,_


class FReportdiscsaless(models.AbstractModel):
    _name = 'report.f_pos_reports.report_discpos'
    _description = 'POS Product Details Report'

    @api.model
    def get_total_sales(self, f_date=False,t_date=False, config_id=False):


        groups={}
        orders = self.env['pos.order'].sudo().search([('config_id', '=', config_id),
                                                      ('date_order', '>=',f_date),
                                                      ('date_order', '<=', t_date)])
        for order in orders:
            order_lines = self.env['pos.order.line'].sudo().search([('order_id', '=', order.id)])
            for order_line in order_lines:
                dic_name = order_line.product_id.id
                color = "   "
                size = "   "
                color_attributes = self.env['product.attribute'].sudo().search([('f_type', '=', 'color')])
                size_attributes = self.env['product.attribute'].sudo().search([('f_type', '=', 'size')])
                product_values = order_line.product_id.product_template_variant_value_ids
                for product_value in product_values:
                    attribute_value = product_value.product_attribute_value_id
                    if attribute_value and attribute_value.attribute_id in color_attributes:
                        color = attribute_value.f_code or '0'
                        color = color
                    if attribute_value and attribute_value.attribute_id in size_attributes:
                        size = attribute_value.name or ' '
                        size = size



                if not groups.get(dic_name):
                        config = self.env['pos.config'].search([('id', '=', config_id)])
                        quants = self.env['stock.quant'].search([('product_id', '=', order_line.product_id.id),('location_id', '=', config.picking_type_id.default_location_src_id.id)])
                        loc_quantity = 0.0
                        if len(quants) > 0:
                            for quant in quants:
                                    loc_quantity += quant.quantity
                        groups[dic_name] = {}
                        groups[dic_name].update({
                            'name': order_line.product_id.name,
                            'section': order_line.product_id.f_section.f_name if order_line.product_id.f_section else '',
                            'qty': order_line.qty,
                            'article':order_line.product_id.f_article or '0',
                            'color':color,
                            'size':size,
                            'qty_ava':loc_quantity
                        })
                else:
                        groups[dic_name].update({
                            'qty': groups[dic_name].get('qty') +order_line.qty
                        })


        print('groups',groups)
        config = self.env['pos.config'].search([('id', '=', config_id)])

        result = {

            'groups': groups,
            'config_pos': config.name,
            'f_date':f_date,
            't_date':t_date


        }

        return result

    @api.model
    def _get_report_values(self, docids, data=None):
        data = dict(data or {})
        print("data['f_date']", data['f_date'])
        data.update(self.get_total_sales(data['f_date'], data['t_date'],data['pos_config_id']))
        return data




class Fsalereporting(models.TransientModel):
    _name = "f.sale.report.disc"
    _description = "f.sale.report.disc"



    f_date = fields.Datetime(string='From Date')
    t_date = fields.Datetime(string='To Date')
    pos_config_id = fields.Many2one('pos.config', "POS")

    def generate_salereport(self):
        data = {'f_date': self.f_date,'t_date':self.t_date, 'pos_config_id': self.pos_config_id.id}
        return self.env.ref('f_pos_reports.f_posdisc_report').report_action(self, data=data)

