# -*- coding: utf-8 -*-
{
    'name': "f_pos_reports",

    'summary': """
     pos report - product & payment""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Falak Solutions",
    'license': 'LGPL-3',
    

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['base','pos_hr','point_of_sale','f_shkukani_inventory_custom','f_generate_shkukani_files','loyalty'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'views/f_report_pdf_products.xml',
        'views/f_pos_report_details.xml',
        'views/f_report_pdf_payment.xml',
        'views/f_pos_report_details_pay.xml',
        'views/f_gift_card_thermal.xml',
    ],
    'assets': {

        'point_of_sale.assets': [
            '/f_pos_customs_shuk/static/src/js/*.js',
        ]

    },
}
