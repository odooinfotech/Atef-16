import logging
import time
import tempfile
import binascii
import zipfile
import io
from odoo.exceptions import Warning
from odoo import models, fields, exceptions, api, _
from io import BytesIO, StringIO
from PIL import Image
import os
from odoo.exceptions import AccessError, UserError, ValidationError

_logger = logging.getLogger(__name__)

try:
    import cStringIO
except ImportError:
    _logger.debug('Cannot `import cStringIO`.')
try:
    import base64
except ImportError:
    _logger.debug('Cannot `import base64`.')


def _parse_filename_parts(filename):
    """Parse filename like ignore-ARTICLE-COLORCODE-YEAR-IMPORTANCE"""
    parts = filename.split('-')
    if len(parts) < 5:
        return {}
    return {
        'article': parts[1],
        'color_code': parts[2],
        'year': parts[0],
        'importance': os.path.splitext(parts[4])[0],
    }


class GenSaleInherit(models.TransientModel):
    _inherit = 'gen.sale'

    product_by = fields.Selection(
        [('name', 'Name'), ('internal ref', 'Internal Reference'), ('barcode', 'Barcode'), ('id', 'ID'),
         ('f_article', 'Article Number')],
        string='Product By', default='name')

    def import_img(self):
        try:
            book = BytesIO()
            book.write(base64.decodebytes(self.file))
            book.seek(0)
            zf = zipfile.ZipFile(book, 'r')
        except Exception:
            raise UserError("Please select a ZIP file or you have selected an invalid file")

        list_file = []
        error_details = {}

        for img in zf.namelist()[1:]:
            outpath = "/tmp/"
            p = zf.extract(img, outpath)
            filename = os.path.basename(img)
            (file, ext) = os.path.splitext(filename)
            record = None

            try:
                if self.img_for == 'product':
                    if self.product_model == 'product template':
                        model = self.env['product.template']
                    elif self.product_model == 'product variants':
                        model = self.env['product.product']
                    else:
                        error_details[file] = "Invalid product model selected"
                        continue

                    if self.product_by == 'name':
                        record = model.search([('name', '=', file)], limit=1)
                    elif self.product_by == 'internal ref':
                        record = model.search([('default_code', '=', file)], limit=1)
                    elif self.product_by == 'barcode':
                        record = model.search([('barcode', '=', file)], limit=1)
                    elif self.product_by == 'id':
                        try:
                            record = model.search([('id', '=', int(file))], limit=1)
                        except:
                            error_details[file] = "Invalid ID format"
                            continue
                    elif self.product_by == 'f_article':
                        parsed = _parse_filename_parts(file)
                        if not parsed:
                            error_details[
                                file] = "Filename does not match expected format (ignore-ARTICLE-COLORCODE-YEAR-IMPORTANCE)"
                            continue

                        article = parsed.get('article')
                        color_code = parsed.get('color_code')
                        year = parsed.get('year')
                        importance = parsed.get('importance')

                        if not all([article, color_code, year, importance]):
                            error_details[file] = "Missing article/color/year/importance in filename"
                            continue

                        try:
                            article = int(article)
                            color_code = int(color_code)
                            importance = int(importance)
                        except ValueError:
                            error_details[file] = "Article, color_code, or importance is not a number"
                            continue

                        year = 'S' + year

                        # Check for higher importance
                        higher_found = False
                        for other_img in zf.namelist()[1:]:
                            other_filename = os.path.basename(other_img)
                            other_file, _ = os.path.splitext(other_filename)
                            if other_file == file:
                                continue
                            other_parsed = _parse_filename_parts(other_file)
                            if (
                                    other_parsed.get('article') == str(article) and
                                    other_parsed.get('color_code') == str(color_code) and
                                    other_parsed.get('year') == year[1:]
                            ):
                                try:
                                    other_importance = int(other_parsed.get('importance'))
                                    if other_importance > importance:
                                        higher_found = True
                                        break
                                except:
                                    continue
                        if higher_found:
                            error_details[file] = "A higher-importance image exists for this article/color/year"
                            continue

                        missing_fields = []
                        model = self.env['product.product']
                        record = model.search([
                            ('f_article', '=', article),
                            ('f_color_code', '=', color_code),
                            ('f_season', '=', year),
                        ], limit=1)
                        # _logger.info("record: %s", record.name)

                        if not record:
                            if not self.env['product.template'].search([('f_article', '=', article)], limit=1):
                                missing_fields.append(f"article={article}")
                            if not self.env['product.template'].search([('f_season', '=', year)], limit=1):
                                missing_fields.append(f"year={year}")

                            if missing_fields:
                                error_details[file] = "No matching product record found. Missing: " + ', '.join(
                                    missing_fields)
                                continue

                    if not record:
                        error_details[file] = "No matching product record found"
                        continue

                    try:
                        with open(p, "rb") as image_file:
                            f = base64.b64encode(image_file.read())
                        record.write({'image_1920': f})
                        list_file.append(file)
                    except Exception as e:
                        error_details[file] = f"Failed to write image: {str(e)}"

                elif self.img_for == 'partner':
                    if self.partner_by == 'name':
                        record = self.env['res.partner'].search([('name', '=', file)], limit=1)
                    elif self.partner_by == 'internal ref':
                        record = self.env['res.partner'].search([('ref', '=', file)], limit=1)
                    elif self.partner_by == 'id':
                        try:
                            record = self.env['res.partner'].search([('id', '=', int(file))], limit=1)
                        except:
                            error_details[file] = "Invalid ID format for partner"
                            continue

                    if not record:
                        error_details[file] = "No matching partner record found"
                        continue

                    try:
                        with open(p, "rb") as image_file:
                            f = base64.b64encode(image_file.read())
                        record.write({'image_1920': f})
                        list_file.append(file)
                    except Exception as e:
                        error_details[file] = f"Failed to write image: {str(e)}"

                elif self.img_for == 'employee':
                    if self.emp_by == 'name':
                        record = self.env['hr.employee'].search([('name', '=', file)], limit=1)
                    elif self.emp_by == 'id no':
                        record = self.env['hr.employee'].search([('identification_id', '=', file)], limit=1)
                    elif self.emp_by == 'id':
                        try:
                            record = self.env['hr.employee'].search([('id', '=', int(file))], limit=1)
                        except:
                            error_details[file] = "Invalid ID format for employee"
                            continue

                    if not record:
                        error_details[file] = "No matching employee record found"
                        continue

                    try:
                        with open(p, "rb") as image_file:
                            f = base64.b64encode(image_file.read())
                        record.write({'image_1920': f})
                        list_file.append(file)
                    except Exception as e:
                        error_details[file] = f"Failed to write image: {str(e)}"

            except Exception as e:
                error_details[file] = f"Unhandled exception: {str(e)}"

        # Compose the final message
        if error_details:
            Note = '❗ Errors:\n' + '\n'.join(
                [f'Image "{img}": {reason}' for img, reason in error_details.items()]
            )
        else:
            Note = ''

        context = {'default_name': f"{len(list_file)} Images Successfully Imported.\n{Note}"}
        return {
            'name': 'Success',
            'type': 'ir.actions.act_window',
            'view_type': 'form',
            'view_mode': 'form',
            'res_model': 'custom.pop.message',
            'target': 'new',
            'context': context
        }

    def download_auto(self):

        return {
            'type': 'ir.actions.act_url',
            'url': '/web/binary/download_document?model=gen.sale&id=%s' % self.id,
            'target': 'new',
        }


class CustomPopMessage(models.TransientModel):
    _name = "custom.pop.message"
    _description = "Custom Message"

    name = fields.Text('Message')
