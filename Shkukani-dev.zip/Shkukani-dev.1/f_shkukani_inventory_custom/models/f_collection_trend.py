from odoo import models, fields, api, _


class FCollectionTrend(models.Model):
    _name = 'f.collection.trend'
    _description = 'Collection Trend'
    _rec_name = 'f_name'

    f_name = fields.Char(string='Name')
    f_number = fields.Char(string='Number')
