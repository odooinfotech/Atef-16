# -*- coding: utf-8 -*-
# from odoo import http


# class FalakMultiPaymentsBase(http.Controller):
#     @http.route('/falak_multi_payments_base/falak_multi_payments_base/', auth='public')
#     def index(self, **kw):
#         return "Hello, world"

#     @http.route('/falak_multi_payments_base/falak_multi_payments_base/objects/', auth='public')
#     def list(self, **kw):
#         return http.request.render('falak_multi_payments_base.listing', {
#             'root': '/falak_multi_payments_base/falak_multi_payments_base',
#             'objects': http.request.env['falak_multi_payments_base.falak_multi_payments_base'].search([]),
#         })

#     @http.route('/falak_multi_payments_base/falak_multi_payments_base/objects/<model("falak_multi_payments_base.falak_multi_payments_base"):obj>/', auth='public')
#     def object(self, obj, **kw):
#         return http.request.render('falak_multi_payments_base.object', {
#             'object': obj
#         })
