from odoo import models, fields, api, _
from datetime import datetime, timedelta, date
from odoo.exceptions import UserError, ValidationError

# Not Useddd
class FChequePreWizard(models.TransientModel):
    _name = 'cheque.wizard.prepare'
    _description = "Prepare Check Wizard"

    f_prepare_note = fields.Char('Note')
    f_prepare_action = fields.Selection([
        ('deposit', 'Deposit'), ('undeposit', 'UnDeposiit'), ('collect', 'Collect'), ('return', 'Return'), (
            'release', 'Release'), ('bounce', 'Bounce')], string="Action")
    f_bulk_responsible = fields.Many2one('res.users', string="Responsible", default=lambda self: self.env.user and self.env.user.id or False)

    def start_bulk_action(self):
        payments = self.env['account.payment'].sudo().search(
            ['|', ('payment_method_code', '=', 'check_printing'), ('check_details', '=', True), ('id', 'in', self.env.context.get('active_ids'))])
        for payment in payments:
            payment.write({'f_bulk_action': self.f_prepare_action, 'f_bulk_action_note': self.f_prepare_note, 'f_bulk_responsible':self.f_bulk_responsible})
        return True
