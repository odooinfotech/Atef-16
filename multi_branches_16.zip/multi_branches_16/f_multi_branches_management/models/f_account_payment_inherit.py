from odoo import models, fields, api

class f_account_payment(models.Model):
    _inherit = 'account.payment'

    @api.model
    def create(self, vals):
        res = super(f_account_payment, self).create(vals)
        if self.env.company.f_default_partner_branch:
            if res.partner_id.f_related_branch:
                res.update({
                    'f_related_branch': res.partner_id.f_related_branch.id or False
                })
            else:
                res.update({
                    'f_related_branch': self.env.user.f_default_branch.id or False
                })

        return res

    def write(self, vals):
        if self.env.company.f_default_partner_branch:
            if 'partner_id' in vals:
                partner = self.sudo().env['res.partner'].sudo().search([('id', '=', vals['partner_id'])], limit=1)
                if partner.f_related_branch:
                    vals['f_related_branch'] = partner.f_related_branch.id
                else:
                    vals['f_related_branch'] = self.env.user.f_default_branch.id

        return super(f_account_payment, self).write(vals)


    
#     @api.model
#     def default_get(self, fields):
#         print('55555555555555555555555555555555',self)
#         rec = super(f_account_payment, self).default_get(fields)
#         
#         invoice_defaults = self.reconciled_invoice_ids
#         print('invoice_defaults',invoice_defaults)
#         if invoice_defaults and len(invoice_defaults) == 1:
#             print('branchhhhhhh',invoice.f_related_branch.id)
#             invoice = invoice_defaults[0]
#             rec['f_related_branch'] = invoice.f_related_branch.id
#         return rec
#     
    
    def _get_default_branch(self):
         user_default_branch = False
         if self.env.company.f_allow_multi_branches ==True :  
             if self.env.company.f_allow_multi_branches ==True :
                        
                 context = self._context
                 current_uid = context.get('uid')
                 print('current_uid',current_uid)
                 user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
                 if user_default_branch :
                     comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id
                     if comp == self.env.company.id :

                         self.f_related_branch  = user_default_branch
                         print('user_default_branch',user_default_branch)

                     else :
                         print(self.env.user.company_id.id)
                         branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.company.id)],limit=1)
                         print('branch',branch)
                         self.f_related_branch  = branch.id
                         user_default_branch = branch.id
                 else :
                     user_default_branch = self.env['res.users'].browse(current_uid).f_allowed_branches[0]
         return user_default_branch
    
    
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, default=_get_default_branch, tracking=True)
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')            
 
class f_account_payment_register(models.TransientModel):
    _inherit = 'account.payment.register'
 
    
    # add the branch to the keys to include it when grouping the payments of bulk of invoices on register payment 
    @api.model
    def _get_line_batch_key(self, line):
       keys = super(f_account_payment_register, self)._get_line_batch_key(line)
       keys['f_related_branch'] = line.f_related_branch.id
       return keys
       
    # update the batch values to contain the branch this is used for  register payments for a group of invoices    
    def _create_payment_vals_from_batch(self, batch_result):
        batche_values = super(f_account_payment_register, self)._create_payment_vals_from_batch(batch_result)
       # print('batche_values4444444444444444',batche_values)
        f_related_branch = self.env['account.move'].browse(self._context.get('active_ids')[0]).f_related_branch
        batche_values['f_related_branch'] = f_related_branch.id
       # batche_values['f_related_branch'] = batch_result['key_values']['f_related_branch']
        return batche_values

        
    # to get the branch of the invoice in case of payment of one invoice 
    def _create_payment_vals_from_wizard(self,batch_result):
        payment_values = super(f_account_payment_register, self)._create_payment_vals_from_wizard(batch_result)
        f_related_branch = self.env['account.move'].browse(self._context.get('active_ids')[0]).f_related_branch
        payment_values['f_related_branch'] = f_related_branch.id
        return payment_values

