# -*- coding: utf-8 -*-

from . import f_inherit_stat