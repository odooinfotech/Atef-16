from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError


class FPrintOptionsWizard(models.TransientModel):
    _name = "f.print.options.wizard"
    _description = 'Print Options Wizard'

    f_design = fields.Many2one('f.barcode.design', string='Design')
    f_print_copy = fields.One2many('f.product.copies' ,'parent_id' , string='Product Copy')
    f_number_of_labels = fields.Integer(string='# Labels', compute='_f_compute_labels_count')
    f_printed_labels = fields.Integer(string='# Printed Labels', default=0)

    def _f_compute_labels_count(self):
        for rec in self:
            rec.f_number_of_labels = 0
            f_number_of_labels = 0
            for copy in rec.f_print_copy:
                f_number_of_labels += copy.f_copy
            rec.f_number_of_labels = f_number_of_labels

    def f_print_action(self):
        if self.f_design:
            print(self.f_design)
            print_fields = {
                'name': False,
                'article': False,
                'price': False,
                'color': False,
                'size': False,
                'company_name': False,
            }
            for print_field in self.f_design.f_fields:
                print(print_field.f_field_name)
                if print_field.f_field_name == 'name':
                    print_fields['name'] = True
                elif print_field.f_field_name == 'Article':
                    print_fields['article'] = True
                elif print_field.f_field_name == 'price':
                    print_fields['price'] = True
                elif print_field.f_field_name == 'Color':
                    print_fields['color'] = True
                elif print_field.f_field_name == 'Size':
                    print_fields['size'] = True
                elif print_field.f_field_name == 'company':
                    print_fields['company_name'] = True

            for copy in self.f_print_copy:
                copy.f_product_name = False
                copy.f_article = False
                copy.f_product_price = False
                copy.f_color = False
                copy.f_size = False
                copy.f_company = False
                copy.f_font_size = self.f_design.f_size.f_font_size
                if print_fields['name']:
                    copy.f_product_name = True
                if print_fields['article']:
                    copy.f_article = True
                if print_fields['price']:
                    copy.f_product_price = True
                if print_fields['color']:
                    copy.f_color = True
                if print_fields['size']:
                    copy.f_size = True
                if print_fields['company_name']:
                    copy.f_company = True
            print(self.f_design.f_size.name)
            report = self.env['ir.actions.report'].sudo().search([
                ('report_name', '=', 'f_shkukani_print_labels.f_product_label_custom_template')])
            report.paperformat_id = self.f_design.f_size.id
            return (self.env.ref('f_shkukani_print_labels.f_action_product_label_print').
                    report_action(self.f_print_copy))
        else:
            raise ValidationError(_("Please choose the design before print"))
