from odoo import models, api, _

class f_multo_payment_pdf_template(models.AbstractModel):
    _name = 'report.falak_multi_payments_base.f_reportpayment_receipt'
    _description = "Multi Payment Template"

    @api.model
    def _get_report_values(self, docids, data=None):
        report = self.env['ir.actions.report'].\
            _get_report_from_name('falak_multi_payments_base.payment_receipt')
        if data and data.get('form') and data.get('form').get('user_ids'):
            docids = self.env['f.multi.payments'].browse(data['form']['user_ids'])
            docs = self.env['f.multi.payments'].browse(data['form']['user_ids'])
        return {'doc_ids': self.env['f.multi.payments'].browse(data.get('ids')),
                'doc_model': report.model,
                'docs': self.env['f.multi.payments'].browse(data.get('ids')),
                'data': data,
                }


