from odoo import models, fields, api, SUPERUSER_ID, _
from datetime import datetime, timedelta,date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError

class FPartnerInherit(models.Model):
    _inherit = "res.partner"


    f_check_restricted = fields.Boolean('Checks Payments Restricted')