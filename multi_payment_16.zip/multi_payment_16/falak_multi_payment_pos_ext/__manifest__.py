# -*- coding: utf-8 -*-
{
    'name': "Multi Payments POS checks Ext",

    'summary': """
      This Module is for integrating the Multi payments with POS Checks 
      """,

    'description': """
    \  
	  - Create Multi Payment for POS Check Payment 
	    and add all the checks related to the same POS order ubder the same multi payment. 
	   
    """,

    'author': "Falak Solutions",
#    'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['base','account','web','falak_multi_payments_base','check_management','point_of_sale','pos_check_payment'],

    # always loaded
    'data': [
        
    ],
    # only loaded in demonstration mode
    'demo': [
    ],
}
