from odoo import models, fields, api, _
from odoo.exceptions import UserError, ValidationError

class FAccountAccountInherit(models.Model):
    _inherit = 'res.company'

    f_enable_fees = fields.Boolean(string='Disable Fees')
    f_enable_bounce_fees = fields.Boolean(string='Enable default Bounce Fees')
    f_enable_return_fees = fields.Boolean(string='Enable default Return Fees')