odoo.define('f_pos_customs_shuk.f_posr_ass', function(require) {
    'use strict';


    const PosComponent = require('point_of_sale.PosComponent');
    const ProductScreen = require('point_of_sale.ProductScreen');
    const { useListener } = require("@web/core/utils/hooks");
    const Registries = require('point_of_sale.Registries');
    const { _t } = require('web.core');
    const { Gui } = require('point_of_sale.Gui');
    var rpc = require('web.rpc');



	class fposconfWidget extends PosComponent {

	 setup() {
            super.setup();
            useListener('click', this.onClick);
            var order = this.env.pos.get_order();
        }

        
        get currentOrder() {
            return this.env.pos.get_order();
        }
        
        async onClick() {
        this.showTempScreen('posconfigScreen');

        }
    }
    
	fposconfWidget.template = 'fposconfWidget';

    ProductScreen.addControlButton({
        component: fposconfWidget,
        condition: function() {
return true;
        },

    });

    Registries.Component.add(fposconfWidget);

    return fposconfWidget;
    
 
    


});



        
