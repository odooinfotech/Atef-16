import json
import time
from ast import literal_eval
from collections import defaultdict
from datetime import date
from itertools import groupby
from operator import itemgetter

from odoo import SUPERUSER_ID, _, api, fields, models, tools
from odoo.addons.stock.models.stock_move import PROCUREMENT_PRIORITIES
from odoo.exceptions import UserError
from odoo.osv import expression
from odoo.tools import DEFAULT_SERVER_DATETIME_FORMAT, format_datetime
from odoo.tools.float_utils import float_compare, float_is_zero, float_round
from odoo.tools.misc import format_date


class FTransferStockpi(models.Model):
    _inherit = "stock.picking"



    @api.model
    def create(self, vals):
        
        res = super(FTransferStockpi, self).create(vals)

        wh_branch_id = self.env['sale.order'].sudo().search([('name','=',res.origin)]).warehouse_id.f_related_branch.id
        print('wh_branch_id',wh_branch_id)
        if wh_branch_id :
            res.update({
                'f_related_branch' : wh_branch_id or False
            })
        else :
          print('self.picking_type_id.f_related_branch.id',vals['picking_type_id'])
          pt_branch =  self.env['stock.picking.type'].sudo().search([('id','=',vals['picking_type_id'])]).f_related_branch.id
          if pt_branch:
              res.update({
                'f_related_branch' : pt_branch
            })
          else :
              res.update({
                'f_related_branch' : self.env.user.f_default_branch.id
            })
              
        return res




    def button_validate(self):
        res = super(FTransferStockpi, self).button_validate()

        for picking in self:
            new_picking_ids = self.env['stock.picking'].with_user(SUPERUSER_ID).search([
                ('f_name_sequance', '=', picking.f_name_sequance)
            ])
            for xx in new_picking_ids:
                if xx.f_source_transit:
                    xx.with_user(SUPERUSER_ID).write({
                        'f_related_branch': xx.location_dest_id.f_related_branch,
                    })

        return res
