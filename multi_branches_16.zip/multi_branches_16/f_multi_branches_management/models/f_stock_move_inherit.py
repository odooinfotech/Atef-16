from odoo import models, fields, api

class f_stock_move(models.Model):
    _inherit = 'stock.move'
        
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, related='picking_id.f_related_branch')
    f_is_multi_branch = fields.Boolean(related='picking_id.f_is_multi_branch')


class f_stock_move_line(models.Model):
    _inherit = 'stock.move.line'
        
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, related='picking_id.f_related_branch')
    f_is_multi_branch = fields.Boolean(related='picking_id.f_is_multi_branch')
