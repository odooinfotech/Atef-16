from odoo import models, fields, api, SUPERUSER_ID, _
from datetime import datetime, timedelta,date
from dateutil.relativedelta import relativedelta
from odoo.exceptions import UserError

class FMultiPaymentInherit(models.Model):
    _inherit = "f.multi.payments"


    def f_post_payment(self):
        res = super().f_post_payment()
        for pay in self :
            for line in pay.f_payment_lines:
                line.f_current_journal = line.journal_id.id
        return res



    f_check_aging_days = fields.Float(string='Checks Age')

    def write(self, vals):
        obj = super(FMultiPaymentInherit, self).write(vals)
        for rec in self:
            if 'f_payment_date' in vals:
                total_days_amount = 0
                total_amount_checks = 0
                for pay in rec.f_payment_lines:
                    if pay.due_date and rec.f_payment_date and pay.check_details == True:
                        days = (pay.due_date - rec.f_payment_date).days
                        if days < 0:
                            days = 0
                        total_days_amount = total_days_amount + (abs(pay.amount_company_currency_signed) * days)
                        total_amount_checks = total_amount_checks + abs(pay.amount_company_currency_signed)

                if total_amount_checks != 0:
                    rec.f_check_aging_days = float(total_days_amount / total_amount_checks)
                else:
                    rec.f_check_aging_days = 0

        return obj








    # Auto Checks Generation
    f_count = fields.Integer('Number of Checks')
    f_first_due_date = fields.Date('First Due Date',default=fields.Date.context_today)
    f_end_of_month = fields.Boolean('End Of Month')
    f_first_check_number = fields.Char('First Check Number')
    f_frequency_factor = fields.Selection([('months', 'Months'), ('days', 'Days')], default='months',
                                          string='Frequency Factor')
    f_frequency = fields.Integer('Frequency',default=1)
    f_check_amount = fields.Float('Check Amount')

    bank_id = fields.Many2one('res.bank', string="Bank", tracking=True)
    branch_id = fields.Many2one('f.bank.branch', string="Branch", tracking=True , domain="[('bank_id','=',bank_id)]")
    account_number = fields.Char('Account Number')

    def f_auto_generate_checks(self):
        i = 0
        count = self.f_count
        if not self.f_first_due_date or not self.f_first_check_number or not self.f_default_journal or not self.f_frequency or not self.f_frequency_factor :
            raise UserError(_("Missing Values"))

        while count > 0:

            if self.f_frequency_factor == 'days':
                if i==0:
                    print('self.f_first_due_date',self.f_first_due_date)
                    next_check_due_date = self.f_first_due_date
                else :
                    next_check_due_date = self.f_first_due_date+timedelta(days=self.f_frequency*i)
            if self.f_frequency_factor == 'months':
                if i==0:
                    next_check_due_date = self.f_first_due_date
                else :
                    next_check_due_date = self.f_first_due_date+relativedelta(months=self.f_frequency*i)
                    if self.f_end_of_month:

                        next_check_due_date =(next_check_due_date.replace(day=1)) + relativedelta(months=1)- relativedelta(days=1)
                    print('next_check_due_date', next_check_due_date)

            next_check_no = round(float(self.f_first_check_number) +i)
            print('next_check_no',next_check_no)
            i += 1





            vals = {
                    'date': self.f_payment_date,
                    'state': 'draft',
                    'payment_type': self.f_payment_type,
                    'partner_type': self.f_partner_type,
                    'partner_id': self.f_partner_id.id,
                    'journal_id': self.f_default_journal.id,
                    'amount': self.f_check_amount,
                    'currency_id': self.f_default_journal.currency_id.id,
                    'check_number': next_check_no,
                    'check_state': 'draft',
                    'bank_id': self.bank_id.id,
                    'branch_id': self.branch_id.id,
                    'account_number': self.account_number,
                    'due_date' : next_check_due_date,
                    'invoice_user_id': self.user_id.id,
                    'f_parent_id' : self.id,

                }
            if self.f_payment_type == 'outbound':
                check_payment_method = self.env['account.payment.method'].sudo().search([('code','=','check_printing'),('payment_type','=','outbound')],limit=1)
                payment_method_line_id = self.env['account.payment.method.line'].sudo().search(
                    [('journal_id', '=', self.f_default_journal.id), ('payment_method_id', '=', check_payment_method.id)],
                    limit=1).id  # Checks
                vals['payment_method_line_id'] = payment_method_line_id

            print('Vals',vals)
            self.env['account.payment'].sudo().create(vals)
            count = count - 1
