# -*- coding: utf-8 -*-
{
    'name': "Order report Thermal",

    'summary': """
     pos report - product & payment""",

    'description': """
        Long description of module's purpose
    """,

    'author': "Falak Solutions",
    'license': 'LGPL-3',


    'category': 'Uncategorized',
    'version': '0.1',


    'depends': ['base','sale_management'],

    # always loaded
    'data': [
       'views/f_sale_report_thermal.xml',
    ],

}
