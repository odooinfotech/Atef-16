from odoo import models, fields, api, _
import itertools
class FBranchChequeWizardInerit(models.TransientModel):
    _inherit = 'cheque.wizard'

    
    def prepare_endorse_payment_vals(self,selected_payments):
        #In this Fucntion we create the multi payment and the payment is created in POST action 

        multi_payment,prepared_vals = super(FBranchChequeWizardInerit, self).prepare_endorse_payment_vals(selected_payments)

        print('prepared_vals',prepared_vals)
        lines = []

        payments = self.env['account.payment'].sudo().search([('f_parent_id', '=',multi_payment.id)])
        if self.env.company.f_default_partner_branch:
            if self.supplier_id.f_related_branch:
                payments.write({'f_related_branch':self.supplier_id.f_related_branch.id})
            else:
                payments.write({'f_related_branch': self.env.user.f_default_branch.id})
        else:
            if self.env.company.f_allow_multi_branches ==True :
                payments.write({'f_related_branch': self.env.user.f_default_branch.id})


        multi_payment = self.env['f.multi.payments'].sudo().search([('id','=',multi_payment.id)])
        if self.env.company.f_default_partner_branch:
            if self.supplier_id.f_related_branch:
                multi_payment.write({'f_related_branch':self.supplier_id.f_related_branch.id})
            else:
                payments.write({'f_related_branch': self.env.user.f_default_branch.id})

        else:
            if self.env.company.f_allow_multi_branches ==True :
                payments.write({'f_related_branch': self.env.user.f_default_branch.id})

        return multi_payment,prepared_vals
