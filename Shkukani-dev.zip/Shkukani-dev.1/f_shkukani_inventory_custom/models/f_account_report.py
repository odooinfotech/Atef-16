# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models

class FAccountInvReportInheritD(models.Model):
    _inherit = "account.invoice.report"
    
    f_article = fields.Char(string='Article')
    
    def _select(self):
        return super(FAccountInvReportInheritD, self)._select() + """  ,template.f_article  """
