
# -*- coding: utf-8 -*-

from odoo import models, fields, api,_

# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

from odoo import fields, models,_


class hr_employee(models.Model):
    _inherit = 'hr.employee'

    f_hide_paid_orders = fields.Boolean('Show Paid Orders IN POS Screen ',default=False)

class PosSession(models.Model):
    _inherit = 'pos.session'



    def _loader_params_hr_employee(self):
        res = super()._loader_params_hr_employee()
        res.get('search_params').get('fields').extend(
                ['f_hide_paid_orders'])
        return res
