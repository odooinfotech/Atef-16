from odoo import models, fields, api, _
from datetime import datetime, timedelta, date
from odoo.exceptions import UserError, ValidationError
import locale


class FWizardbulkeport(models.Model):
    _name = "f.bulk.checks.report.wizard"
    _description = "Bulk Checks Rep Wizard"

    lang = fields.Many2one('res.lang', string='Language')

    def print_report_bulk_checks(self):
        print(self.lang)

        data = {'lang': self.lang.code}

        bulk_ids = self.env['f.bulk.checks'].browse(self.env.context.get('active_ids'))
        bulk_ids.write({
            'f_lang': self.lang.code,

        })


        return self.env.ref('check_management.f_bulk_checks_action_report').report_action(bulk_ids.ids)


class FCheckActions(models.Model):
    _name = 'f.check.action'
    _description = "Checks Actions"
    _rec_name = "f_action_name"

    f_action_name = fields.Char(string="Name" , translate=True)
    f_checks_type = fields.Selection([('inbound', 'Inbound'), ('outbound', 'Outbound')], string="Check Type",
                                     default="inbound")
    f_code = fields.Char(string="Code")


class FBulkActions(models.Model):
    _name = 'f.bulk.checks'
    _inherit = ['mail.thread', 'mail.activity.mixin']
    _description = "Bulk Checks Action"
    _rec_name = "f_bulk_sequence"
    _check_company_auto = True
    _order = "f_action_date desc"

    def f_submit_bulk(self):
        if not self.f_checks_to_action :
            raise UserError(_("Please Select Checks First "))

        domain = [('company_id', '=', self.company_id.id), ('state', '=', 'posted'),
                  ('payment_type', '=', self.f_check_action.f_checks_type),
                  ('check_number', '!=', False), '|', '|',
                  ('check_state', '=', self.state1), ('check_state', '=', self.state2),
                  ('check_state', '=', self.state3)]

        if self.f_currency_id.id:
            domain += [('currency_id', '=', self.f_currency_id.id)]

        checks_ids = self.env['account.payment'].search(domain)

        ex_check_ids = list()
        ex_check_ids_msg = ''
        for rec in self.f_checks_to_action:
            if rec.id not in checks_ids.ids:
                ex_check_ids.append('''%s ''' % (rec.name))

        ex_check_ids_msg = '\n'.join(ex_check_ids).strip(' + ')

        if len(ex_check_ids) > 0:
            raise UserError(_("Can't Confirm !! wrong Payments  : %s ,With selected Action Type :  %s  " % (
            ex_check_ids_msg, self.f_check_action.f_action_name)))



        return {
            'name': 'Checks Actions',
            'type': 'ir.actions.act_window',
            'view_mode': 'form',
            'res_model': 'cheque.wizard',
            'target': 'new',
            'context': {'default_context_active_id':self.f_checks_to_action[0].id,
                        'form_view_ref':'check_management.cheque_wizard_wizard_view','action_source': 'bulk_action', 'default_transfer_to_account_id': self.f_action_account_id.id,
                        'default_deposit_to_account_id': self.f_action_account_id.id,
                        'default_supplier_id':self.supplier_id.id,
                        'default_collect_from_account_id': self.f_action_account_id.id, 'action_type': self.f_code,
                        'default_currency_id': self.f_currency_id.id, 'default_action_date': self.f_action_date,
                        'active_ids': self.f_checks_to_action.ids,'default_bulk_seq':self.f_bulk_sequence,'default_bulk_id':self.id}
        }

    def f_cancel_bulk(self):
        print('Cancel')
        self.f_bulk_state = 'cancel'
    def f_draft_bulk(self):
        print('Cancel')
        self.f_bulk_state = 'draft'




    # @api.model
    # def create(self, vals):
    #     print('vals', vals)
    #     vals['f_bulk_sequence'] = self.get_bulk_seq(vals['f_action_date'])
    #     obj = super(FBulkActions, self).create(vals)
    #     return obj
    f_lang = fields.Char(string='Language For Printing Purpose')
    active =fields.Boolean('Active', default=True)
    f_bulk_sequence = fields.Char(string='name', readonly=True, copy=False)

    f_check_action = fields.Many2one('f.check.action', string="Action",required=True)
    f_code = fields.Char(related="f_check_action.f_code",store=True)
    f_action_date = fields.Date('Action Date',required=True,default=fields.Date.context_today , copy=False)
    f_bulk_state = fields.Selection([('draft', 'Draft'), ('done', 'Done'), ('cancel', 'Cancelled')], default='draft', copy=False)

    f_note = fields.Char(string="Notes")
    f_user = fields.Many2one('res.users', string="Responsible", default=lambda self: self.env.uid)
    f_action_account_id = fields.Many2one('account.journal', 'Journal', copy=False)
    f_currency_id = fields.Many2one('res.currency', string='Currency', related = "f_action_account_id.currency_id", store=True)

    f_checks_count = fields.Integer('Checks Count',store =True,copy=False)
    f_total_amount = fields.Monetary('Total',compute="_get_total",store =True, copy=False , currency_field='f_currency_id',)
    f_total_checks_amount_char = fields.Char('Total',compute="_get_total_per_currency")
    f_total_checks_amount_stored = fields.Char('Total/currency')


    company_id = fields.Many2one(
        'res.company', required=True, default=lambda self: self.env.company)


    @api.onchange('company_id')
    def f_compget_values_journals_domain(self):
        if self.company_id:
            domain = [('company_id', '=', self.company_id.id)]
            return {'domain': {'f_action_account_id': domain}}
            
            

    @api.depends('f_checks_to_action')
    def _get_total_per_currency(self):
        currency_totals = {}
        for check in self.f_checks_to_action:
            if check.currency_id:
                if check.currency_id not in currency_totals:
                    currency_totals[check.currency_id] = check.amount
                else:
                    currency_totals[check.currency_id] += check.amount
        for rec in self:
            currency_total_str = ''
            for currency, total in currency_totals.items():
                formatted_total = currency.round(total)
                locale.setlocale(locale.LC_ALL, '')
                formatted_total_str = locale.currency(formatted_total, symbol=False, grouping=True)

                currency_total_str += f"{formatted_total_str}{currency.symbol}  "
            rec.f_total_checks_amount_char = currency_total_str.strip()
            rec.f_total_checks_amount_stored = currency_total_str.strip()

    @api.depends('f_checks_to_action')
    def _get_total(self):
        total = 0
        count = 0
        for check in self.f_checks_to_action :
            total += check.amount
            count+=1

        self.f_total_amount = total
        self.f_checks_count = count

    f_checks_type = fields.Selection([('inbound', 'Inbound'), ('outbound', 'Outbound')], string="Check Type",
                                     default="inbound")
    supplier_id = fields.Many2one('res.partner', 'Vendors')

    state1 = fields.Char()
    state2 = fields.Char()
    state3 = fields.Char()

    @api.onchange('f_check_action','f_action_account_id')
    def onchange_check_action(self):

        self.state1 = False
        self.state2 = False
        self.state3 = False
        domain=[]
        checks_domain_currency = [('currency_id', '=', self.f_currency_id.id)]
        if self.f_check_action.f_code == 'deposit':
            self.state1 = 'in_check_box'
            self.state2 = 'bounced'
            domain = [('allow_deposit','=',True),('type','in',('cash','bank'))]

        if self.f_check_action.f_code == 'uncollect':
            self.state1 = 'collected'
            domain = [('name', '=', False)]
            checks_domain_currency = []

        if self.f_check_action.f_code == 'undeposit':
            self.state1 = 'under_collection'
            domain = [('allow_deposit', '=', True), ('type', 'in', ('cash', 'bank'))]
            checks_domain_currency = []

        if self.f_check_action.f_code == 'collect':
            self.state1 = 'in_check_box'
            self.state2 = 'bounced'
            self.state3 = 'under_collection'
            domain = [('allow_deposit', '=', True),('type','in',('cash','bank'))]
        if self.f_check_action.f_code == 'bounce':
            self.state1 = 'collected'
            domain = [('name','=',False)]
            checks_domain_currency = []
        if self.f_check_action.f_code == 'endorse':
            self.state1 = 'bounced'
            self.state2 = 'in_check_box'
            domain = [('name', '=', False)]
            checks_domain_currency = []
        if self.f_check_action.f_code == 'unendorse':
            self.state1 = 'endorsed'
            domain = [('name', '=', False)]
            checks_domain_currency = []
        if self.f_check_action.f_code == 'transfer':
            self.state1 = 'in_check_box'
            self.state2 = 'bounced'
            domain = [('allow_transfer', '=', True)]
        if self.f_check_action.f_code == 'release':
            self.state1 = 'issued'
            domain = [('type','in',('cash','bank'))]
            checks_domain_currency = []
        if self.f_check_action.f_code == 'return':
            self.state1 = 'bounced'
            self.state2 = 'in_check_box'
            domain = [('type', 'in', ('cash', 'bank'))]
            checks_domain_currency =[]
        if self.f_check_action.f_code == 'v_return':
            self.state1 = 'issued'
            self.state2 = 'released'
            domain = [('type', 'in', ('cash', 'bank'))]
            checks_domain_currency = []

        print('Allowed states',self.state1,self.state2,self.state3)
        self.f_checks_type = self.f_check_action.f_checks_type
        print('domain',domain)

        domain +=[('company_id', '=', self.company_id.id)]

        checks_domain = [('company_id','=',self.company_id.id),('state','=','posted'),('id', 'not in', self.f_checks_to_action.ids), ('payment_type', '=', self.f_checks_type),
                          ('check_number', '!=', False), '|', '|',
                         ('check_state', '=', self.state1), ('check_state', '=', self.state2), ('check_state', '=', self.state3)]

        contact_domain = []
        # if self.env['ir.config_parameter'].sudo().get_param('check_management.f_warn_archive_contacts'):
        #     contact_domain = [('partner_id.active', '=', True)]

        checks_domain = checks_domain_currency + checks_domain + contact_domain


        print('checks_domain',checks_domain)

        return {'domain': {'f_action_account_id': domain, 'f_checks_to_action': checks_domain}}


    f_checks_to_action = fields.Many2many('account.payment', string="Checks",
                                          domain="([('state','=','posted'),('currency_id', '=',f_currency_id),('id','not in',f_checks_to_action),('payment_type', '=', f_checks_type),('check_number', '!=',False),'|','|',('check_state','=',state1),('check_state','=',state2),('check_state','=',state3)])")
