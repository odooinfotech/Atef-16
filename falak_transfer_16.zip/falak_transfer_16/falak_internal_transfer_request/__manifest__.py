# -*- coding: utf-8 -*-
{
    'name': "Falak Internal Transfer Request",

    'summary': """
        """,

    'description': """
        This module is used for:
        -- preparing internal transfer request between two locations , 
        -- The items can be prepared automatically on two ways :
            - Depending on min/max rule of each product in the (To Location )
            - depending on soled quantities of each product in the (To Location)
        -- The items also can be prepared manually.
        -- Ability Add/Remove Items Manually to the Request and to update the demand Quantity . 
    
        Validations: 
        -- New Requests are not allowed if there is a running (not done or cancelled) request for the 
           same (To Location ) 
        -- if the Request state is ready, you can't edit the demand qty
        -- At Process Action The system create a new shipment automatically and connect it to
           the current request , this shipment can be viewed in the request screen as smart button. 
    """,

    'author': "Falak Solutions",
    'license': 'LGPL-3',
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '14.0',

    # any module necessary for this one to work correctly
    'depends': ['base','stock', 'transfer_module','location_access'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/f_internal_transfer_request_access.xml',
        'views/f_wizard_form.xml',
        'views/f_internal_request_view.xml',
        'views/f_res_config_settings_view.xml',
        'data/f_sequence_number_template.xml',
        
        
    ],
    # only loaded in demonstration mode
    # 'demo': [
    #     'demo/demo.xml',
    # ],
}
