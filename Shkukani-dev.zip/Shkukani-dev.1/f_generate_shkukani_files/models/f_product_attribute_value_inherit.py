from odoo import models, fields, api, _


class FProductAttributeValueInherit(models.Model):
    _inherit = 'product.attribute.value'

    f_code = fields.Char(string='Code')
