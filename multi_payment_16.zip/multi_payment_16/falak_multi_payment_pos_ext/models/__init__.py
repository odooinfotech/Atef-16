# -*- coding: utf-8 -*-

from . import f_pos_session_inherit
from . import f_multi_payment_inherit
