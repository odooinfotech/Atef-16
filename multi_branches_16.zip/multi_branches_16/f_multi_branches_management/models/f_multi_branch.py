from odoo import models, fields, api

class f_multi_branches_management(models.Model):
    _name = 'f.comp.branches'
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = 'List of defined Branches'
    _rec_name = 'f_branch_name'
    
    active = fields.Boolean(string='Active',default=True)
    f_branch_name = fields.Char('Branch Name')
    company_id     = fields.Many2one('res.company', string = 'Company', domain = "[('f_allow_multi_branches','=',True)]" )
    fcb_desc      = fields.Text('Description')
    fcb_phone     = fields.Char('Phone')
    f_for_website = fields.Boolean('Website Branch')
    
