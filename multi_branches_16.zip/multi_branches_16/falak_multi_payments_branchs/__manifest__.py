# -*- coding: utf-8 -*-
{
    'name': "falak_multi_payments_branchs",

    'summary': """
       this module integrates the multi payments with multi branches  
       """,

    'description': """
    
        - Add Branch Field to the Multi  payment.
         
        - Change the Branch Field in the payment to be same as the group chosen in the Multi  payment
        
        -  Add Access on the Multi Payments Based on the branch 
        
        - when installing the Module if there are previous multi payment without Related branches
          then the system will automatically update the multi payment header branch to be same as payment branch  
               
          
    """,

    'author': "Falak Solutions",
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['base','account','web','falak_multi_payments_base','f_multi_branches_management','check_management'],

    # always loaded
    'data': [
        'security/f_record_rule.xml',
        'views/f_multi_payments_view_inherit.xml',
        #'wizard/f_multi_payments_lines_view.xml',
        #'views/templates.xml',
    ],

    
    'post_init_hook': 'update_multi_payments_branches',
}

