# -*- coding: utf-8 -*-

from odoo import models, fields, api,_


class FDISCconfigpos(models.Model):
    _inherit = 'pos.config'

    f_empl_ass_req = fields.Boolean("Required Cashier/Assisted by ", default=False)
    f_pos_configreq = fields.Boolean("Required POS Shop /Returned Items", default=False)



class ResConfigSettings(models.TransientModel):
    _inherit = 'res.config.settings'

    f_empl_ass_req = fields.Boolean(related='pos_config_id.f_empl_ass_req', readonly=False)
    f_pos_configreq = fields.Boolean(related='pos_config_id.f_pos_configreq', readonly=False)




class PosOrder(models.Model):
    _inherit = 'pos.order'

    f_employee_assisted = fields.Many2one('hr.employee',string='Assisted by')
    f_pos_config = fields.Many2one('pos.config', string='POS Shop')


    @api.model
    def _order_fields(self, ui_order):
        res = super()._order_fields(ui_order)
        if ui_order.get('f_employee_assisted') :
            res['f_employee_assisted'] = ui_order.get('f_employee_assisted')

        if ui_order.get('f_pos_config') :
            res['f_pos_config'] = ui_order.get('f_pos_config')['id']
        return res

class PosSession(models.Model):
    _inherit = 'pos.session'

    def _loader_params_product_product(self):
        params = super()._loader_params_product_product()
        params['search_params']['fields'].append('f_article')
        return params

    def f_get_all_pos_config(self):
        users = self.sudo().env['pos.config'].search([('active','=',True),'|',('company_id','=',self.env.company.id),('company_id','=',False)])
        user_list = [{'name': user.name, 'id': user.id} for user in users]
        user_list.append({'name': 'Remove POS', 'id': 0})

        return user_list






    def _loader_params_pos_order(self):
        res = super()._loader_params_pos_orde()
        res.get('search_params').get('fields').extend(
                ['f_employee_assisted','f_pos_config'])
        return res


    def _pos_ui_models_to_load(self):
        """Inherited to load promotion models"""
        result = super()._pos_ui_models_to_load()
        result += ['product.attribute.value']
        return result

    def _loader_params_product_attribute_value(self):
        return {
            'search_params': {
                'fields': ['name','id','f_code','attribute_id'],
                'order': 'attribute_id desc',
            },
        }



    def _get_pos_ui_product_attribute_value(self, params):
        return self.env['product.attribute.value'].search_read(**params['search_params'])


