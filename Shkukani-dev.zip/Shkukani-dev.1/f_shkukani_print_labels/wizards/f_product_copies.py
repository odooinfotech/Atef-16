from odoo import models, fields, api, _


class FProductCopies(models.TransientModel):
    _name = "f.product.copies"
    _description = 'Product Copies'

    f_product_id = fields.Many2one('product.product', string='Product')
    f_copy = fields.Integer(string='Copy')
    f_company = fields.Boolean(string='Company', default=False)
    f_product_name = fields.Boolean(string='Product Name', default=False)
    f_article = fields.Boolean(string='Product Article', default=False)
    f_product_price = fields.Boolean(string='Product Price', default=False)
    f_color = fields.Boolean(string='Product Color', default=False)
    f_size = fields.Boolean(string='Product Size', default=False)
    f_font_size = fields.Integer(string='Font Size (px)')
    parent_id   = fields.Many2one('f.print.options.wizard', string='parent')
    f_printed = fields.Boolean(string='Printed', default=False)

    @api.model
    def _get_values(self):
        record = []
        for rec in self:
            rec.f_printed = True
            rec.parent_id.f_printed_labels += rec.f_copy
            for copy in range(int(rec.f_copy)):
                price = rec.f_product_id.list_price
                print("Price = ", price)
                lines = list(range(1))
                color = ""
                size = ""
                color_attributes = self.env['product.attribute'].sudo().search([('f_type', '=', 'color')])
                size_attributes = self.env['product.attribute'].sudo().search([('f_type', '=', 'size')])
                product_values = rec.f_product_id.product_template_variant_value_ids
                print(product_values)
                for product_value in product_values:
                    attribute_value = product_value.product_attribute_value_id
                    if attribute_value and attribute_value.attribute_id in color_attributes:
                        print("Color: ", attribute_value.name)
                        color = attribute_value.f_code or '0'
                    if attribute_value and attribute_value.attribute_id in size_attributes:
                        print("Size: ", attribute_value.name)
                        size = attribute_value.name or ' '
                record.append({
                    'f_copy': rec,
                    'f_product_id': rec.f_product_id,
                    'f_price': price,
                    'f_product_name': rec.f_product_name,
                    'f_article': rec.f_article,
                    'f_product_price': rec.f_product_price,
                    'f_color': rec.f_color,
                    'f_color_value': color,
                    'f_size': rec.f_size,
                    'f_size_value': size,
                    'f_company': rec.f_company,
                    'f_font_size': str(rec.f_font_size) + 'px',
                    'f_price_size': str(rec.f_font_size + 3) + 'px',
                    'f_sheet_per_line': lines,

                })
        print(record)
        return record
