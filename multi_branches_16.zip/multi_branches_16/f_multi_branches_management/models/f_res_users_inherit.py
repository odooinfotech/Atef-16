from odoo import models, fields, api

class f_res_users(models.Model):
    _inherit = 'res.users'

    ## This function is to filter the branches list based on the allowed companies for the selected user
    ## and to remove the list of branches related to the removed companies allowed  for the selected user   --not done yet 
    @api.onchange('company_ids','company_id')
    def _get_allowed_branches(self):
        #update the filed (f_allowed_branches) domain 
        
        for oc in self._origin.company_ids:
            if oc.id not in  self.company_ids.ids : 
                branches = self.env['f.comp.branches'].search([('company_id.id','=',oc.id)])
                for b in branches : 
                    
                    self.write({'f_allowed_branches':[(3,b.id)]})
                #self.env['f.comp.branches'].search([('company_id.id','=',ob.id)]).write({'company_id':[(5)]})
                print(oc.name)
        
        domain =  [('company_id' , 'in', self.company_ids.ids)]
            
        return {'domain': {'f_allowed_branches': domain}}

        
    #f_allow_all        = fields.Boolean('Access to All Branches', help = 'Grant Access to the user to all branches based on the companies the user has access on')
    
    f_allowed_branches = fields.Many2many('f.comp.branches','f_comp_branches_rel' ,string = 'Allowed Branches')
    f_default_branch   = fields.Many2one('f.comp.branches' , string = 'Default Branch' )
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')
    
    
