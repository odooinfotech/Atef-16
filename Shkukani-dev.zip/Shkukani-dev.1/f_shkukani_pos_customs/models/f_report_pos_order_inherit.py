from odoo import api, fields, models, _


class FReportPosOrderInherit(models.Model):
    _inherit = 'report.pos.order'

    f_article = fields.Char(string='Article')
    f_season = fields.Char(string='Season')
    f_section = fields.Many2one('f.product.section', string='Section')

    def _select(self):
        return super(FReportPosOrderInherit, self)._select() + ',pt.f_article AS f_article,pt.f_season as f_season,pt.f_section as f_section'

    def _group_by(self):
        return super(FReportPosOrderInherit, self)._group_by() + ',pt.f_article, pt.f_season,pt.f_section'
