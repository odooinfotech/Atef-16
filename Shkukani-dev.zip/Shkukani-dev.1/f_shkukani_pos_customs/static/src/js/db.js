odoo.define('f_shkukani_pos_customs.db', function (require) {
"use strict";
    var PosDB = require('point_of_sale.DB');
    var models = require('point_of_sale.models');

    //models.load_fields("product.product", ['f_commercial_name'])

    PosDB.include({
        init: function(options){
            this._super(options);

        },

          _product_search_string: function(product){
        	console.log("search - product ",product)
            var str = this._super(product);
        	console.log("search - comm",str,product.f_index)
            str = str.slice(0, str.length - 1);
            if (product.f_index) {
                str += '|' + product.f_index;
            }
            str += '\n';

            return str;
        },
    });
});