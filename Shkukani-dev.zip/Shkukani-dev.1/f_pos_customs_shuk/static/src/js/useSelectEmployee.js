odoo.define('f_pos_customs_shuk.FcustomdSelectCashierMixin', function (require) {
    'use strict';
    const { Component } = owl;
    const { _t } = require('web.core');
    const { Gui } = require('point_of_sale.Gui');
    const FcustomdSelectCashierMixin = (PosComponent) => class ComponentWithSelectCashierMixin extends PosComponent {





        async selectCashier() {

        if (this.env.pos.config.module_pos_hr) {
        const list = this.env.pos.employees.map((employee) => {
                        return {
                            id: employee.id,
                            item: employee,
                            label: employee.name,
                            isSelected: false,
                        };
                    });
        	var manager_list = []
        	for(var x in list){
        		manager_list.push(list[x]);



        	}
        	let xx = true;
        	let {confirmed, payload: employee} = await this.showPopup('SelectionPopup', {
                    title: this.env._t('Change Assisted by'),
                    list: manager_list,
                });



                if (!confirmed) {
                    return;
                }

                if (employee) {

                console.log('employee1111',employee)

                        this.env.pos.get_order().f_ass_set_cashier(employee);
                         this.trigger('close-temp-screen');



                }

                    return employee;


}

        }


    }

    return FcustomdSelectCashierMixin;
});
