from odoo import models, fields, api, _

class FAccountPaymentInherit (models.Model):
    _inherit = 'account.payment'
 
    #Override by falak   
    def write(self, vals):
        print('In Write >>>>>>>>>>>>>>>>>>>>>>>>1',vals)        
        res = super().write(vals)
        #aml = self.env['account.move.line'].search([('move_id','=',self.move_id.id)])
        #print('aml',aml)
        for pay in self :
            if pay.f_is_multi_branch:
                if pay.move_id:
                    pay.move_id.write({'f_related_branch':self.f_related_branch.id})
                    for rec in self.move_id.line_ids :
                       rec.write({'f_related_branch':self.f_related_branch.id})
        return res  
    
