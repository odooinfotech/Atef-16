from odoo import models, fields, api, _
from odoo.exceptions import ValidationError, UserError

class FHrEmployeeInherit(models.Model):
    _inherit = 'hr.employee'

    f_code = fields.Char(string='Custom Code')
    f_nickname = fields.Char(string='Nickname')

    @api.onchange('f_nickname')
    def _f_onchange_nickname(self):
        for rec in self:
            nickname = rec.f_nickname
            if nickname and len(nickname) > 10:
                raise ValidationError(_('Nickname must be less than 10 letters.'))
