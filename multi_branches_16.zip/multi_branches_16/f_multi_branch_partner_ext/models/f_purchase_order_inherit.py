from odoo import models, fields, api

class f_purchase_order_or(models.Model):
    _inherit = 'purchase.order'
    

    @api.onchange('partner_id')
    def _get_default_branch_partner(self):
        
         cust_default_branch = False
         if self.env.user.company_id.f_allow_multi_branches ==True : 
             print('mmmmmm',self.partner_id)
             cust_default_branch = self.env['res.partner'].search([('id','=',self.partner_id.id)]).f_related_branch.id
             if cust_default_branch:
                 print('mmmmmm',cust_default_branch)
                 self.f_related_branch  = cust_default_branch
    
    @api.model
    def _prepare_picking(self):
        res = super(f_purchase_order_or, self)._prepare_picking()
        branch_id = False
        if self.picking_type_id.f_related_branch:
            branch_id = self.picking_type_id.f_related_branch.id
        else :
            branch_id = self.partner_id.f_related_branch.id
        res.update({
            'f_related_branch' : branch_id
        })
        return res


    def _prepare_invoice(self):
        result = super(f_purchase_order_or, self)._prepare_invoice()
        branch_id = False
        if self.f_related_branch:
            branch_id = self.f_related_branch.id
        else :
            branch_id = self.partner_id.f_related_branch.id

        result.update({
                
                'f_related_branch' : branch_id
            })
        
        return result
   