from odoo import models, fields, api,SUPERUSER_ID, _


class FexpenseSheet(models.Model):
    _inherit = 'hr.expense.sheet'

    def _prepare_payment_vals(self):
        vals = super(FexpenseSheet, self)._prepare_payment_vals()
        multi_payment_vals = {
            'f_payment_type': 'outbound',
            'f_partner_type': 'supplier',
            'f_payment_date': vals['invoice_date'],
            'f_partner_id': self.env.company.partner_id.id,
        }


        multi_payment = self.env['f.multi.payments']
        multi_payment = multi_payment.create(multi_payment_vals)
        vals['f_parent_id'] =multi_payment.id
        multi_payment.sudo().f_post_payment()

        return vals



