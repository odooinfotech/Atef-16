# -*- coding: utf-8 -*-

from . import f_internal_transfer_req_inherit