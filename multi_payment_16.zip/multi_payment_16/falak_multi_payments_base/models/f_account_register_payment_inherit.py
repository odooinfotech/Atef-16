from odoo import models, fields, api, _


class FAccountRegisterPaymentInherit(models.TransientModel):
    _inherit = 'account.payment.register'  
    
    
    def _create_payment_vals_from_wizard(self,batch_result):
        payment_vals = super()._create_payment_vals_from_wizard(batch_result)


        multi_payment = self.env['f.multi.payments'].create ({
           'f_payment_type'     : payment_vals['payment_type'],
            'f_partner_type'    : payment_vals['partner_type'],
            'f_partner_id'      : payment_vals['partner_id'],
            'f_currency_id'     : payment_vals['currency_id'],
            'f_payment_date'    : payment_vals['date'],
            'f_multi_pay_state' :'posted',
            })        
        
        #multi_payment.f_post_payment()
        
        payment_vals ['f_parent_id'] = multi_payment.id
        return payment_vals


    def _create_payment_vals_from_batch(self, batch_result):
        
        batch_values = super(FAccountRegisterPaymentInherit, self)._create_payment_vals_from_batch(batch_result)
        
        multi_payment = self.env['f.multi.payments'].create ({
            'f_payment_type'    : batch_values['payment_type'],
            'f_partner_type'    : batch_values['partner_type'],
            'f_partner_id'      : batch_values['partner_id'],
            'f_currency_id'     : batch_values['currency_id'],
            'f_payment_date'    : batch_values['date'],
            'f_multi_pay_state' :'posted',
            })        
        #multi_payment.f_post_payment()
        batch_values ['f_parent_id'] = multi_payment.id
        return batch_values
    
    
    def action_create_payments(self):
        action = super(FAccountRegisterPaymentInherit, self).action_create_payments()
        #print('895666666666666666666666666',action)
        #print(n)   
        if action != True  and 'domain' in  action : 
            
            domain = action['domain']
            payments = self.env['account.payment'].search(domain)
            
            #print('domain',domain)
            if action['view_mode'] == 'form':
                domain = action['domain'] 
                print('domain',domain)
                action.update({
                        'res_model': 'f.multi.payments',
                        'view_mode': 'form',
                        'domain': [('id', 'in', payments.f_parent_id.id)],
                    })
            else:
                domain = action['domain'] 
                action.update({
                    'res_model': 'f.multi.payments',
                    'view_mode': 'tree,form',
                    'domain': [('id', 'in', payments.f_parent_id.ids)],
                })
        return action
