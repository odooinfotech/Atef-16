from odoo import models, fields, api, _
import itertools



class FChequeWizardInerit(models.TransientModel):
    _inherit = 'cheque.wizard'


    def get_debt_account(self,pay):
        print('payyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyyy2222222222222')
        type = self.env['f.type.details'].search([('f_is_returened','=',True)],limit=1)
        account = self.env['account.account'].search([('f_type_id','=',type.id),('account_type','=','asset_receivable')],limit=1)
        return account.id


