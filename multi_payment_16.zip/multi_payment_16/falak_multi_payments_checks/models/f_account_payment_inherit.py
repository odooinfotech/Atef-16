from odoo import models, fields, api,SUPERUSER_ID, _
from odoo.exceptions import UserError, ValidationError, Warning



class FAccountPaymentInheritCheck(models.Model):
    _inherit = "account.payment"


    def action_post(self):
            for rec in self:

                if rec.partner_id.f_check_restricted:
                    if rec.journal_id.check_details :
                        days = (rec.due_date - rec.f_parent_id.f_payment_date).days
                        if rec.journal_id.check_details and days >  30 :
                            raise UserError(_(
                                " Can't  Confirm there is checks payment where checks restricted from this partner . "
    
                            ))
                super().action_post()


    def f_calculate_totalagedchecks(self):
        if self.f_parent_id:
            total_days_amount = 0
            total_amount_checks = 0
            for pay in self.f_parent_id.f_payment_lines:
                if pay.due_date and self.f_parent_id.f_payment_date and pay.check_details == True and pay.state != 'cancel':
                    days = (pay.due_date - self.f_parent_id.f_payment_date).days
                    if days < 0:
                        days = 0
                    total_days_amount = total_days_amount + (abs(pay.amount_company_currency_signed) * days)
                    total_amount_checks = total_amount_checks + abs(pay.amount_company_currency_signed)
                    if total_amount_checks != 0:
                        f_check_aging_days = float(total_days_amount / total_amount_checks)
                        self.f_parent_id.write({'f_check_aging_days': f_check_aging_days})

                    else:
                        f_check_aging_days = 0
                        self.f_parent_id.write({'f_check_aging_days': f_check_aging_days})




    f_dest_pay_vendor = fields.Many2one('res.partner',related='des_payment.partner_id',string='Supplier Payment Vendor',store=True)

    f_endorse_exchange_rate = fields.Float(string='Endorse EX.Rate',default=False, digits=(16, 4))




    
    @api.onchange('payment_method_line_id')
    def empty_check_info(self):
        print('empty_check_info')
        for rec in self :
            rec.check_number = False 
            rec.due_date = False
            rec.check_state = False
            rec.check_comments = False
            
