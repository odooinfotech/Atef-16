from odoo import tools
from odoo import api, fields, models, _


class FCSVProductsalesReport(models.Model):
    _name = "f.sales.productreportcsv"
    _description = "Product Sales Analysis / POS Report"
    _auto = False

    product_id = fields.Many2one('product.product', string='Product', readonly=True)
    qty = fields.Integer('Quantity', readonly=True)
    f_season = fields.Char(string='Season')
    barcode = fields.Char(string='EAN CODE')
    type = fields.Char(string='Ticket Type')
    company_id = fields.Many2one('res.company', string='Company', readonly=True)
    pos_shop = fields.Many2one('pos.config', string='POS Shop', readonly=True)
    order_no = fields.Char(string='Ticket Number')
    customer_no = fields.Char(string='Customer Number')
    date = fields.Date(string='Date')
    price = fields.Float(string='Float Retail price (Without Discount)')
    price_with_disc = fields.Float(string='Float Retail price (With Discount)')

    price_char = fields.Char(string='Retail price (Without Discount)')
    price_with_disc_char = fields.Char(string='Retail price (With Discount)')

    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        self.env.cr.execute("""CREATE or REPLACE VIEW  f_sales_productreportcsv as 
  select max(a.id) as id from product_product a


        """)
