from odoo import models, fields, api, _


class FReportPaperformat(models.Model):
    _inherit = "report.paperformat"

    f_font_size = fields.Integer(string='Font Size (px)')


