from odoo import models, fields, api
   
class FAccountPaymentInherit(models.Model):
    _inherit = 'account.payment'


  #  def write(self,vals):
      #  if 'partner_id' in vals :
          #  partner_val = self.env['res.partner'].search([('id','=', vals['partner_id'] )])
          #  if self.move_id :
              #  self.sudo().move_id.write({
                  #  'f_related_branch':partner_val.f_related_branch.id
               # })
      #  res = super().write(vals)
      #  return res
    

    #f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, related = 'f_parent_id.f_related_branch')
    @api.model
    def create (self,vals):
       if 'f_show_internal_transfer' not in vals and 'f_parent_id' in vals:
           branch =  self.env['f.multi.payments'].search([('id','=', vals['f_parent_id'])]).f_related_branch.id
           
           vals['f_related_branch'] = branch
           
       res = super(FAccountPaymentInherit, self).create(vals)
       return res
        
