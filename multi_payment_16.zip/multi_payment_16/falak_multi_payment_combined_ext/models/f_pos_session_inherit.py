from odoo import models,_

class FPosSessionInherit(models.Model):
    _inherit = 'pos.session'
        
    def _create_combine_account_payment(self, payment_method, amounts, diff_amount):
        result = super(FPosSessionInherit,self)._create_combine_account_payment(payment_method, amounts, diff_amount)
        combine_payment = result[0].move_id.payment_ids[0]
        #print('try',self.env.ref('falak_multi_payments_base.99999999'),)
        multi_payment = self.env['f.multi.payments'].create ({
                    'f_payment_type'   : 'inbound',
                    'f_partner_type'   : 'customer',
                    'f_partner_id'     : self.env.ref('falak_multi_payment_combined_ext.99999999').id,
                    'f_currency_id'    : combine_payment.journal_id.currency_id.id,
                    'f_payment_date'   : combine_payment.date,
                    'f_pay_reference'  : _('Combine %s POS payments from %s') % (payment_method.name, self.name),
                    'f_pos_session_id' : self.id,
                    'f_payment_total'  : combine_payment.amount_company_currency_signed,

                    })
        combine_payment.write({'f_parent_id':multi_payment.id})
        multi_payment.f_post_payment()
        return result

