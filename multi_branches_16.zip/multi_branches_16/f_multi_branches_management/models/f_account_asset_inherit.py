
from odoo import models, fields, api

class f_account_asset(models.Model):
    _inherit = 'account.asset'
    
    def _get_default_branch(self):
         #print(self.new)

         user_default_branch = False
         if self.env.user.company_id.f_allow_multi_branches ==True :

             context = self._context
             current_uid = self.env.uid
             print('current_uid',current_uid)
             user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
             if user_default_branch:
                 comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id

                 if not self.f_related_branch :
                     if comp == self.env.user.company_id.id :
                         self.f_related_branch  = user_default_branch
                         #print('user_default_branch',user_default_branch)
                     else :
                         #print(self.env.user.company_id.id)
                         branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.user.company_id.id)],limit=1)
                         #print('branch',branch)
                         self.f_related_branch  = branch.id
                         user_default_branch = branch.id
             else :
                 user_default_branch = self.env['res.users'].browse(current_uid).f_allowed_branches[0]
         return user_default_branch
    
    
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, default=_get_default_branch, tracking=True)
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')
    
    
    #OVERRIDE this function to set the related branch in the asset related account.moves 
    def compute_depreciation_board(self,date=False):
         res = super().compute_depreciation_board()
         #print('res of compute_depreciation_board',res)
         for move in self.depreciation_move_ids: 
             move.write({'f_related_branch':self.f_related_branch})
    
    #OVERRIDE this function to set the related branch in the move created at sell/depose
    def _get_disposal_moves(self, invoice_line_ids, disposal_date):
        move_ids = super()._get_disposal_moves(invoice_line_ids, disposal_date)
        #print(move_ids,move_ids)
        
        moves = self.env['account.move'].search([('id', 'in', move_ids)])
        #print('moves',moves)
        for move in moves : 
            move.write({'f_related_branch':self.f_related_branch})
        
    @api.onchange('f_related_branch')
    def on_change_asset_branch(self):
        print('self.origin.id',self._origin.id)
        if self._origin.id :    
            asset_moves = self.env['account.move'].search([('asset_id','=',self._origin.id),('state','!=','posted')])  
            print('asset_moves',asset_moves)
            for move in asset_moves :
                move.write({'f_related_branch':self.f_related_branch})
                
            
        
            
