from odoo import tools
from odoo import api, fields, models,_


class FProductsalesReport(models.Model):
    _name = "f.sales.productreport"
    _description = "Product Sales Analysis Report"
    _auto = False


    product_id = fields.Many2one('product.product',string= 'Product', readonly=True)
    qty = fields.Float('Qty - Sold', readonly=True)
    qty_re = fields.Float('Qty - Returned', readonly=True)

    pos_qty = fields.Float('Qty - Sold/POS', readonly=True)
    pos_qty_re = fields.Float('Qty - Returned/POS', readonly=True)



    qty_recv = fields.Float('Qty - Recevied', readonly=True)
    f_season = fields.Char(string='Season')
    f_section = fields.Many2one('f.product.section', string='Section')
    f_article= fields.Char(string='Artical')
    f_brand = fields.Many2one('f.contact.brand',string='Brand')
    net_qty_f =  fields.Float('Net Sold Qty ', readonly=True)
    company_id = fields.Many2one('res.company', string='Company', readonly=True)


    def init(self):
        tools.drop_view_if_exists(self.env.cr, self._table)
        self.env.cr.execute("""CREATE or REPLACE VIEW  f_sales_productreport as 
  select max(a.id) as id from product_product a
    
        
        """ )
