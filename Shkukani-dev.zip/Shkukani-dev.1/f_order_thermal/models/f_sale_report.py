from odoo import models

class LoyaltyCard(models.Model):
    _inherit = 'sale.order'

    def print_thermal_sale_order(self):
        self.ensure_one()
        return self.env.ref('f_order_thermal.action_report_thermal_sale_order').report_action(self)