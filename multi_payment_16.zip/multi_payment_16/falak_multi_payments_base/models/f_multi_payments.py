from odoo import models, fields, api,_
from datetime import datetime
from odoo.exceptions import UserError
import math

class FMultiPayments(models.Model):
    _name = 'f.multi.payments' 
    _inherit = ['mail.thread','mail.activity.mixin']
    _description = "Multi Payments"
    _order = "f_payment_date desc"
    _check_company_auto = True
    _rec_name   = "f_multi_payment_seq"

    f_payment_channel = fields.Char('Payment Channel')
    f_payment_purpose = fields.Many2one('f.payment.purpose', string="Payment Purpose")
    f_legacy_group_id = fields.Char('Legacy Group Id')
    f_legacy_group_number = fields.Char('Legacy Group number')


    f_audited = fields.Boolean('Audited',copy=False,tracking=True, default = False )
    f_audited_by = fields.Many2one('res.users', 'Audited By' , copy=False,tracking=True)
    f_credit = fields.Monetary('AR Balance',related="f_partner_id.credit")     
    currency_id = fields.Many2one( related='company_id.currency_id',  string='Company currency')
    
    
    def unlink(self):
        for rec in self:
            if rec.f_multi_pay_state == 'draft':
                 for line in rec.f_payment_lines.filtered(lambda s: s.state == 'posted'):
                     raise UserError(_("Only you can delete draft payment, there are payments with posted stated!")) 
                     
                 for line in rec.f_payment_lines:
                    moves = self.with_context(force_delete=True).env['account.move'].search([('payment_id', '=', line.id)])
                    moves.unlink()
  

                 return super(FMultiPayments, self).unlink()
            else:
                raise UserError(_("Only you can delete draft payment"))
                

    
    
    
    def f_audit_payment(self):
        for pay in self : 
            pay.write ({'f_audited':True,'f_audited_by':self.env.user.id})
 
    
    
    def _get_default(self):
        if self.env.user.f_default_journal.id :
            return self.env.user.f_default_journal.id
        else:
            return self.env['account.journal'].search([('type','in',('bank','cash'))], limit=1)
    
    f_default_journal = fields.Many2one('account.journal', string='default Journal' , default = _get_default)
    
        
    f_multi_payment_seq = fields.Char(
       readonly=True,
       string = 'Payment Number',
        help="It indicates for Multi payment Sequence",copy = False
    )
    f_payment_type = fields.Selection([
        ('outbound', 'Send Money'),
        ('inbound', 'Receive Money'),
    ], string='Payment Type', tracking=True, required=True, readonly=True, ondelete={'inbound': 'set default','outbound': 'set default'})
    
    f_partner_type = fields.Selection([
        ('customer', 'Customer'),
        ('supplier', 'Vendor'),
    ],  tracking=True, required=True, string="Partner Type", readonly=True, ondelete={'customer': 'set default','supplier': 'set default'})
    
    f_partner_id = fields.Many2one(
        comodel_name='res.partner',required = True,
        string="Customer/Vendor",
        store=True, readonly=False, domain="['|', ('parent_id','=', False), ('is_company','=', True)]",
        tracking=True, check_company=True)

    @api.onchange('f_partner_id')
    def _f_onchange_partner_id_warning(self):
        if not self.f_partner_id:
            return

        if self.f_partner_id.f_multipay_warning:
            return {
                'warning': {
                    'title': _("Warning for %s", self.f_partner_id.name),
                    'message': self.f_partner_id.f_multipay_warning,
                }
            }





    
    
    f_partner_ref = fields.Char(
       related='f_partner_id.ref',
        copy = False
    )
    
    f_sales_person = fields.Many2one('res.users',related = 'f_partner_id.user_id',readonly=True,string='Old Field Sales Person',store = True)
    user_id = fields.Many2one('res.users', copy=False, tracking=True,compute='_set_user_id',  string='Salesperson',store = True,inverse="_inverse_user_id")

    @api.depends('f_partner_id')
    def _inverse_user_id(self):
        for rec in self :
            rec.user_id = rec.user_id.id
    @api.depends('f_partner_id')
    def _set_user_id(self):
        for rec in self :
            rec.user_id = rec.f_partner_id.user_id.id
    
    #pos f_partner_debit = fields.Monetary('Debt',related='f_partner_id.f_credit_with_paid',readonly=True,currency_field='company_currency_id')
    f_currency_id = fields.Many2one('res.currency', string='Currency', store=True, readonly=False,
        compute='_compute_currency_id',
        help="The payment's currency.")
    f_destination_account_id = fields.Many2one(
        comodel_name='account.account',
        string='Destination Account',
        store=True, readonly=False,
        compute='_compute_destination_account_id',
        domain="[('account_type', 'in', ('asset_receivable', 'liability_payable')), ('company_id', '=', company_id),('deprecated','=',False)]",
        check_company=True,copy = False)

    f_payment_date = fields.Date('Payment Date',default=fields.Date.context_today)
    
    f_multi_pay_state = fields.Selection([
        ('draft', 'Draft'),
        ('cancelled', 'Cancelled'),
        ('posted', 'Posted'),
    ], string='Payment State', default='draft', required=True,copy = False,ondelete={'posted': 'set default','draft': 'set default','cancelled': 'set default'})
    
    f_pay_reference = fields.Char('Payment Reference',copy = False)
    f_pay_notes = fields.Char('Notes',copy = False)
     
    def _default_compnay(self):
        self.company_id = self.env.company.id
        return self.env.company.id
    
    company_id     = fields.Many2one('res.company', string = 'Company' , default = _default_compnay)
    company_currency_id = fields.Many2one( related='company_id.currency_id',  string='Company currency')
    
    
    @api.depends( 'f_partner_id', 'f_partner_type')
    def _compute_destination_account_id(self):
        self.f_destination_account_id = False
        for pay in self:
            if pay.f_partner_type == 'customer':
                # Receive money from invoice or send money to refund it.
                if pay.f_partner_id:
                    pay.f_destination_account_id = pay.f_partner_id.with_company(pay.company_id).property_account_receivable_id
                else:
                    pay.f_destination_account_id = self.env['account.account'].search([
                        ('company_id', '=', pay.company_id.id),
                        ('account_type', '=', 'asset_receivable'),
                        ('deprecated', '=', False),
                    ], limit=1)
            elif pay.f_partner_type == 'supplier':
                # Send money to pay a bill or receive money to refund it.
                if pay.f_partner_id:
                    pay.f_destination_account_id = pay.f_partner_id.with_company(pay.company_id).property_account_payable_id
                else:
                    pay.f_destination_account_id = self.env['account.account'].search([
                        ('company_id', '=', pay.company_id.id),
                        ('account_type', '=', 'liability_payable'),
                        ('deprecated', '=', False),
                    ], limit=1)

    

    def f_draft_payment(self):
        for pay in self :
            for payment in pay.f_payment_lines :
                payment.action_draft ()
            pay.write ({'f_multi_pay_state':'draft'})
            
    def f_cancel_payment(self):
        print('In Cancelllllllllllllllllllllllllll')
        for pay in self :
            for payment in pay.f_payment_lines : 
                payment.action_cancel ()
            pay.write ({'f_multi_pay_state':'cancelled'})
            

    def f_post_payment(self):
        for pay in self :    
            print('f_post_paymentttttttttttttttttttt')
            if pay.f_multi_pay_state == 'draft':
                for line in pay.f_payment_lines.filtered(lambda s: s.state == 'draft'):
                    line.date = pay.f_payment_date
                    line.partner_id = pay.f_partner_id.id
                    #line.write({'date':pay.f_payment_date})
                    print('Multi Payment Post ',pay)
                    line.action_post()
                print('pay',pay)
                

                pay.write ({'f_multi_pay_state':'posted'})
                print('5555555')

    def get_payment_seq(self,payment_date):
        if payment_date:
            if type(payment_date) == str:
                payment_date = datetime.strptime(payment_date, '%Y-%m-%d')
            year = payment_date.year
            month = '{:02d}'.format(payment_date.month)
        else:
            year = datetime.today().year
            month = '{:02d}'.format(datetime.today().month)
            # print(month)
        seq_no = self.env['ir.sequence'].next_by_code('Multi Pay Sequence')
        seq_number    = str(year) + '/' + str(month) + '/' + str(seq_no)
        return seq_number

    ## To create new sequence number               
    @api.model
    def create(self, vals):
          print('In create vals',vals)
          vals['f_multi_payment_seq'] = self.get_payment_seq(vals['f_payment_date'])
          obj = super(FMultiPayments, self).create(vals)

          for pay in self :
              for line in pay.f_payment_lines:
                line.destination_account_id = pay.f_destination_account_id.id
                line.date = pay.f_payment_date
                line.partner_id = pay.f_partner_id.id
                line.invoice_user_id = pay.user_id.id
                line.user_id = pay.user_id.id
                line.f_payment_purpose = pay.f_payment_purpose

          return obj
    
    # Multi Payment Lines 
    f_payment_lines = fields.One2many('account.payment','f_parent_id', 'Payment Lines' ,copy=False)
    f_payment_lines_v = fields.One2many('account.payment','f_parent_id', 'Payment Lines' ,copy=False)

    f_payment_total = fields.Monetary(
        string='Total',
        currency_field='company_currency_id',copy=False
    )

    
    f_payment_total_per_currency_list = fields.Text(
        string='Total / Currency',
        compute='_compute_total_amount_per_currency',
    )
    
    
    def f_format_value(self,value, decimals=2, width=0, decimals_separator='.', thousands_separator=',', autoint=False, symbol='', position='after'):
            decimals = max(0,int(decimals))
            width    = max(0,int(width))
            value    = float(value)

            if autoint and math.floor(value) == value:
                decimals = 0
            if width == 0:
                width = ''

            if thousands_separator:
                formatstr = "{:"+str(width)+",."+str(decimals)+"f}"
            else:
                formatstr = "{:"+str(width)+"."+str(decimals)+"f}"


            ret = formatstr.format(value)
            ret = ret.replace(',','COMMA')
            ret = ret.replace('.','DOT')
            ret = ret.replace('COMMA',thousands_separator)
            ret = ret.replace('DOT',decimals_separator)

#             if symbol:
#                 if position == 'after':
#                     ret = ret + symbol
#                 else:
#                     ret = symbol + ret
            return ret
        
        
    
    def _compute_total_amount_per_currency(self):
        pay_groups = {}
        for yy in self.f_payment_lines.filtered(lambda s:s.state != 'cancel'):
            shipdic_name = yy.currency_id.id
            if not pay_groups.get(shipdic_name):
                                pay_groups[shipdic_name] = {}
                                pay_groups[shipdic_name].update({
                                    'journal': yy.currency_id.name,
                                    'currency': yy.currency_id.symbol,
                                    'amount': yy.amount,
                                })
            else:
                pay_groups[shipdic_name].update({
                                    'amount': pay_groups[shipdic_name].get('amount') + yy.amount,
                                })
        pay_list = list()        
        for k,v in pay_groups.items():
            pay_list.append('''%s : %s %s'''% (pay_groups[k]['journal'], self.f_format_value(pay_groups[k]['amount']), pay_groups[k]['currency']))
        self.f_payment_total_per_currency_list = '\n'.join(pay_list).strip(' + ')
    
    #f_to_pay_invoices = fields.Many2many('account.move','account_move_multi_payment_rel','f_invoice_id', 'f_multi_payment_id','To Pay Invoices' )
    
   

    
    def write(self, vals):
          obj = super(FMultiPayments, self).write(vals)
          for pay in self :
              if 'f_payment_purpose' in vals or 'f_destination_account_id' in vals or 'f_payment_date' in vals or 'f_partner_id' in vals or'user_id' in vals :
                  for line in pay.f_payment_lines:
                    print('In Multi Payment Write vals = ',vals)
                    line.destination_account_id = pay.f_destination_account_id.id
                    line.date = pay.f_payment_date
                    line.partner_id = pay.f_partner_id.id
                    line.invoice_user_id = pay.user_id.id
                    line.user_id = pay.user_id.id
                    line.f_payment_purpose = pay.f_payment_purpose

              if 'f_payment_date' in vals :
                    self.f_multi_payment_seq = self.get_payment_seq(vals['f_payment_date'])

          return obj
                        
                        

    # To Print Payment Receipt 
    def payment_print(self):
        datas = {'ids': self._ids,
                 'form': self.read()[0],
                 'model': 'f.multi.payments'}
        #print('44444444444444444444',datas)
        return self.env.ref('falak_multi_payments_base.action_report_payment_receipt').report_action(self, data=datas)

