from odoo import models, fields, api, _
from datetime import datetime
from odoo.exceptions import UserError


## Create new model called f.internal.request.header
class FInternalRequestHeader(models.Model):
    _name = 'f.internal.request.header'
    _description = 'Internal Transfer Request'
    _rec_name = 'f_seq_id'

    def _get_user_def_location(self):
        locations = self.env['stock.location'].search([('f_allowed_users', 'in', self.env.user.id)], limit=1).id
        print(locations, self.env.user.id)
        return locations

    ## Set From location field as the one which is in res.config.settings by default
    def _get_from_location(self):
        main_location = self.env['ir.config_parameter'].sudo().get_param(
            'falak_internal_transfer_request.f_main_location')
        picking_shipment = self.env['stock.picking.type'].search([('default_location_src_id.id', '=', main_location)])
        return picking_shipment.default_location_src_id

    company_id = fields.Many2one('res.company', string='Company', required=True, readonly=True,
                                 default=lambda self: self.env.company)
    f_to_location = fields.Many2one('stock.location', string="To Location", default=_get_user_def_location)
    f_from_location = fields.Many2one('stock.location', domain="[('usage', '=', 'internal')]",
                                      default=_get_from_location, string="From Location")
    f_seq_id = fields.Char(string="Sequence Number")
    f_date = fields.Datetime(string="Transfer Date", required=True, index=True, default=fields.Datetime.now,
                             readonly=True)
    f_state = fields.Selection(string='Status', selection=[
        ('draft', 'Draft'),
        ('prepare', 'Preparing'),
        ('ready', 'Ready'),
        ('cancel', 'Cancelled'),
        ('done', 'Validated')],
                               copy=False, index=True, readonly=True,
                               default='draft')
    f_request_line = fields.One2many('f.internal.request.line', 'f_request_id', string='Request Lines', copy=True,
                                     auto_join=True)
    f_from_date = fields.Datetime(string="From Date")
    f_to_date = fields.Datetime(string="To Date")
    f_option = fields.Selection(string="Option",
                                selection=[('sale', 'Based on Sales'), ('rule', 'Based on Re-order Rules'),
                                           ('manual', 'Manual')], default='sale')

    ## Prepare the transfer request with products by depending on min and max qty of each product
    def f_prepare_request(self):
        #if self.f_option in 'rule':

        request_qty = 0
        on_hand_qty = 0
        for record in self:
            reorder_products = self.env['stock.warehouse.orderpoint'].sudo().search(
                [('location_id', '=', self.f_to_location.id), ('product_min_qty', '!=', 0),
                 ('product_max_qty', '!=', 0)])

            for product in reorder_products:
                min_qty = product.product_min_qty
                max_qty = product.product_max_qty

                available_qty = self.env['stock.quant'].sudo().search(
                    [('location_id', '=', self.f_to_location.id), ('product_id', '=', product.product_id.id)],
                    limit=1).quantity
                if (available_qty < min_qty):
                    request_qty = max_qty - available_qty
                    if request_qty > 0:
                        on_hand_qty = 0.0
                        prod_qty = self.env['stock.quant'].sudo().read_group(
                            [('location_id', 'child_of', self.f_from_location.id),
                             ('product_id', '=', product.product_id.id)],
                            fields=['product_id', 'quantity'], groupby=['product_id'])
                        if prod_qty:
                            on_hand_qty = prod_qty[0]['quantity']
                        else:
                            on_hand_qty = 0
                        vals = {
                            'product_id': product.product_id.id,
                            'f_demand_quantity': request_qty,
                            'f_final_quantity': request_qty,
                            'f_on_hand_qty': on_hand_qty,
                            'f_request_id': self.id,
                        }
                        self.env['f.internal.request.line'].sudo().create(vals)
        self.f_state = 'prepare'
        return request_qty

    ## Prepare the internal transfer request manually
    def f_prepare_request_manual(self):
        self.f_state = 'prepare'

    ## Cancel the transfer request
    def f_cancel_request(self):
        self.f_state = 'cancel'

    ## Transfer request is ready
    def f_ready_request(self):
        self.f_state = 'ready'

    ## Process the request to create the shipment and receipt record
    def f_process_request(self):
        shipment_operation_type = self.env['ir.config_parameter'].sudo().get_param(
            'falak_internal_transfer_request.f_operation_type')
        shipment = self.env['stock.picking.type'].sudo().search([('id', '=', shipment_operation_type)])
        print(shipment_operation_type, 'pppp', shipment.default_location_dest_id)
        request_lines_vals = []
        for request_line in self.f_request_line:
            request_lines_vals.append((0, 0, {'product_id': request_line.product_id.id,
                                              'location_id': self.f_from_location.id,
                                              'location_dest_id': shipment.default_location_dest_id.id,
                                              'f_prod_note': request_line.f_note,
                                              'product_uom_qty': request_line.f_final_quantity,
                                              'name': request_line.product_id.name,
                                              'product_uom': request_line.product_id.uom_id, }))

        shipment_obj = self.env['stock.picking'].sudo().create({'picking_type_id': shipment.id,
                                                                'location_id': self.f_from_location.id,
                                                                'location_dest_id': shipment.default_location_dest_id.id,
                                                                'f_to_loc': self.f_to_location,
                                                                'f_internal_transfer_id': self.id,
                                                                'move_ids_without_package': request_lines_vals,

                                                                })
        self.f_state = 'done'
        return shipment_obj

    ## Create new record and sequence number
    @api.model
    def create(self, vals_list):
        vals_list['f_seq_id'] = self.env['ir.sequence'].next_by_code('f.itr.seq.num')
        return super(FInternalRequestHeader, self).create(vals_list)

    def write(self, vals_list):
        return super(FInternalRequestHeader, self).write(vals_list)

    ## Display the Internal Transfer Requests that belongs to the current record
    def preview_internal_requests(self):
        #self.ensure_one()
        return {
            'name': _('Transfer Requests'),
            'view_type': 'form',
            'view_mode': 'tree,form',
            'res_model': 'stock.picking',
            'domain': [('f_internal_transfer_id', '=', self.id)],
            'type': 'ir.actions.act_window',
            'target': 'current',
        }
