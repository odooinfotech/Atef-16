# -*- coding: utf-8 -*-
{
    'name': "f_ex_pos_stat_multipay",

    'summary': """
        ex multipay for pos statement """,

    'description': """
  
    """,

    'author': "falak-solutions",
    'license': 'LGPL-3',

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/16.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '0.1',

    # any module necessary for this one to work correctly
    'depends': ['f_partner_statemment_payment_ext','f_pos_detailed_statement_extend'],

    # always loaded
    'data': [
        # 'security/ir.model.access.csv',
       # 'views/views.xml',
      #  'views/templates.xml',
    ],
    # only loaded in demonstration mode

}
