# -*- coding: utf-8 -*-

from odoo import models, fields, api, _, tools


class FProductprofit(models.TransientModel):
    _name = 'f.sales.productreport.wiz'
    _description = "Product Sales Analysis  Wizard "



    from_date = fields.Date(string='From',requierd=True)
    to_date = fields.Date(string='To',requierd=True)
    f_season = fields.Char(string='Season')
    f_section = fields.Many2one('f.product.section', string='Section')
    f_location = fields.Many2one('stock.location', string='Location',domain=[('usage','=','internal')])

    def _where_prod(self):
        whr = ''
        if self.f_season :
            whr =  whr + "and pt.f_season ilike '%s'"%(self.f_season)

        if self.f_section :
            whr =  whr + "and pt.f_section = %s"%(self.f_section.id)
        return whr

    def _query(self):
        return """
  select prod.product_id as id ,
        prod.product_id as product_id ,
        prod.f_section as f_section,
        prod.f_season as f_season ,
        prod.f_article as f_article ,
        prod.f_brand as f_brand ,
    	 COALESCE(so_info.so_qty,0) + COALESCE( pos_info.pos_qty,0) as qty ,
       COALESCE(so_returninfo.so_returned_qty,0) +  COALESCE(pos_return_info.pos_return_qty,0) as qty_re ,
       
      COALESCE( pos_info.pos_qty,0) as pos_qty ,
      COALESCE(pos_return_info.pos_return_qty,0) as pos_qty_re ,
       
       
       
      (  COALESCE(so_info.so_qty,0) + COALESCE( pos_info.pos_qty,0)   ) -     COALESCE(so_returninfo.so_returned_qty,0) +  COALESCE(pos_return_info.pos_return_qty,0)  as net_qty_f,
        COALESCE(receving_info.receving_qty,0 ) as qty_recv ,
        %s as company_id 
   
        from 
        
    (   Select pp.id as product_id , pt.name as product_name, pp.barcode as barcode ,pt.f_season as f_season,pt.f_section as f_section,pt.f_article as f_article , pt.f_brand_id  as f_brand  
         from product_product pp ,product_template pt 
         where pp.product_tmpl_id = pt.id and pt.type = 'product' %s
         ) prod
         
         
         left join 
        ( select l.product_id as product_id , sum(COALESCE((l.product_uom_qty / u.factor * u2.factor),0)) as so_qty
     
         from sale_order_line l
            LEFT JOIN sale_order s ON s.id=l.order_id
            LEFT JOIN product_product p ON l.product_id=p.id
            LEFT JOIN product_template t ON p.product_tmpl_id=t.id
            LEFT JOIN uom_uom u ON u.id=l.product_uom
            LEFT JOIN uom_uom u2 ON u2.id=t.uom_id
             where l.product_uom_qty > 0 
		 and s.company_id = %s
	 and date(s.date_order) >= date('%s')
		 	 and date(s.date_order) <= date('%s')
		 
            group by l.product_id ) so_info on (so_info.product_id = prod.product_id)
            
            
            
             left join 
        ( select l.product_id as product_id , sum(COALESCE((l.product_uom_qty / u.factor * u2.factor),0) )as so_returned_qty

         from sale_order_line l
            LEFT JOIN sale_order s ON s.id=l.order_id
            LEFT JOIN product_product p ON l.product_id=p.id
            LEFT JOIN product_template t ON p.product_tmpl_id=t.id
            LEFT JOIN uom_uom u ON u.id=l.product_uom
            LEFT JOIN uom_uom u2 ON u2.id=t.uom_id
                     where l.product_uom_qty < 0 
		  and s.company_id = %s
	 and date(s.date_order) >= date('%s')
		 	 and date(s.date_order) <= date('%s')
            group by l.product_id ) so_returninfo on (so_returninfo.product_id = prod.product_id)
            
            
             left join 
        ( select l.product_id as product_id , sum(COALESCE(l.qty,0) ) as pos_qty
     
         from pos_order_line l
            LEFT JOIN pos_order s ON s.id=l.order_id
             LEFT JOIN pos_session  ps ON ps.id=s.session_id
               LEFT JOIN pos_config  pc ON pc.id=ps.config_id
                LEFT JOIN stock_picking_type  pty ON pty.id=pc.picking_type_id
            
            LEFT JOIN product_product p ON l.product_id=p.id
            LEFT JOIN product_template t ON p.product_tmpl_id=t.id
     
                where l.qty > 0 
		  and s.company_id = %s

			 and date(s.date_order) >= date('%s')
		 	 and date(s.date_order) <= date('%s')
		 	 		  and pty.default_location_src_id = %s 
		 
            group by l.product_id ) pos_info on (pos_info.product_id = prod.product_id)
            
            
               left join 
        ( select l.product_id as product_id , COALESCE(sum(l.qty) ,0) as pos_return_qty
       
         from pos_order_line l
            LEFT JOIN pos_order s ON s.id=l.order_id
                         LEFT JOIN pos_session  ps ON ps.id=s.session_id
               LEFT JOIN pos_config  pc ON pc.id=ps.config_id
                LEFT JOIN stock_picking_type  pty ON pty.id=pc.picking_type_id
            LEFT JOIN product_product p ON l.product_id=p.id
            LEFT JOIN product_template t ON p.product_tmpl_id=t.id
     
              where l.qty < 0 
		  and s.company_id = %s
		    
		  	 and date(s.date_order) >= date('%s')
		 	 and date(s.date_order) <= date('%s')
		 	 and pty.default_location_dest_id = %s 
            group by l.product_id ) pos_return_info on (pos_return_info.product_id = prod.product_id)
            
            
              left join 
        ( select sq.product_id as product_id , 
        
        sum(COALESCE(sq.qty_done,0))  as receving_qty

         
          from   stock_move_line sq
			
		left join stock_move sm on (sm.id = sq.move_id)
         left join stock_location sl on (sq.location_id = sl.id)
          left join stock_location sd on (sq.location_dest_id = sd.id)
         
         where sq.state = 'done'
         and sl.usage='supplier'  and sd.usage ='internal'
		  and sm.company_id = %s
		  	 and date(sm.date) >= date('%s')
		 	 and date(sm.date )<= date('%s')
	 		and sd.id = %s 
         

            group by sq.product_id ) receving_info on (receving_info.product_id = prod.product_id)
            
            
            
        """%(self.env.company.id,
             self._where_prod(),
             self.env.company.id,self.from_date,self.to_date,
             self.env.company.id,self.from_date,self.to_date,
             self.env.company.id,self.from_date,self.to_date,self.f_location.id,
            self.env.company.id,self.from_date,self.to_date,self.f_location.id,
             self.env.company.id,self.from_date,self.to_date,self.f_location.id,)

    def get_product_details(self):

        tools.drop_view_if_exists(self.env.cr, 'f_sales_productreport')
        self.env.cr.execute("""CREATE or REPLACE VIEW f_sales_productreport as (%s)""" % (self._query()))

        tree_id = self.env.ref('f_product_sale_details_report.view_report_fproductsol_tree').id
        form_id = False
        action = {
            'name': _('Product Sales Analysis Report'),
            'type': 'ir.actions.act_window',
            'view_mode': 'tree',
            'res_model': 'f.sales.productreport',
        }

        return action
