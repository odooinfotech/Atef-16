from odoo import models, fields, api, _
from datetime import datetime, timedelta,date
from odoo.exceptions import UserError, ValidationError


class FAccountJournal(models.Model):
    _inherit = 'account.journal'
    
    # New Fields in  Journal Def for Checks  
    check_details = fields.Boolean(string='Show Check Details',help="this flag will determine if this Journal is a check or not and based on that all the fields and flows will follow")
    allow_deposit = fields.Boolean(string='Allow Check Deposit' , help= "This flag is meaning that this bank journal allows to be used for deposit and collect")
    deposite_account = fields.Many2one('account.account', string='Check Deposit Account',
        domain=[('deprecated', '=', False)], help="this flag will determine if this Journal is a check or not and based on that all the fields and flows will follow")
    outward_checks_account = fields.Many2one('account.account', string='Outward Checks Account',  domain=[('deprecated', '=', False)])
    f_without_statement = fields.Boolean(string='Without Statement' , help= "This flag indicates if this ledger will be handled through statement or not " ,default = False) 

    #check_transfer
    allow_transfer = fields.Boolean(string='Allow Check Transfer' , help= "This flag means that this journal is a checks Box for the Company", default = False)



    f_bounced_fees_account = fields.Many2one('account.account','Account')


    

