from odoo import models, fields, api, _


class FProductTemplateInherit(models.Model):
    _inherit = 'product.template'

    # New Fields
    f_article = fields.Char(string='Article')
    f_season = fields.Char(string='Season')
    f_section = fields.Many2one('f.product.section', string='Section')
    #f_taric = fields.Char(string='Taric')
    f_group = fields.Many2one('f.product.group', string='Group')
    f_article_category = fields.Many2one('f.article.category', string='Article Category')
    f_brand_id = fields.Many2one('f.contact.brand', string='Brand Name')
    f_hs_code = fields.Char(string='HS Code')
    #f_textile_composition = fields.Char(string='Textile Composition')
    f_sim = fields.Char(string='Sim')
    f_brand = fields.Char(string='Brand')
    f_gander = fields.Char(string='Gander')
    f_safety_warning = fields.Char(string='Safety Warning')
