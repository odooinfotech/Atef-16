from odoo import api, fields, models, _


## Create new model called (f.order.wizard) with five fields.
class RequestDetails(models.Model):
    _name = 'f.order.wizard'
    _description = 'Request Details'

    start_date = fields.Datetime(required=True, default=fields.Datetime.now)
    end_date = fields.Datetime(required=True, default=fields.Datetime.now)

    f_to_location = fields.Many2one('stock.location',string="Location", domain="[('usage', '=', 'internal')]")
    f_from_location = fields.Many2one('stock.location', domain="[('usage', '=', 'internal')]")
    f_seq_id = fields.Char(string="Sequence Number")
    
               
                   
## Prepare the internal transfer request by depending on soled qty of each product    
    def f_prepare_by_sales(self):
        #if self.f_option in 'sale':
            sold_products = self.env['stock.move.line'].sudo().read_group([('date','<=',self.end_date),('date','>=',self.start_date),('state', '=', 'done'),
                                                               ('location_id', '=', self.f_to_location.id),('location_dest_id.usage', '=', 'customer')], 
                                                            fields=['product_id', 'qty_done'], groupby=['product_id'])
            print('sold_products', sold_products)
            for product in sold_products:
                on_hand_qty=0.0
                prod_qty = self.env['stock.quant'].sudo().read_group([('location_id', 'child_of', self.f_from_location.id),('product_id', '=', product['product_id'][0])], 
                                                            fields=['product_id', 'quantity'], groupby=['product_id'])
                if prod_qty: 
                    on_hand_qty =prod_qty[0]['quantity']
                else :
                    on_hand_qty = 0    
                vals = {    
                            'product_id': product['product_id'][0],
                            'f_demand_quantity' : product['qty_done'],
                            'f_on_hand_qty' : on_hand_qty,
                            'f_final_quantity' : product['qty_done'],
                            'f_request_id':self['f_seq_id'],
                        
                        }            
                #print('vals',vals)
                res= self.env['f.internal.request.line'].sudo().create(vals)
                #print('99999999999999999999999999999',res)

            
            obj = self.env['f.internal.request.header'].sudo().search([('id', '=', self.f_seq_id)])
            obj.write({'f_state': 'prepare',
                        'f_from_date':self.start_date,
                        'f_to_date':self.end_date})              
                                         
                       
