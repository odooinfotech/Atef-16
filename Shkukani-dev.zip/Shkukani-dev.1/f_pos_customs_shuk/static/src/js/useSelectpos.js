odoo.define('f_pos_customs_shuk.useSelectpos', function (require) {
    'use strict';
    const { Component } = owl;
    const { _t } = require('web.core');
    const { Gui } = require('point_of_sale.Gui');
    const useSelectpos = (PosComponent) => class ComponentWithSelectCashierMixin extends PosComponent {





        async selectCashier() {



        const list = this.env.pos.configs_list

                    .map((employee) => {
                        return {
                            id: employee.id,
                            item: employee,
                            label: employee.name,
                            isSelected: false,
                        };
                    });
        	var manager_list = []
        	for(var x in list){
        		manager_list.push(list[x]);



        	}
        	let xx = true;
        	let {confirmed, payload: employee} = await this.showPopup('SelectionPopup', {
                    title: this.env._t('Change POS Shop'),
                    list: manager_list,
                });



                if (!confirmed) {
                    return;
                }

                if (employee) {

                        console.log('employee',employee)
                        this.env.pos.get_order().f_ass_set_pos(employee);
                         this.trigger('close-temp-screen');



                }

                    return employee;




        }


    }

    return useSelectpos;
});
