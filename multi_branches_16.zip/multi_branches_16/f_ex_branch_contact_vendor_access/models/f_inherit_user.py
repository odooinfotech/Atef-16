from odoo import models, fields, api

class f_res_users(models.Model):
    _inherit = 'res.users'

    f_mix_contatc_access = fields.Boolean('Mix Contact Access',default=False)


