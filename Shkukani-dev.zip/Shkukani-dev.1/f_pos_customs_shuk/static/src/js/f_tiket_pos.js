
odoo.define('f_pos_customs_shuk.f_tiket_pos', function (require) {
    'use strict';

    const PosComponent = require('point_of_sale.PosComponent');
    const TicketScreen = require('point_of_sale.TicketScreen');
    const Registries = require('point_of_sale.Registries');
    const { useAutofocus } = require("@web/core/utils/hooks");
    const { parse } = require('web.field_utils');

    const { useState } = owl;

    const PosResaccessTicketScreen = (TicketScreen) =>
        class extends TicketScreen {




     _getFilterOptions() {
            const orderStates = this._getOrderStates();
               if ( this.env.pos.get_cashier().f_hide_paid_orders) {
                     orderStates.set('SYNCED', { text: this.env._t('Paid') });
            }


                 return orderStates;

        }






             };

    Registries.Component.extend(TicketScreen, PosResaccessTicketScreen);

            });