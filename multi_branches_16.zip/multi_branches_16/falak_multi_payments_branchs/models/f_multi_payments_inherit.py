from odoo import models, fields, api
from datetime import datetime


class FMultiPaymentsInherit(models.Model):
    _inherit = 'f.multi.payments' 
    
    def _get_default_branch(self):
         user_default_branch = False
         if self.env.company.f_allow_multi_branches ==True :

             if self.env.company.f_allow_multi_branches ==True :

                 print(self.new)   
                 context = self._context
                 current_uid =context.get('uid') or self.env.user.id
                 print('current_uid',current_uid)
                 user_default_branch = self.env['res.users'].browse(current_uid).f_default_branch
                 if user_default_branch :
                     comp = self.env['f.comp.branches'].search([('id','=',user_default_branch.id)]).company_id.id

                     if not self.f_related_branch :
                         if comp == self.env.company.id :
                             self.f_related_branch  = user_default_branch
                             print('user_default_branch',user_default_branch)
                         else :
                             print(self.env.user.company_id.id)
                             branch = self.env['f.comp.branches'].search([('company_id.id','=',self.env.company.id)],limit=1)
                             print('branch',branch)
                             self.f_related_branch  = branch.id
                             user_default_branch = branch.id
                 else :
                     user_default_branch = self.env['res.users'].browse(current_uid).f_allowed_branches[0]

         return user_default_branch
    
    
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True, default=_get_default_branch)
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')

    @api.model
    def create(self, vals):
        print('In create vals', vals)
        obj = super(FMultiPaymentsInherit, self).create(vals)
        if self.env.company.f_default_partner_branch:
            if obj.f_partner_id.f_related_branch:
                obj.update({
                    'f_related_branch': obj.f_partner_id.f_related_branch.id or False
                })
            else:
                obj.update({
                    'f_related_branch': self.env.user.f_default_branch.id or False
                })


        for pay in self:
            for line in pay.f_payment_lines:
                line.f_related_branch = pay.f_related_branch.id
        return obj

    def write(self, vals):
          obj = super(FMultiPaymentsInherit, self).write(vals)
          for pay in self :




              if self.env.company.f_default_partner_branch:
                  if 'f_partner_id' in vals:
                      partner = self.sudo().env['res.partner'].sudo().search([('id', '=', vals['f_partner_id'])], limit=1)
                      if partner.f_related_branch:
                          vals['f_related_branch'] = partner.f_related_branch.id

                      else:
                          vals['f_related_branch'] = self.env.user.f_default_branch.id

              if 'f_related_branch' in vals:
                  for line in pay.f_payment_lines:
                      line.f_related_branch = pay.f_related_branch.id









          return obj
