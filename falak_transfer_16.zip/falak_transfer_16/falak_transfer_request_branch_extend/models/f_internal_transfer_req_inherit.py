
from odoo import SUPERUSER_ID, _, api, fields, models,tools


class FITRHeaderInherit(models.Model):
    _inherit = 'f.internal.request.header'
    
    def f_process_request(self):
        res = super(FITRHeaderInherit, self).f_process_request()
        res.write({'f_related_branch':res.location_id.f_related_branch.id})


