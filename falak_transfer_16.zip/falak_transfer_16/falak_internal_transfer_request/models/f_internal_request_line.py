from odoo import models, fields, api,_
from odoo.exceptions import UserError

## Create new model called f.internal.request.line with four fields 
class FInternalRequestLine(models.Model):
      _name = 'f.internal.request.line'
      _description = 'Internal Transfer Request Line'
      
      
      product_id = fields.Many2one('product.product',string="Product")
      f_demand_quantity = fields.Integer(string="Demand Quantity")
      f_final_quantity = fields.Integer(string="Final Quantity")
      f_request_id = fields.Many2one('f.internal.request.header', string='Request Id')
      f_request_state = fields.Selection(related = 'f_request_id.f_state', readonly=True, string = "Request state")
      f_on_hand_qty = fields.Integer(string="On Hand Quantity")
      f_note = fields.Text(string="Note")
     
      _sql_constraints = [
       ('f_product_unique', 'unique (product_id,f_request_id)', 'The product already Exists!')
     ]

      
## Make the default value of final quantity equal to the value of demand quantity      
      @api.onchange('f_demand_quantity')
      def _onchange_demand_quantity(self):
        if self.f_demand_quantity:
            self.f_final_quantity = self.f_demand_quantity
            
            
## Compute the on hand quantity of this product and if the product is already exists in lines, prevent user from editing it             
      @api.onchange('product_id')
      def _onchange_product(self):
          if self._origin.product_id.id:
             raise UserError(_('Sorry! Not allowed to edit product'))
         
          on_hand_qty=0
          prod_qty = self.env['stock.quant'].read_group([('location_id', 'child_of', self.f_request_id.f_from_location.id),('product_id', '=', self.product_id.id)], 
                                                            fields=['product_id', 'quantity'], groupby=['product_id'])
          if prod_qty:
              on_hand_qty =prod_qty[0]['quantity']
          else :
              on_hand_qty = 0    
          self.f_on_hand_qty = on_hand_qty
          
                
                
      
      
                  
          
              
          
