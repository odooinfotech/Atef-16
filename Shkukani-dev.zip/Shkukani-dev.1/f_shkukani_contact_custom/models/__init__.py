# -*- coding: utf-8 -*-

from . import f_contact_brand
from . import f_res_partner_inherit
from . import f_res_company_inherit
from . import f_res_users_inherit