from odoo import models, tools, api, fields
from email.policy import default


class PosDebtReport(models.Model):

    _name = "f.real.icttransfer"
    _description = "Real Internal Transfer"
    _auto = False
   
    
    
    product_id = fields.Many2one('product.product', string='Product', readonly=True)
    qty_ship = fields.Float(string='Shipment Qty',default=0, readonly=True)
    qty_done = fields.Float(string='Delivered Qty',default=0, readonly=True)
    #internal_transfer = fields.Many2one('f.stock.picking.transfer', string='Internal Company Transfer', readonly=True)
    pick_type_id = fields.Many2one('stock.picking.type', string='Picking Type', readonly=True)
    state= fields.Boolean('State')
    f_name_seq = fields.Char('Internal Seq.')
   # f_picking_satus = fields.Selection([('draft', 'Draft'),('waiting', 'Waiting Another Operation'),('confirmed', 'Waiting'),('assigned', 'Ready'), ('done', 'Done'), ('cancel', 'Cancelled')], string='Picking State')
    #
    
    


    
    
    #@api.model_cr
    def init(self):
        tools.drop_view_if_exists(self._cr, 'f_real_icttransfer')
        self._cr.execute("""
            CREATE OR REPLACE VIEW f_real_icttransfer AS (
            
            select max(sm.id) as id,sm.product_id as product_id ,sp.f_name_sequance as f_name_seq , max(st.code) as pick_type_id,
          
             sum(CASE WHEN (sp.f_source_transit = False and sp.f_dest_transit = True )  THEN (CASE WHEN(sl.qty_done is not null) then sl.qty_done ELSE 0 end) ELSE 0 END) qty_ship,
             sum(CASE WHEN (sp.f_source_transit = True and sp.f_dest_transit = False )  THEN (CASE WHEN(sl.qty_done is not null) then sl.qty_done ELSE 0 end) ELSE 0 END) qty_done,
(case when ((sum(CASE WHEN (sp.f_source_transit = False and sp.f_dest_transit = True )  THEN (CASE WHEN(sl.qty_done is not null) then sl.qty_done ELSE 0 end) ELSE 0 END)) =   sum(CASE WHEN (sp.f_source_transit = True and sp.f_dest_transit = False )  THEN (CASE WHEN(sl.qty_done is not null) then sl.qty_done ELSE 0 end) ELSE 0 END))THEN True Else False end) state
            from stock_move sm
            left join  stock_picking sp on (sp.id = sm.picking_id)
            left join stock_picking_type st on (st.id = sm.picking_type_id)
            left join stock_move_line sl on (sl.move_id = sm.id)
            left join stock_location sok on (sl.location_dest_id  = sok.id)
            
            where sp.f_name_sequance != '' and sp.state ='done'
            and COALESCE(sok.scrap_location, FALSE) = FALSE
            group by sm.product_id,sp.f_name_sequance
            
             )
        """)
