from odoo import models, fields, api



class FMultiPaymentsInheritOR(models.Model):
    _inherit = 'f.multi.payments' 
    
    @api.onchange('f_partner_id')
    def _get_default_branch_partner(self):
        
         cust_default_branch = False
         if self.env.user.company_id.f_allow_multi_branches ==True : 
             
             cust_default_branch = self.env['res.partner'].search([('id','=',self.f_partner_id.id)]).f_related_branch.id
             if cust_default_branch:
                self.f_related_branch  = cust_default_branch