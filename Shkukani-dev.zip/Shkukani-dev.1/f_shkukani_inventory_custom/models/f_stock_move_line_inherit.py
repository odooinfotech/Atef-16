from odoo import models, fields

class StockMoveLineInherit(models.Model):
    _inherit = 'stock.move.line'  # Inherit the stock.move model

    # Define your new field
    f_barcode = fields.Char( related='product_id.barcode')
