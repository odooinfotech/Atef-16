from odoo import models, fields, api, _
from datetime import datetime, timedelta,date
from odoo.exceptions import UserError, ValidationError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT

class FAccountPaymentReg (models.TransientModel):
    #_name =  'account.payment.register'
    _inherit = 'account.payment.register'
  
    _description = "Register Payment"
    
    
    def _valid_field_parameter(self, field, name):
        return name == 'tracking' or super()._valid_field_parameter(field, name)
    
    # Cheque Payment Details Fields
    returned_check_invoice = fields.Many2one(
        'account.move','Returned Check Invoice' , readonly = True)
    check_details =  fields.Boolean('Check Payment' , related='journal_id.check_details', store=True)
    payment_method_code = fields.Char ('Payment Method',related='payment_method_line_id.payment_method_id.code' ,store=True)
    journal_type =  fields.Selection('Journal Type' , related='journal_id.type', store=True,readonly = True)
    
    bank_id      = fields.Many2one('res.bank', string="Bank" )
    
    
    #Check_transfer
    f_current_journal = fields.Many2one('account.journal', 'Current Journal', readonly = True)
    transfer_date = fields.Date(string="Transfer Date" , readonly = True)
    
    
    #hedaia
    branch_id      = fields.Many2one('f.bank.branch', string="Branch"  ,domain ="[('bank_id','=',bank_id)]")
    
    account_number = fields.Char('Account Number')
    due_date     = fields.Date(string='Due Date'  )
    check_number = fields.Char(string='Check Number',readonly = False)
    check_state = fields.Selection(
         selection=[
            ('draft', 'Draft'),
            ('in_check_box', 'In Check Box'),
            ('under_collection', 'under collection'),
            ('collected', 'Collected'),
            ('returned', 'Returned'),
            ('bounced', 'Bounced'),
            ('cancelled', 'Cancelled'),
            ('issued', 'Issued'),
            ('released', 'Released'),
            ('endorsed', 'Endorsed')],
        string='Check State',default='draft', readonly = True)
            
    check_comments = fields.Text(string='Comments')
    
    deposit_date = fields.Date(string="Deposit Date" , readonly = True)
    undeposit_date = fields.Date(string="Undeposit Date" , readonly = True)
    collection_date = fields.Date(string="Collection Date" , readonly = True)
    deposit_collect_bank = fields.Many2one('account.journal', 'Deposit/Collect/Release Bank Account', readonly = True)
    bounce_date     = fields.Date(string="Bounce Date" , readonly = True)
    return_date     = fields.Date(string="Return Date" , readonly = True)
    endorse_date     = fields.Date(string="Endorse Date" , readonly = True)
    unendorse_date     = fields.Date(string="Unendorse Date" , readonly = True)
    release_date   = fields.Date(string="Release Date" , readonly = True)
    source_payment     = fields.Many2one('account.payment', 'Source Payment')
    des_payment     = fields.Many2one('account.payment', 'Supplier Payment')
    state = fields.Selection([('draft', 'Draft'), ('posted', 'Posted'), ('sent', 'Sent'), ('reconciled', 'Reconciled'), ('cancelled', 'Cancelled')], readonly=True, default='draft', copy=False, string="Status")
    bounced_check_received = fields.Boolean('Bounced Check Received')
    bounced_check_returned_to_customer = fields.Boolean('Bounced Check Returned To Customer ')
    f_responsible_emp = fields.Many2one('hr.employee','Responsible Employee', default = lambda self: self.env.user.employee_ids.id )
    
    def _create_payment_vals_from_wizard(self,batch_result):
        
        payment_values = super(FAccountPaymentReg, self)._create_payment_vals_from_wizard(batch_result)
        payment_values['check_number'] = self.check_number
        payment_values['bank_id'] = self.bank_id.id
        payment_values['due_date'] = self.due_date
        payment_values['account_number'] =self.account_number
        payment_values['check_comments'] =self.check_comments
        payment_values['branch_id'] =self.branch_id.id
        return payment_values
        




