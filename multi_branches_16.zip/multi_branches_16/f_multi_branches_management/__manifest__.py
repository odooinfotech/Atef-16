# -*- coding: utf-8 -*-
{
    'name': "Multi Branches Management",

    'summary': """
        Multi Branches Management 
        """,

    'description': """
        This Module Manages  the concept of Multi Branches in Odoo 15
    """,

    'author': "Falak Solutions",
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/14.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['base','mail','stock','sale','web','sale_stock','account_asset','sale_management','purchase','sale_purchase'],

    # always loaded
    'data': [
        'security/ir.model.access.csv',
        'security/f_record_rules.xml',
        'views/f_menues_view.xml',
        'views/f_res_company_views_inherit.xml',
        'views/f_res_users_views_inherit.xml',
        'views/f_branches_def_views.xml',
        'views/f_warehouses_locations_inherit.xml',
        'views/f_account_move_view_inherit.xml',
        'views/f_sale_order_view_inherit.xml',
        'views/f_account_payment_view_inherit.xml',
        'views/f_stock_picking_view_inherit.xml',
        'views/f_purchase_order_view_inherit.xml',
        'views/f_stock_move_view_inherit.xml',
        'views/f_account_asset_view_inherit.xml',
        'views/f_res_partner_view_inherit.xml',
    ],

    
}
