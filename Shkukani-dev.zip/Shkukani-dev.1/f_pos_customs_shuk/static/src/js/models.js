odoo.define('f_pos_customs_shuk.models', function (require) {
    "use strict";
    const ProductScreen = require('point_of_sale.ProductScreen');
    const Registries = require('point_of_sale.Registries');
    const { _t } = require('web.core');
    const { Gui } = require('point_of_sale.Gui');

    var { PosGlobalState, Order,Orderline } = require('point_of_sale.models');

        const PostagsPosGlobalState = (PosGlobalState) => class PostagsPosGlobalState extends PosGlobalState {
        async _processData(loadedData) {
            await super._processData(...arguments);
                let pos_configs_f = await this.env.services.rpc({
            model: 'pos.session',
            method: 'f_get_all_pos_config',
                args: [[]],
        }, {
            timeout: 3000,
            shadow: true,
        })

        this.configs_list = pos_configs_f;





        }
        }


    Registries.Model.extend(PosGlobalState, PostagsPosGlobalState);

    const ProductRefOrderline = (Orderline) => class ProductRefOrderline extends Orderline {
	    constructor() {
	        super(...arguments);

	    }

	    export_for_printing() {
	        const json = super.export_for_printing(...arguments);
	        json.product_price_main = this.get_product().lst_price;

	        return json;
	    }









	}
	Registries.Model.extend(Orderline, ProductRefOrderline);

    



    const PosempOrder = (Order) => class PosempOrder extends Order {
    constructor(obj, options) {
        super(...arguments);
            this.f_employee_assisted = this.f_ass_get_cashier();
            this.f_pos_config = this.f_ass_getpos_config();

    }

	updatePricelist(newPartner) {
            super.updatePricelist(newPartner);
                    let newPartnerPricelist = this.pos.default_pricelist;
                    //console.log('6666666666666666666666')
                    this.set_pricelist(newPartnerPricelist);

        }


	    

     f_ass_getpos_config() {
            return this.f_pos_config;

    }

     f_ass_set_pos(conf_fpos) {
        this.f_pos_config = conf_fpos;

    }

     f_ass_get_cashier() {
            return this.f_employee_assisted;

    }

     f_ass_set_cashier(employee) {
        this.f_employee_assisted = employee;

    }

    init_from_JSON(json) {
        super.init_from_JSON(...arguments);
            this.f_employee_assisted = this.pos.employee_by_id[json.f_employee_assisted];
           this.f_pos_config  = json.f_pos_config
          // console.log('this7777777777777777777', json.f_pos_config)

    }
    export_as_JSON() {
        const json = super.export_as_JSON(...arguments);
            json.f_employee_assisted = this.f_employee_assisted ? this.f_employee_assisted.id : false;
               json.f_pos_config =this.f_ass_getpos_config();
            //   console.log('json7777777777777777777',json)
        return json;
    }



    export_for_printing() {
            const result = super.export_for_printing.apply(this, arguments);
            if (this.f_employee_assisted){
                 result.f_employee_assisted=this.f_employee_assisted.name;
            }
            else{
             result.f_employee_assisted= = '';
            }


            return result;
        }



}
Registries.Model.extend(Order, PosempOrder);



    const FcustomPaymentScreen = (ProductScreen) =>
        class extends ProductScreen {
            async _onClickPay() {
                const order = this.env.pos.get_order();

                if (this.env.pos.config.f_empl_ass_req){
                if (!order.f_employee_assisted){
                   await this.showPopup('ErrorPopup', {
                    title: this.env._t('Required Field : Assisted by'),
                });
                return false;
                }
                if(!order.get_partner()){
                   await this.showPopup('ErrorPopup', {
                    title: this.env._t('Required Field : Customer'),
                    });
                    return false;
                }

                }





                 if (this.env.pos.config.f_pos_configreq){
                if (!order.f_pos_config){

                for (const line of order.get_orderlines()) {
        if (line.quantity < 0) {
            await this.showPopup('ErrorPopup', {
                    title: this.env._t('Required Field : POS Shop'),
                });
            return false;
        }
    }
    }}




                super._onClickPay();
            }
        };

    Registries.Component.extend(ProductScreen, FcustomPaymentScreen);

    return ProductScreen;






});
