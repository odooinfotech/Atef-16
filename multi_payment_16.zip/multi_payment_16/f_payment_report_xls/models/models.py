# -*- coding: utf-8 -*-

from odoo import models, tools, api, fields, _

from datetime import datetime, timedelta, date
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from odoo.http import request
import logging

_logger = logging.getLogger(__name__)


class FxlsReportCustStatement(models.AbstractModel):
    _name = 'report.f_payment_report_xls.frepochecks_xls'
    _description = 'Excel Payment Report'
    _inherit = ["report.report_xlsx.abstract"]

    def generate_xlsx_report(self, workbook, data, partners):
       # f_pay_ids = self.env['account.payment'].browse(self.env.context.get('active_ids'))

        format1 = workbook.add_format({'font_size': 22, 'bg_color': '#D3D3D3'})
        format4 = workbook.add_format({'font_size': 22})
        format2 = workbook.add_format({'font_size': 12, 'bold': True, 'bg_color': '#D3D3D3'})
        format3 = workbook.add_format({'align': 'right', 'font_size': 12, 'bold': True})
        format5 = workbook.add_format({'align': 'right', 'font_size': 10, 'bg_color': '#D3D3D3', 'bold': True})
        format7 = workbook.add_format({'font_size': 10, 'bg_color': '#FFFFFF'})
        format6 = workbook.add_format({'font_size': 22, 'bg_color': '#FFFFFF'})
        format9 = workbook.add_format({'font_size': 12})
        format10 = workbook.add_format({'font_size': 12, 'bg_color': 'green'})
        format11 = workbook.add_format({'font_size': 14, 'bg_color': 'yellow'})
        format18 = workbook.add_format({'font_size': 10, 'bg_color': 'yellow', 'align': 'center', 'bold': True})
        format12 = workbook.add_format({'font_size': 10})
        format14 = workbook.add_format({'font_size': 10})
        format12.set_align('center')
        format13 = workbook.add_format(
            {'font_size': 10, 'num_format': 'yyyy-mm-dd', 'bg_color': '#D0D1FF', 'bold': True})
        format30 = workbook.add_format({'font_size': 10, 'num_format': 'yyyy-mm-dd', 'align': 'center', 'bold': True})
        format19 = workbook.add_format({'font_size': 10, 'num_format': 'yyyy-mm-dd'})
        format22 = workbook.add_format({'font_size': 10, 'align': 'center', 'bg_color': '#D3D3D3', 'bold': True})
        format20 = workbook.add_format({'font_size': 10, 'align': 'center', 'bold': True})
        format28 = workbook.add_format({'font_size': 10, 'bold': True})

        row_number = 0
        column_number = 0

        sheet_new = workbook.add_worksheet(" Payment Report / xls")
        # sheet_new.right_to_left()
        sheet_new.write('B1', "Payment Report / xls", format28)

        row_number = 11
        column_number = 0

        sheet_new.write(row_number, column_number, "Reference", format11)
        sheet_new.write(row_number, column_number + 1, "Sales Person", format11)
        sheet_new.write(row_number, column_number + 2, "Create On", format11)
        sheet_new.write(row_number, column_number + 3, "check Due Date ", format11)
        sheet_new.write(row_number, column_number + 4, "check Status ", format11)
        sheet_new.write(row_number, column_number + 5, "Amount /Currency ", format11)
        sheet_new.write(row_number, column_number + 6, "Amount In Currency ", format11)
        sheet_new.write(row_number, column_number + 7, "Amount", format11)
        sheet_new.write(row_number, column_number + 8, "Customer", format11)
        sheet_new.write(row_number, column_number + 9, "Customer Account No", format11)
        sheet_new.write(row_number, column_number + 10, "Current Journal", format11)
        sheet_new.write(row_number, column_number + 11, "check No", format11)
        sheet_new.write(row_number, column_number + 12, "Bank", format11)
        sheet_new.write(row_number, column_number + 13, "Number", format11)

        row_number += 1

        for z in partners:
            sheet_new.write(row_number, column_number, z.ref if z.ref else '', format3)
            sheet_new.write(row_number, column_number + 1, z.invoice_user_id.name if z.invoice_user_id.name else '',
                            format3)
            sheet_new.write(row_number, column_number + 2, z.create_date, format19)
            sheet_new.write(row_number, column_number + 3, z.due_date, format19)
            sheet_new.write(row_number, column_number + 4, z.check_state, format3)
            sheet_new.write(row_number, column_number + 5, z.currency_id.symbol, format3)
            sheet_new.write(row_number, column_number + 6, z.amount, format3)
            sheet_new.write(row_number, column_number + 7, z.amount_company_currency_signed, format3)
            sheet_new.write(row_number, column_number + 8, z.partner_id.name, format3)
            sheet_new.write(row_number, column_number + 9, z.account_number, format3)
            sheet_new.write(row_number, column_number + 10, z.journal_id.name, format3)
            sheet_new.write(row_number, column_number + 11, z.check_number, format3)
            sheet_new.write(row_number, column_number + 12, z.bank_id.name, format3)
            sheet_new.write(row_number, column_number + 13, z.name, format3)
            row_number += 1




















