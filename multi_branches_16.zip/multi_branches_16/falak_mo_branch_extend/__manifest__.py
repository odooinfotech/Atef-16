# -*- coding: utf-8 -*-
{
    'name': "Falak Manufacturing Branch Ext",

    'summary': """
            This Module is used to set the picking branch to be same as picking operation type .

        """,

    'description': """
        
    """,

    'author': "Falak Solutions",
    #'website': "http://www.yourcompany.com",

    # Categories can be used to filter modules in modules listing
    # Check https://github.com/odoo/odoo/blob/13.0/odoo/addons/base/data/ir_module_category_data.xml
    # for the full list
    'category': 'Uncategorized',
    'version': '16.0',
    'license': 'LGPL-3',

    # any module necessary for this one to work correctly
    'depends': ['base','stock','f_multi_branches_management','mrp'],

    # always loaded
    'data': [  ],
    # only loaded in demonstration mode
    'demo': [ ],
}
