from odoo import models

class FPosSessionInherit(models.Model):
    _inherit = 'pos.session'
    
    def create_payment(self,vals):

        # Override function to create multi payment header and payment details 
        lines = []
        lines.append((0, 0, vals))
        multi_payment = self.env['f.multi.payments'].search([('f_pos_order_id','=',vals['pos_order_id'])])

        if multi_payment : 
            result =multi_payment.write({'f_payment_lines':lines,'f_multi_pay_state':'draft'})
        else : 
                multi_payment = self.env['f.multi.payments'].create ({
                'f_payment_type'   : 'inbound',
                'f_partner_type'   : 'customer',
                'f_partner_id'     : vals['partner_id'],
                'f_currency_id'    : vals['currency_id'], 
                'f_payment_date'   : vals['date'],
                'f_pay_reference'  : vals['ref'],
                'f_pos_session_id' : vals['pos_session_id'],
                'f_pos_order_id'   : vals['pos_order_id'],
                'f_payment_lines'  : lines
                })
        multi_payment.f_post_payment()
        return multi_payment
