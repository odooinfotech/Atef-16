from odoo import api, fields, models, _

class FPosSession(models.Model):
    _inherit = 'pos.session'
    
    f_related_branch = fields.Many2one('f.comp.branches',string = 'Related Branch',check_company=True,  related = "config_id.f_related_branch")
    f_is_multi_branch = fields.Boolean(related='company_id.f_allow_multi_branches')

    
    
    def _validate_session(self, balancing_account=False, amount_to_balance=0, bank_payment_method_diffs=None):
        
        res = super(FPosSession, self)._validate_session(balancing_account=False, amount_to_balance=0, bank_payment_method_diffs=None)
        all_related_moves = super(FPosSession, self)._get_related_account_moves()
        print('pos session f_related_branch', self.f_related_branch)
        print(all_related_moves)
        for move in (all_related_moves) : 
            move.write({'f_related_branch':self.f_related_branch})
        
        for line in (all_related_moves.mapped('line_ids')) : 
            line.write({'f_related_branch':self.f_related_branch})
        print(self.picking_ids)
        for pick in self.picking_ids: 
            print(pick)
            pick.write({'f_related_branch':self.f_related_branch})
        
        related_payments = self.env['account.payment'].search([('pos_session_id','=',self.id)])
        for pay in related_payments :
            pay.write({'f_related_branch':self.f_related_branch})
        return res 
