from odoo import models, fields, api, _
from datetime import datetime
import base64


class FSaleFile(models.TransientModel):
    _name = 'f.sale.file'
    _description = 'Sale File'

    f_pos_config = fields.Many2one('pos.config', string='POS')
    f_from_date = fields.Date(string='From')
    f_to_date = fields.Date(string='To')
    f_file_name = fields.Char(string='Name')

    def f_generate_sale_file(self):
        lines = []
        orders = self.env['pos.order'].sudo().search([('config_id', '=', self.f_pos_config.id),
                                                     ('date_order', '>=', datetime.combine(self.f_from_date, datetime.min.time())),
                                                     ('date_order', '<=', datetime.combine(self.f_to_date, datetime.max.time()))])
        for order in orders:
            order_lines = self.env['pos.order.line'].sudo().search([('order_id', '=', order.id)])
            for order_line in order_lines:
                ticket_number = str(order.id).zfill(6)
                date = order.date_order.strftime('%d%m%Y').rjust(8)
                article = order_line.product_id.f_article or '0'
                article = article.zfill(5)
                season = order_line.product_id.f_season or ' '
                season = season.rjust(2)
                color = "   "
                size = "   "
                color_attributes = self.env['product.attribute'].sudo().search([('f_type', '=', 'color')])
                size_attributes = self.env['product.attribute'].sudo().search([('f_type', '=', 'size')])
                product_values = order_line.product_id.product_template_variant_value_ids
                for product_value in product_values:
                    attribute_value = product_value.product_attribute_value_id
                    if attribute_value and attribute_value.attribute_id in color_attributes:
                        color = attribute_value.f_code or '0'
                        color = color.zfill(3)
                    if attribute_value and attribute_value.attribute_id in size_attributes:
                        size = attribute_value.name or ' '
                        size = size.rjust(3)
                price = str(int(order_line.price_unit)).zfill(8)
                qty = str(int(order_line.qty)).zfill(5)
                qty_symbol = 'F'
                if order_line.qty < 0:
                    qty_symbol = 'D'
                total_amount = int(order_line.qty * order_line.price_unit)
                amount_symbol = 'F'
                if total_amount < 0:
                    amount_symbol = 'D'
                total_amount = str(total_amount).zfill(11)
                discount = "00"
                discount_type = "0"
                shop_return = "000"
                sp_return = "000"
                pos_number = self.f_pos_config.f_number
                pos_number = pos_number.zfill(3)

                line = ticket_number+date+article+season+color+size+price+qty_symbol+qty+amount_symbol+total_amount+discount+discount_type+shop_return+sp_return+pos_number+' '


                lines.append(line)

        line = '******' + '********' + '*****' + '**' + '***' + '***' + '********' + '*' + '*****' + '*' + '***********' + '**' + '*' + '***' + '***' + '***' + '*'
        lines.append(line)

        text = "\r\n".join(lines)
        return text

    def download_sale_file(self):
        sale_text = self.f_generate_sale_file()
        print('sale_text', sale_text)
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        attachment = self.env['ir.attachment'].sudo().create({
            'name': self.f_file_name,
            'type': 'binary',
            'datas': base64.b64encode(sale_text.encode('utf-8'))
        })

        url = base_url + '/web/content/' + str(attachment.id) + '?download=true'
        print('url', url)
        return {
            'type': 'ir.actions.act_url',
            "url": url,
            "target": "self",
        }

    def f_generate_payment_file(self):
        lines = []
        orders = self.env['pos.order'].sudo().search([('config_id', '=', self.f_pos_config.id),
                                                      ('date_order', '>=',
                                                       datetime.combine(self.f_from_date, datetime.min.time())),
                                                      ('date_order', '<=',
                                                       datetime.combine(self.f_to_date, datetime.max.time()))])
        sessions = self.env['pos.session'].sudo().search([('config_id', '=', self.f_pos_config.id)])
        for order in orders:
            payments = self.env['pos.payment'].sudo().search([('pos_order_id', '=', order.id)])
            ticket_number = str(order.id).zfill(6)
            date = order.date_order.strftime('%d%m%Y').rjust(8)
            sp_code = '000'
            sp_name = ''
            if order.employee_id:
                sp_code = order.employee_id.f_code or '000'
                sp_name = order.employee_id.f_nickname or ''
            else:
                user = order.user_id
                sp_code = user.employee_id.f_code or '000'
                sp_name = user.employee_id.f_nickname or ''
            sp_code = sp_code.zfill(3)
            sp_name = sp_name.zfill(10)
            payment_type = ' '
            if payments:
                f_types = {payment.payment_method_id.f_type for payment in payments}
                if len(f_types) > 1:
                    payment_type = 'V'
                elif len(f_types) == 1:
                    payment_type = f_types.pop()
            payment_type = payment_type.rjust(1)
            total_amount = order.amount_total
            symbol_amount = 'F'
            if total_amount < 0:
                total_amount = total_amount * -1
                symbol_amount = 'D'
            total_amount = str(int(total_amount)).zfill(11)
            cash_amount = 0
            credit_amount = 0
            check_amount = 0
            for payment in payments:
                if payment.payment_method_id.f_type == 'M':
                    cash_amount += payment.amount
                if payment.payment_method_id.f_type == 'T':
                    credit_amount += payment.amount
                if payment.payment_method_id.f_type == 'L':
                    check_amount += payment.amount
            symbol_cash_amount = 'F'
            if cash_amount < 0:
                cash_amount = cash_amount * -1
                symbol_cash_amount = 'D'
            cash_amount = str(int(cash_amount)).zfill(11)
            symbol_credit_amount = 'F'
            if credit_amount < 0:
                credit_amount = credit_amount * -1
                symbol_credit_amount = 'D'
            credit_amount = str(int(credit_amount)).zfill(11)
            symbol_check_amount = 'F'
            if check_amount < 0:
                check_amount = check_amount * -1
                symbol_check_amount = 'D'
            check_amount = str(int(check_amount)).zfill(11)
            symbol_postponed_amount = 'F'
            postponed_amount = '0'.zfill(11)
            symbol_amount_voucher_received = 'F'
            amount_voucher_received = '0'.zfill(11)
            symbol_amount_voucher_given = 'F'
            amount_voucher_given = '0'.zfill(11)
            symbol_amount_discount = 'F'
            amount_discount = '0'.zfill(11)
            hour = order.date_order.strftime('%H%M').rjust(4)
            order_lines = self.env['pos.order.line'].sudo().search([('order_id', '=', order.id)])
            article_number = str(len(order_lines))
            symbol_amount_foreign_currency = 'F'
            amount_foreign_currency = '0'.zfill(11)
            symbol_deliver_foreign_currency = 'F'
            given_foreign_currency = '0'.zfill(11)
            change = '0'.zfill(8)
            credit_card_code = '00'
            code_foreign_currency = '00'
            tax = '0000'
            pos_number = self.f_pos_config.f_number
            pos_number = pos_number.zfill(3)

            line = (ticket_number+date+sp_code+sp_name+payment_type+symbol_amount+total_amount+symbol_cash_amount+cash_amount+symbol_credit_amount
                    +credit_amount+symbol_check_amount+check_amount+symbol_postponed_amount+postponed_amount+symbol_amount_voucher_received+amount_voucher_received
                    +symbol_amount_voucher_given+amount_voucher_given+symbol_amount_discount+amount_discount+hour+article_number+symbol_amount_foreign_currency
                    +amount_foreign_currency+symbol_deliver_foreign_currency+given_foreign_currency+change+credit_card_code+code_foreign_currency+tax+pos_number)


            lines.append(line)

        line = '****************************************************************************************************************************************************************************'
        lines.append(line)

        text = "\r\n".join(lines)
        return text

    def download_payment_file(self):
        payment_text = self.f_generate_payment_file()
        print('sale_text', payment_text)
        base_url = self.env['ir.config_parameter'].sudo().get_param('web.base.url')
        attachment = self.env['ir.attachment'].sudo().create({
            'name': self.f_file_name,
            'type': 'binary',
            'datas': base64.b64encode(payment_text.encode('utf-8'))
        })

        url = base_url + '/web/content/' + str(attachment.id) + '?download=true'
        print('url', url)
        return {
            'type': 'ir.actions.act_url',
            "url": url,
            "target": "self",
        }