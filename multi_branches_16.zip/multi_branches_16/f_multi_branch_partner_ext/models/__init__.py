
from . import f_sale_order_inherit
from . import f_account_move_inherit
from . import f_account_payment_inherit
from . import f_purchase_order_inherit
from . import f_multi_payment_inherit
#from . import f_stock_picking_inherit

