from odoo import models, fields, api, _


class FPosConfigInherit(models.Model):
    _inherit = 'pos.config'

    f_contact_brand_id = fields.Many2one('f.contact.brand', string='Contact Brand')
