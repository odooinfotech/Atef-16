# -*- coding: utf-8 -*-

from itertools import chain

import time
import logging

from ast import literal_eval

from odoo import _, api, fields, models, tools
from odoo.exceptions import UserError
from odoo.tools import DEFAULT_SERVER_DATE_FORMAT
from odoo.tools.safe_eval import safe_eval

_logger = logging.getLogger(__name__)




class FPrice_list(models.Model):
    _inherit = "product.pricelist.item"

    applied_on = fields.Selection(selection_add=[('2b_product_group', 'Group')
        ,('2b_product_section', 'Section')
        , ('2b_product_brand', 'Brand')
        , ('2b_product_season', 'Season')
        , ('2b_product_article', 'Article')],
                                  ondelete={'2b_product_group': 'cascade'
                                      ,'2b_product_section': 'cascade'
                                      , '2b_product_brand': 'cascade'
                                      , '2b_product_season': 'cascade'
                                      , '2b_product_article': 'cascade'
                                            })

    f_group = fields.Many2one('f.product.group', string='Group')
    f_section = fields.Many2one('f.product.section', string='Section')
    f_brand = fields.Char(string='Brand')
    f_season = fields.Char(string='Season')
    f_article = fields.Char(string='Article')

    @api.onchange('applied_on')
    def _onchange_applied_on_price_category(self):

        if self.applied_on != '2b_product_group':
            self.f_group = False
        if self.applied_on != '2b_product_section':
            self.f_section = False
        if self.applied_on != '2b_product_brand':
            self.f_brand = False
        if self.applied_on != '2b_product_season':
            self.f_season = False
        if self.applied_on != '2b_product_article':
            self.f_article = False



    @api.depends('f_group','f_section')
    def _compute_name_and_price(self):

        for rec in self:
            super(FPrice_list, rec)._compute_name_and_price()
            if rec.f_group:
                rec.name = _("Group: %s") % rec.f_group.f_name
            if rec.f_brand:
                rec.name = _("Brand: %s") % rec.f_brand
            if rec.f_season:
                rec.name = _("Season: %s") % rec.f_season
            if rec.f_article:
                rec.name = _("Article: %s") % rec.f_article
            if rec.f_section:
                rec.name = _("Section: %s") % rec.f_section.f_name



    def _is_applicable_for(self, product, qty_in_product_uom):
        res = super(FPrice_list, self)._is_applicable_for(product, qty_in_product_uom)

        if self.applied_on == "2b_product_group" and  self.f_group.id != product.f_group.id:
            return False

        if self.applied_on == "2b_product_section" and  self.f_section.id != product.f_section.id:
            return False
        if self.applied_on == "2b_product_brand" and  self.f_brand != product.f_brand:
            return False

        if self.applied_on == "2b_product_season" and  self.f_season != product.f_season:
            return False
        if self.applied_on == "2b_product_article" and  self.f_article != product.f_article:
            return False


        return res







