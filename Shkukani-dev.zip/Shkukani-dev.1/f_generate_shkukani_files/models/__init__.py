# -*- coding: utf-8 -*-

from . import f_product_attribute_inherit
from . import f_product_attribute_value_inherit
from . import f_sale_file
from . import f_hr_employee_inherit
from . import f_pos_payment_method_inherit
from . import f_pos_config_inherit
