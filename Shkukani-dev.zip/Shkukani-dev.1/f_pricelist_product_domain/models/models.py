# -*- coding: utf-8 -*-

# from odoo import models, fields, api


# class f_pricelist_product_domain(models.Model):
#     _name = 'f_pricelist_product_domain.f_pricelist_product_domain'
#     _description = 'f_pricelist_product_domain.f_pricelist_product_domain'

#     name = fields.Char()
#     value = fields.Integer()
#     value2 = fields.Float(compute="_value_pc", store=True)
#     description = fields.Text()
#
#     @api.depends('value')
#     def _value_pc(self):
#         for record in self:
#             record.value2 = float(record.value) / 100
