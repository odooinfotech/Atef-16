from odoo import models, fields, api, _


class FResPartnerInherit(models.Model):
    _inherit = "res.partner"

    f_exclude_returned_check_fees = fields.Boolean('Exclude Return Check Fees')
