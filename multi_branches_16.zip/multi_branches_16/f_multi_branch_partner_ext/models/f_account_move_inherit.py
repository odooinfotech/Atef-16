from odoo import models, fields, api

class f_account_move_or(models.Model):
    _inherit = 'account.move'


    @api.onchange('partner_id')
    def _get_default_branch_partner(self):
        
         cust_default_branch = False
         context = self._context
         if self.env.user.company_id.f_allow_multi_branches ==True : 
             print('mmmmmm',self.partner_id)
             cust_default_branch = self.env['res.partner'].search([('id','=',self.partner_id.id)]).f_related_branch.id
             if  cust_default_branch :
                print('mmmmmm',cust_default_branch)
                self.f_related_branch  = cust_default_branch

    @api.model_create_multi
    def create(self, vals_list):
        move_id = super().create(vals_list)
        partner_branch = move_id.partner_id.f_related_branch.id
        if partner_branch :
            move_id.write({'f_related_branch': partner_branch})

        else:
            move_id.write({'f_related_branch': self.env.user.f_default_branch.id})
            
        return move_id

