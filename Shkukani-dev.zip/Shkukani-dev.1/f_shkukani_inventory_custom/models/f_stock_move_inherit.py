from odoo import models, fields

class StockMoveInherit(models.Model):
    _inherit = 'stock.move'  # Inherit the stock.move model

    # Define your new field
    f_barcode = fields.Char( related='product_id.barcode')
