from . import f_company_inherit
from . import f_res_config_inherit
from . import f_account_move_inherit
from . import f_account_payment_inherit
from . import f_account_reg_payment_inherit
from . import f_account_journal_inherit
from . import f_bank_branch
from . import f_account_account_inherit
from . import f_checks_bulk_actions
from . import f_res_partner_inherit


